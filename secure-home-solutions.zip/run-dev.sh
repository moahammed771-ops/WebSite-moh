#!/bin/bash
cd /home/z/my-project
trap "" SIGTERM SIGHUP SIGINT
export PATH="/home/z/my-project/node_modules/.bin:$PATH"
while true; do
  /home/z/my-project/node_modules/.bin/next dev -p 3000 >> /home/z/my-project/dev.log 2>&1
  echo "[daemon] exited $(date), restarting in 2s" >> /home/z/my-project/dev.log
  sleep 2
done
