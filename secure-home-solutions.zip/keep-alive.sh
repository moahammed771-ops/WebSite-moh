#!/bin/bash
# Persistent dev server keeper — survives sandbox process kills
cd /home/z/my-project
trap "" SIGTERM SIGHUP SIGINT
while true; do
  /home/z/my-project/node_modules/.bin/next dev -p 3000 >> /home/z/my-project/dev.log 2>&1
  echo "[keeper] server exited $(date), restarting in 1s" >> /home/z/my-project/dev.log
  sleep 1
done
