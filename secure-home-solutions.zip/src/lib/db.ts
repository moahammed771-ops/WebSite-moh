import { PrismaClient } from '@prisma/client'
import fs from 'fs'
import path from 'path'

// Hardcoded fallback Supabase URL — used when .env gets overwritten by sandbox
const FALLBACK_DB_URL = 'postgresql://postgres.oqhcrbyjythiyqhjjzsa:moh%40775986004@aws-0-ap-northeast-1.pooler.supabase.com:5432/postgres'

function loadDatabaseUrl(): string {
  // 1. Check process.env for a valid PostgreSQL URL
  const envVal = process.env.DATABASE_URL
  if (envVal && (envVal.startsWith('postgresql://') || envVal.startsWith('postgres://'))) {
    return envVal
  }

  // 2. Read from .env file (may have been overwritten by sandbox)
  try {
    const envPath = path.join(process.cwd(), '.env')
    if (fs.existsSync(envPath)) {
      const content = fs.readFileSync(envPath, 'utf-8')
      for (const line of content.split('\n')) {
        const trimmed = line.trim()
        if (!trimmed || trimmed.startsWith('#')) continue
        const eqIdx = trimmed.indexOf('=')
        if (eqIdx === -1) continue
        const key = trimmed.slice(0, eqIdx).trim()
        let value = trimmed.slice(eqIdx + 1).trim()
        if ((value.startsWith('"') && value.endsWith('"')) || (value.startsWith("'") && value.endsWith("'"))) {
          value = value.slice(1, -1)
        }
        if (key === 'DATABASE_URL' && (value.startsWith('postgresql://') || value.startsWith('postgres://'))) {
          process.env.DATABASE_URL = value
          return value
        }
      }
    }
  } catch {
    // ignore
  }

  // 3. Fallback to hardcoded Supabase URL
  process.env.DATABASE_URL = FALLBACK_DB_URL
  return FALLBACK_DB_URL
}

const dbUrl = loadDatabaseUrl()

const globalForPrisma = globalThis as unknown as {
  prisma: PrismaClient | undefined
}

export const db =
  globalForPrisma.prisma ??
  new PrismaClient({
    log: process.env.NODE_ENV !== 'production' ? ['error', 'warn'] : ['error'],
    datasources: { db: { url: dbUrl } },
  })

if (process.env.NODE_ENV !== 'production') globalForPrisma.prisma = db
