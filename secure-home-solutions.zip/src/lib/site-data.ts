import type { LucideIcon } from "lucide-react";
import {
  Cctv,
  DoorClosed,
  Flame,
  SunMedium,
  ShieldCheck,
  Award,
  Clock,
  Users,
  Wrench,
  HeartHandshake,
  Lightbulb,
  Lock,
  Sparkles,
  PhoneCall,
  MessagesSquare,
  Target,
  Eye,
  Zap,
  Gauge,
  Headset,
  SearchCheck,
  PencilRuler,
  ClipboardCheck,
  Star,
  Quote,
  Building2,
  Home,
  Factory,
  Store,
  CheckCircle2,
  TrendingUp,
  Info,
  Briefcase,
  Tag,
  BookOpen,
  Mail,
} from "lucide-react";

export const COMPANY = {
  name: "Secure Home Solutions",
  nameAr: "حلول أمان منزلية متكاملة",
  short: "Secure Home",
  phone: "+967 734 066 962",
  phoneRaw: "+967734066962",
  whatsapp: "+967734066962",
  email: "info@securehome.com",
  address: "صنعاء، شارع الزبيري، اليمن",
  addressEn: "Sana'a, Al-Zubairi St., Yemen",
  hours: "السبت - الخميس: 8 ص - 6 م",
  founded: "2019",
} as const;

export const NAV_LINKS = [
  { label: "الرئيسية", href: "/" },
  { label: "من نحن", href: "/about" },
  { label: "خدماتنا", href: "/services" },
  { label: "مشاريعنا", href: "/projects" },
  { label: "الأسعار", href: "/pricing" },
  { label: "المدونة", href: "/blog" },
  { label: "تواصل معنا", href: "/contact" },
] as const;

export const HERO_SLIDES = [
  {
    eyebrow: "الأمان هو أولويتنا",
    title: "حلول أمان منزلية متكاملة",
    highlight: "أمان منزلية",
    description:
      "نقدم لك أفضل الحلول الأمنية المتكاملة بأعلى جودة وأسعار منافسة مع خدمة على مدار الساعة وفريق فني محترف.",
    image: "/images/hero-1.png",
    tag: "أنظمة الحماية والمراقبة",
  },
  {
    eyebrow: "طاقة مستدامة لك",
    title: "أنظمة الطاقة الشمسية الأكثر كفاءة",
    highlight: "الطاقة الشمسية",
    description:
      "استثمر في الطاقة النظيفة ووفّر حتى 70% من فاتورة الكهرباء بألواح شمسية عالية الكفاءة وبطاريات ليثيوم طويلة العمر.",
    image: "/images/hero-2.png",
    tag: "حلول الطاقة المتجددة",
  },
  {
    eyebrow: "حماية استباقية ذكية",
    title: "أنظمة إنذار حريق ومراقبة ذكية",
    highlight: "إنذار الحريق",
    description:
      "كواشف ذكية فورية وأنظمة إطفاء تلقائي بالرغوة تحمي منشأتك على مدار الساعة بأحدث تقنيات الذكاء الاصطناعي.",
    image: "/images/hero-3.png",
    tag: "الإنذار والإطفاء",
  },
] as const;

export const HERO_FEATURES = [
  { icon: Clock, label: "خدمة 24/7" },
  { icon: Users, label: "فنيين مدربين" },
  { icon: Award, label: "جودة عالية" },
  { icon: HeartHandshake, label: "أسعار منافسة" },
] as const;

export const CERTIFICATIONS = [
  { label: "ISO 9001", sub: "شهادة جودة" },
  { label: "Hikvision", sub: "شريك معتمد" },
  { label: "Dahua", sub: "وكيل معتمد" },
  { label: "UL Listed", sub: "سلامة معتمدة" },
] as const;

export const ABOUT_BADGES = [
  { icon: ShieldCheck, label: "معتمدون من Hikvision" },
  { icon: Award, label: "وكلاء Dahua المعتمدون" },
  { icon: Flame, label: "شهادات سلامة الحريق" },
  { icon: Wrench, label: "تركيب احترافي معتمد" },
] as const;

export const STATS_PRIMARY = [
  { icon: Users, value: 48, suffix: "+", label: "فريق محترف" },
  { icon: Award, value: 320, suffix: "+", label: "مشروع منجز" },
  { icon: Clock, value: 6, suffix: "+", label: "سنوات خبرة" },
] as const;

export const TIMELINE = [
  {
    year: "2019",
    title: "تأسيس الشركة",
    desc: "انطلاقة Secure Home Solutions في صنعاء برؤية لتوفير حلول أمان موثوقة.",
    icon: Sparkles,
  },
  {
    year: "2020",
    title: "أول 50 مشروع",
    desc: "إنجاز أول 50 مشروع بنجاح وبناء قاعدة عملاء أوفياء في جميع أنحاء اليمن.",
    icon: Award,
  },
  {
    year: "2022",
    title: "توسيع الخدمات",
    desc: "إضافة أنظمة الطاقة الشمسية وإنذار الحريق لتقديم حلول متكاملة شاملة.",
    icon: Target,
  },
  {
    year: "2024",
    title: "+300 مشروع",
    desc: "تجاوزنا حاجز 300 مشروع منجز مع توسع الفريق الفني والشراكات الدولية.",
    icon: ShieldCheck,
  },
] as const;

export const CORE_VALUES = [
  {
    icon: Award,
    title: "الجودة",
    desc: "نلتزم بأعلى معايير الجودة في كل تفصيل من تركيب وصيانة.",
    color: "#f05100",
  },
  {
    icon: ShieldCheck,
    title: "الأمان",
    desc: "حمايتك وأمانك هو أولويتنا القصوى في كل ما نقدمه.",
    color: "#009588",
  },
  {
    icon: Lightbulb,
    title: "الابتكار",
    desc: "نستخدم أحدث التقنيات والحلول المبتكرة من أفضل الشركات العالمية.",
    color: "#fcbb00",
  },
  {
    icon: Lock,
    title: "الثقة",
    desc: "نبني علاقات طويلة الأمد مبنية على الثقة والشفافية الكاملة.",
    color: "#104e64",
  },
] as const;

export const STATS_SECONDARY = [
  { value: 6, suffix: "+", label: "سنوات خبرة" },
  { value: 320, suffix: "+", label: "مشروع منجز" },
  { value: 280, suffix: "+", label: "عميل راضٍ" },
  { value: 48, suffix: "+", label: "فني محترف" },
  { value: 24, suffix: "/7", label: "خدمة متواصلة" },
  { value: 99, suffix: "%", label: "رضا العملاء" },
] as const;

export type Service = {
  id: string;
  num: string;
  icon: LucideIcon;
  title: string;
  desc: string;
  features: string[];
  image: string;
  accent: string;
};

export const SERVICES: Service[] = [
  {
    id: "cctv",
    num: "01",
    icon: Cctv,
    title: "كاميرات المراقبة",
    desc: "أنظمة مراقبة احترافية بأحدث التقنيات تشمل كاميرات IP وHD مع ميزات الذكاء الاصطناعي.",
    features: ["كاميرات 4K فائقة الدقة", "رؤية ليلية متقدمة", "تنبيهات ذكية عبر الهاتف", "تخزين سحابي آمن"],
    image: "/images/service-cctv.png",
    accent: "#f05100",
  },
  {
    id: "intercom",
    num: "02",
    icon: DoorClosed,
    title: "أنظمة الإنتركم",
    desc: "أنظمة اتصال داخلي متطورة تشمل الإنتركم الصوتي والمرئي مع تقنية الذكاء الاصطناعي.",
    features: ["إنتركم مرئي عالي الدقة", "فتح الأبواب عن بعد", "تكامل مع الهاتف الذكي", "تحكم بصمة الوجه"],
    image: "/images/service-intercom.png",
    accent: "#009588",
  },
  {
    id: "fire",
    num: "03",
    icon: Flame,
    title: "إنذار الحريق",
    desc: "أنظمة إنذار حريق متكاملة تشمل كواشف الدخان والحرارة مع أنظمة الإطفاء التلقائي.",
    features: ["كواشف ذكية فورية", "إطفاء تلقائي بالرغوة", "ربط مع غرفة التحكم", "صيانة دورية معتمدة"],
    image: "/images/service-fire.png",
    accent: "#e40014",
  },
  {
    id: "solar",
    num: "04",
    icon: SunMedium,
    title: "الطاقة الشمسية",
    desc: "حلول طاقة شمسية متكاملة تشمل الألواح الشمسية والبطاريات والأنفرترات بأسعار تنافسية.",
    features: ["ألواح شمسية عالية الكفاءة", "بطاريات ليثيوم طويلة العمر", "أنفرتر ذكي متطور", "ضمان حتى 25 سنة"],
    image: "/images/service-solar.png",
    accent: "#fcbb00",
  },
];

export const VISION_MISSION = [
  {
    icon: Eye,
    title: "رؤيتنا",
    desc: "أن نكون الخيار الأول في حلول الأمان والحماية في المنطقة، ورواداً في تبني أحدث التقنيات الذكية.",
  },
  {
    icon: Target,
    title: "مهمتنا",
    desc: "توفير حلول أمان مبتكرة وموثوقة تحمي ما يهمك، مع التزام تام بالجودة وخدمة عملاء استثنائية.",
  },
] as const;

export const QUICK_LINKS = [
  { label: "الرئيسية", href: "/" },
  { label: "من نحن", href: "/about" },
  { label: "خدماتنا", href: "/services" },
  { label: "مشاريعنا", href: "/projects" },
  { label: "الأسعار", href: "/pricing" },
  { label: "المدونة", href: "/blog" },
  { label: "الأسئلة الشائعة", href: "/faq" },
  { label: "تواصل معنا", href: "/contact" },
] as const;

export const FOOTER_SERVICES = [
  { label: "كاميرات المراقبة", href: "/services/cctv" },
  { label: "أنظمة الإنتركم", href: "/services/intercom" },
  { label: "إنذار الحريق", href: "/services/fire" },
  { label: "الطاقة الشمسية", href: "/services/solar" },
  { label: "الصيانة والدعم", href: "/contact" },
  { label: "الاستشارات الفنية", href: "/contact" },
] as const;

/* ============ بطاقات استكشاف الصفحات (الصفحة الرئيسية) ============ */
export const EXPLORE_PAGES = [
  {
    title: "من نحن",
    desc: "تعرّف على شركتنا، رؤيتنا، قيمنا، مسيرة نجاحنا وفريقنا المتميز.",
    href: "/about",
    icon: Info,
    accent: "#f05100",
  },
  {
    title: "خدماتنا",
    desc: "كاميرات المراقبة، الإنتركم، إنذار الحريق، والطاقة الشمسية.",
    href: "/services",
    icon: Cctv,
    accent: "#009588",
  },
  {
    title: "مشاريعنا",
    desc: "أكثر من 320 مشروعاً منجزاً في مختلف أنحاء اليمن.",
    href: "/projects",
    icon: Briefcase,
    accent: "#104e64",
  },
  {
    title: "الأسعار",
    desc: "باقات تناسب جميع الميزانيات مع ضمان رسمي وتركيب احترافي.",
    href: "/pricing",
    icon: Tag,
    accent: "#fcbb00",
  },
  {
    title: "المدونة",
    desc: "أحدث المقالات والنصائح في مجال الأمان والطاقة.",
    href: "/blog",
    icon: BookOpen,
    accent: "#7c3aed",
  },
  {
    title: "تواصل معنا",
    desc: "نحن هنا لمساعدتك على مدار الساعة عبر قنوات متعددة.",
    href: "/contact",
    icon: Mail,
    accent: "#e40014",
  },
] as const;

export const FOOTER_CERTS = [
  { icon: ShieldCheck, label: "معتمد Hikvision" },
  { icon: Award, label: "وكلاء Dahua" },
  { icon: Flame, label: "شهادة سلامة" },
  { icon: Wrench, label: "تركيب معتمد" },
  { icon: Lock, label: "SSL/TLS مشفر بالكامل" },
  { icon: Award, label: "أفضل شركة أمن 2024" },
  { icon: Award, label: "شهادة ISO 9001" },
  { icon: HeartHandshake, label: "شريك معتمد" },
] as const;

export const ASSISTANT_SUGGESTIONS = [
  { icon: Cctv, text: "أريد نظام كاميرات مراقبة لمنزلي" },
  { icon: SunMedium, text: "كم تكلفة تركيب طاقة شمسية؟" },
  { icon: Flame, text: "ما هي أفضل أنظمة إنذار الحريق؟" },
  { icon: PhoneCall, text: "كيف أتواصل معكم لطلب عرض سعر؟" },
] as const;

export const ASSISTANT_CAPABILITIES = [
  { icon: MessagesSquare, label: "استشارات فنية فورية" },
  { icon: Target, label: "توصية بالحل المناسب" },
  { icon: Wrench, label: "تقدير أسعار مبدئي" },
  { icon: PhoneCall, label: "تحويل لمتخصص" },
] as const;

/* ============ لماذا نحن ============ */
export const WHY_US = [
  {
    icon: Award,
    title: "خبرة موثوقة",
    desc: "أكثر من 6 سنوات من الخبرة في تنفيذ مشاريع الأمان المعقدة بشهادات معتمدة.",
    color: "#f05100",
  },
  {
    icon: Zap,
    title: "استجابة سريعة",
    desc: "فريق فني جاهز لل intervention خلال 24 ساعة مع خدمة طوارئ على مدار الساعة.",
    color: "#009588",
  },
  {
    icon: ShieldCheck,
    title: "تقنيات معتمدة",
    desc: "نستخدم منتجات Hikvision وDahua المعتمدة عالمياً مع ضمان رسمي حتى 5 سنوات.",
    color: "#104e64",
  },
  {
    icon: HeartHandshake,
    title: "أسعار منافسة",
    desc: "حلول مرنة تناسب جميع الميزانيات مع شفافية كاملة في التسعير دون رسوم خفية.",
    color: "#fcbb00",
  },
  {
    icon: Headset,
    title: "دعم متواصل",
    desc: "دعم فني مستمر بعد التركيب مع صيانة دورية ومتابعة دورية لرضاك.",
    color: "#e40014",
  },
  {
    icon: Lightbulb,
    title: "حلول مبتكرة",
    desc: "تكامل مع أنظمة الذكاء الاصطناعي والمنازل الذكية لأمان استباقي حقيقي.",
    color: "#7c3aed",
  },
] as const;

/* ============ كيف نعمل ============ */
export const PROCESS_STEPS = [
  {
    num: "01",
    icon: SearchCheck,
    title: "الاستشارة الأولية",
    desc: "نستمع لاحتياجاتك ونقيّم الموقع لاقتراح الحل الأنسب لمتطلباتك.",
  },
  {
    num: "02",
    icon: PencilRuler,
    title: "التصميم والتخطيط",
    desc: "نصمم خطة أمان متكاملة بمخططات فنية دقيقة بناءً على معطياتك.",
  },
  {
    num: "03",
    icon: Wrench,
    title: "التركيب والتنفيذ",
    desc: "فريق معتمد يقوم بالتركيب الاحترافي بأحدث الأدوات وأفضل الممارسات.",
  },
  {
    num: "04",
    icon: ClipboardCheck,
    title: "الاختبار والتشغيل",
    desc: "نختبر جميع الأنظمة شاملةً وندربك على الاستخدام قبل التسليم.",
  },
  {
    num: "05",
    icon: Headset,
    title: "الصيانة والدعم",
    desc: "نوفر صيانة دورية ودعماً فنياً مستمراً لضمان كفاءة الأنظمة على المدى الطويل.",
  },
] as const;

/* ============ مشاريعنا ============ */
export type Project = {
  id: string;
  title: string;
  category: string;
  location: string;
  image: string;
  icon: LucideIcon;
  desc: string;
  tags: string[];
};

export const PROJECTS: Project[] = [
  {
    id: "p1",
    title: "نظام مراقبة فيلا سكنية",
    category: "كاميرات مراقبة",
    location: "صنعاء - حدة",
    image: "/images/project-1.png",
    icon: Home,
    desc: "تركيب 8 كاميرات 4K مع تخزين سحابي وتنبيهات ذكية عبر الهاتف.",
    tags: ["كاميرات 4K", "تخزين سحابي", "تنبيهات ذكية"],
  },
  {
    id: "p2",
    title: "نظام طاقة شمسية لمبنى تجاري",
    category: "طاقة شمسية",
    location: "صنعاء - شارع الزبيري",
    image: "/images/project-2.png",
    icon: Building2,
    desc: "تركيب 40 لوح شمسي مع أنفرتر ذكي لتوفير 70% من فاتورة الكهرباء.",
    tags: ["ألواح شمسية", "أنفرتر ذكي", "توفير 70%"],
  },
  {
    id: "p3",
    title: "نظام إنذار حريق لمستودع",
    category: "إنذار حريق",
    location: "عدن - المنطقة الحرة",
    image: "/images/project-3.png",
    icon: Factory,
    desc: "تركيب 32 كاشف دخان وحرارة مع نظام إطفاء تلقائي بالرغوة.",
    tags: ["كواشف ذكية", "إطفاء تلقائي", "ربط تحكم"],
  },
  {
    id: "p4",
    title: "إنتركم مرئي لمكتب إداري",
    category: "أنظمة إنتركم",
    location: "صنعاء - التجارية",
    image: "/images/project-4.png",
    icon: Store,
    desc: "إنتركم مرئي عالي الدقة مع تحكم بفتح الأبواب عن بعد وبصمة الوجه.",
    tags: ["إنتركم مرئي", "فتح عن بعد", "بصمة الوجه"],
  },
  {
    id: "p5",
    title: "أمان متكامل لمنزل ذكي",
    category: "حلول متكاملة",
    location: "صنعاء - شملان",
    image: "/images/project-5.png",
    icon: Home,
    desc: "حزمة شاملة: كاميرات + إنذار + طاقة شمسية مع تكامل المنزل الذكي.",
    tags: ["حل متكامل", "منزل ذكي", "5 كاميرات"],
  },
  {
    id: "p6",
    title: "غرفة تحكم مراقبة مركزية",
    category: "كاميرات مراقبة",
    location: "صنعاء - المركز",
    image: "/images/project-6.png",
    icon: Building2,
    desc: "تجهيز غرفة تحكم بشاشات عرض متعددة لمراقبة 48 كاميرا على مدار الساعة.",
    tags: ["غرفة تحكم", "48 كاميرا", "مراقبة 24/7"],
  },
] as const;

export const PROJECT_FILTERS = [
  "الكل",
  "كاميرات مراقبة",
  "أنظمة إنتركم",
  "إنذار حريق",
  "طاقة شمسية",
  "حلول متكاملة",
] as const;

/* ============ الأسعار ============ */
export type PricingPlan = {
  id: string;
  name: string;
  tagline: string;
  price: string;
  period: string;
  popular: boolean;
  features: string[];
  cta: string;
  accent: string;
};

export const PRICING_PLANS: PricingPlan[] = [
  {
    id: "basic",
    name: "الباقة الأساسية",
    tagline: "مثالية للمنازل الصغيرة والشقق",
    price: "299",
    period: "ابتداءً من / دولار",
    popular: false,
    accent: "#104e64",
    features: [
      "4 كاميرات HD بدقة عالية",
      "جهاز تسجيل 4 قنوات",
      "رؤية ليلية حتى 30 متر",
      "تطبيق مراقبة للهاتف",
      "تركيب احترافي مجاني",
      "ضمان سنة كاملة",
      "دعم فني خلال أسبوع",
    ],
    cta: "اطلب الآن",
  },
  {
    id: "pro",
    name: "الباقة الاحترافية",
    tagline: "الأكثر طلباً للفلل والمكاتب",
    price: "699",
    period: "ابتداءً من / دولار",
    popular: true,
    accent: "#f05100",
    features: [
      "8 كاميرات 4K فائقة الدقة",
      "جهاز تسجيل 8 قنوات AI",
      "رؤية ليلية ملونة متقدمة",
      "تنبيهات ذكية بالحركة",
      "تخزين سحابي 30 يوم",
      "إنتركم مرئي مجاني",
      "تركيب + تدريب مجاني",
      "ضمان 3 سنوات",
      "دعم فني 24/7 أولوية",
    ],
    cta: "الأكثر طلباً",
  },
  {
    id: "enterprise",
    name: "باقة المؤسسات",
    tagline: "للمنشآت الكبيرة والمصانع",
    price: "حسب الطلب",
    period: "عرض سعر مخصص",
    popular: false,
    accent: "#009588",
    features: [
      "كاميرات غير محدودة",
      "غرفة تحكم مركزية",
      "أنظمة إنذار حريق متكاملة",
      "ربط فروع متعددة",
      "تخزين سحابي غير محدود",
      "طاقة شمسية اختيارية",
      "فريق صيانة مخصص",
      "ضمان 5 سنوات",
      "دعم فني فوري على مدار الساعة",
    ],
    cta: "تواصل معنا",
  },
] as const;

/* ============ آراء العملاء ============ */
export type Testimonial = {
  id: string;
  name: string;
  role: string;
  rating: number;
  text: string;
  initials: string;
  color: string;
};

export const TESTIMONIALS: Testimonial[] = [
  {
    id: "t1",
    name: "أحمد الشامي",
    role: "صاحب فيلا - صنعاء",
    rating: 5,
    text: "خدمة احترافية من البداية للنهاية. الفريق منظم والتركيب نظيف جداً. كاميرات الـ4K وضوحها خيالي وأنصح بهم بشدة.",
    initials: "أ.ش",
    color: "#f05100",
  },
  {
    id: "t2",
    name: "سلمى الحضرمي",
    role: "مديرة مكتب - عدن",
    rating: 5,
    text: "ركّبوا لنا نظام طاقة شمسية ووفّر علينا 65% من فاتورة الكهرباء. متابعة دورية ممتازة ودعم فني سريع.",
    initials: "س.ح",
    color: "#009588",
  },
  {
    id: "t3",
    name: "خالد العولقي",
    role: "مدير مستودع - المنطقة الحرة",
    rating: 5,
    text: "نظام إنذار الحريق أنقذنا من حادث كبير. الكواشف تستجيب فوراً والفريق يأتي للصيانة في الموعد دائماً.",
    initials: "خ.ع",
    color: "#104e64",
  },
  {
    id: "t4",
    name: "منى الإرياني",
    role: "صاحبة محل تجاري",
    rating: 5,
    text: "الإنتركم المرئي سهّل علينا التحكم بالدخول وفتح الباب عن بعد. الجودة ممتازة والسعر معقول جداً.",
    initials: "م.إ",
    color: "#fcbb00",
  },
  {
    id: "t5",
    name: "فهد المخلافي",
    role: "مهندس - شركة مقاولات",
    rating: 5,
    text: "تعاملنا معهم في 3 مشاريع حتى الآن. الالتزام بالمواعيد والاحترافية في التنفيذ شيء مميز فعلاً.",
    initials: "ف.م",
    color: "#e40014",
  },
  {
    id: "t6",
    name: "نورا قائد",
    role: "ربة منزل - حدة",
    rating: 5,
    text: "المساعد الذكي ساعدني أختار النظام المناسب قبل ما أتصل. خدمة ذكية وفكرة رائعة. شكراً Secure Home.",
    initials: "ن.ق",
    color: "#7c3aed",
  },
] as const;

/* ============ شركاؤنا ============ */
export const PARTNERS = [
  { name: "Hikvision", desc: "شريك معتمد" },
  { name: "Dahua", desc: "وكيل معتمد" },
  { name: "Honeywell", desc: "أنظمة إنذار" },
  { name: "ZKTeco", desc: "تحكم بالدخول" },
  { name: "JA Solar", desc: "ألواح شمسية" },
  { name: "Tesla Powerwall", desc: "بطاريات" },
  { name: "Axis", desc: "كاميرات IP" },
  { name: "Bosch", desc: "أنظمة أمان" },
] as const;

/* ============ مقارنة الخدمات ============ */
export type ComparisonService = {
  id: string;
  name: string;
  icon: LucideIcon;
  startPrice: string;
  warranty: string;
  accent: string;
};

export const COMPARISON_SERVICES: ComparisonService[] = [
  {
    id: "cctv",
    name: "كاميرات المراقبة",
    icon: Cctv,
    startPrice: "120$",
    warranty: "سنتان",
    accent: "#f05100",
  },
  {
    id: "intercom",
    name: "أنظمة الإنتركم",
    icon: DoorClosed,
    startPrice: "180$",
    warranty: "سنة",
    accent: "#009588",
  },
  {
    id: "fire",
    name: "إنذار الحريق",
    icon: Flame,
    startPrice: "250$",
    warranty: "3 سنوات",
    accent: "#e40014",
  },
  {
    id: "solar",
    name: "الطاقة الشمسية",
    icon: SunMedium,
    startPrice: "900$",
    warranty: "5 سنوات",
    accent: "#fcbb00",
  },
];

export const COMPARISON_FEATURES = [
  { label: "الإشعارات الذكية", values: [true, true, true, false] },
  { label: "التحكم عن بعد", values: [true, true, false, true] },
  { label: "تكامل المنزل الذكي", values: [true, true, true, true] },
  { label: "توفير الطاقة", values: [false, false, false, true] },
  { label: "تنبيهات الطوارئ", values: [true, false, true, false] },
  { label: "تخزين سحابي", values: [true, false, true, true] },
  { label: "صيانة دورية مجانية", values: [true, true, true, true] },
  { label: "دعم فني 24/7", values: [true, true, true, true] },
] as const;

/* ============ منتجاتنا المتميزة ============ */
export type Product = {
  id: string;
  name: string;
  brand: string;
  model: string;
  category: string;
  price: string;
  badge: string;
  accent: string;
  icon: LucideIcon;
};

export const PRODUCTS: Product[] = [
  {
    id: "prod1",
    name: "كاميرا Dome",
    brand: "Hikvision",
    model: "DS-2CD2143G2-I",
    category: "كاميرات",
    price: "120$",
    badge: "4MP",
    accent: "#f05100",
    icon: Cctv,
  },
  {
    id: "prod2",
    name: "كاميرا PTZ 4K",
    brand: "Dahua",
    model: "SD5A432GA-HNR",
    category: "كاميرات",
    price: "650$",
    badge: "4K",
    accent: "#009588",
    icon: Cctv,
  },
  {
    id: "prod3",
    name: "كاميرا WDR",
    brand: "Hikvision",
    model: "DS-2CD2043G2-I",
    category: "كاميرات",
    price: "95$",
    badge: "4MP",
    accent: "#104e64",
    icon: Cctv,
  },
  {
    id: "prod4",
    name: "إنتركم مرئي",
    brand: "Commax",
    model: "CDV-70B",
    category: "إنتركم",
    price: "180$",
    badge: "HD",
    accent: "#7c3aed",
    icon: DoorClosed,
  },
  {
    id: "prod5",
    name: "كاشف دخان ذكي",
    brand: "Honeywell",
    model: "SF-100",
    category: "إنذار",
    price: "45$",
    badge: "ذكي",
    accent: "#e40014",
    icon: Flame,
  },
  {
    id: "prod6",
    name: "لوح شمسي 450W",
    brand: "JA Solar",
    model: "JAM72S30-450",
    category: "طاقة",
    price: "210$",
    badge: "450W",
    accent: "#fcbb00",
    icon: SunMedium,
  },
];

export const PRODUCT_FILTERS = ["الكل", "كاميرات", "إنتركم", "إنذار", "طاقة"] as const;

/* ============ فريقنا ============ */
export type TeamMember = {
  id: string;
  name: string;
  role: string;
  desc: string;
  initials: string;
  color: string;
};

export const TEAM: TeamMember[] = [
  {
    id: "t1",
    name: "أحمد الشرعبي",
    role: "المدير التنفيذي",
    desc: "مؤسس الشركة بخبرة 10 سنوات في مجال الأمان",
    initials: "أ",
    color: "#f05100",
  },
  {
    id: "t2",
    name: "سارة الحداد",
    role: "مديرة التسويق",
    desc: "خبرة في تسويق الحلول التقنية والأمنية",
    initials: "س",
    color: "#009588",
  },
  {
    id: "t3",
    name: "علي المخلافي",
    role: "مهندس تقني",
    desc: "معتمد من Hikvision وDahua للتركيب",
    initials: "ع",
    color: "#104e64",
  },
  {
    id: "t4",
    name: "فاطمة القباطي",
    role: "مستشارة أمنية",
    desc: "متخصصة في تصميم أنظمة الأمان المتكاملة",
    initials: "ف",
    color: "#7c3aed",
  },
  {
    id: "t5",
    name: "يوسف الصبري",
    role: "مدير المبيعات",
    desc: "خبرة واسعة في حلول عملاء الشركات",
    initials: "ي",
    color: "#fcbb00",
  },
  {
    id: "t6",
    name: "هناء الإرياني",
    role: "موظفة دعم",
    desc: "تقدم دعماً فنياً ممتازاً على مدار الساعة",
    initials: "ه",
    color: "#e40014",
  },
];

/* ============ الأسئلة الشائعة ============ */
export type FAQItem = {
  id: string;
  question: string;
  answer: string;
  category: string;
};

export const FAQ_ITEMS: FAQItem[] = [
  {
    id: "f1",
    category: "كاميرات",
    question: "ما هي أنواع الكاميرات الأمنية التي تقدمونها؟",
    answer:
      "نقدم مجموعة شاملة من كاميرات المراقبة تشمل كاميرات IP وHD و4K، كاميرات Dome وBullet وPTZ، مع ميزات الرؤية الليلية والذكاء الاصطناعي وتنبيهات الهاتف الذكي.",
  },
  {
    id: "f2",
    category: "صيانة",
    question: "كيف يمكنني طلب خدمة الصيانة؟",
    answer:
      "يمكنك طلب خدمة الصيانة عبر الاتصال على +967 734 066 962 أو تعبئة نموذج طلب عرض سعر في الموقع. فريقنا سيصل إليك خلال 24 ساعة في صنعاء و48 ساعة في باقي المحافظات.",
  },
  {
    id: "f3",
    category: "ضمان",
    question: "هل تقدمون ضماناً على المنتجات والخدمات؟",
    answer:
      "نعم، نقدم ضماناً رسمياً يصل إلى 5 سنوات على المعدات وضماناً لمدة سنة على التركيب. تشمل الضمان الصيانة الدورية المجانية واستبدال القطع المعيبة.",
  },
  {
    id: "f4",
    category: "كاميرات",
    question: "كم يستغرق تركيب نظام الكاميرات؟",
    answer:
      "يعتمد الوقت على حجم النظام: نظام منزلي صغير (4-8 كاميرات) يستغرق يوماً واحداً، بينما المشاريع الكبيرة قد تستغرق من 2 إلى 5 أيام. نلتزم دائماً بالموعد المتفق عليه.",
  },
  {
    id: "f5",
    category: "تقنية",
    question: "هل يمكنني التحكم في الكاميرات عن بعد؟",
    answer:
      "بالتأكيد! جميع أنظمتنا تدعم التحكم عن بعد عبر تطبيق الهاتف الذكي (iOS وAndroid) من أي مكان في العالم. يمكنك مشاهدة البث المباشر واستلام التنبيهات وتشغيل التسجيلات.",
  },
  {
    id: "f6",
    category: "أسعار",
    question: "ما هي أسعار خدماتكم؟",
    answer:
      "أسعارنا تبدأ من 299$ للباقة الأساسية و699$ للباقة الاحترافية. للمشاريع المخصصة نقدم عروض أسعار مجانية بعد تقييم الموقع. اتصل بنا للحصول على عرض دقيق.",
  },
  {
    id: "f7",
    category: "طاقة",
    question: "كم أوفر بتركيب نظام الطاقة الشمسية؟",
    answer:
      "يصل التوفير إلى 70% من فاتورة الكهرباء شهرياً، وتسترد قيمة الاستثمار خلال 3-5 سنوات. الألواح الشمسية لها عمر افتراضي 25 سنة مع ضمان 10 سنوات على الأداء.",
  },
  {
    id: "f8",
    category: "صيانة",
    question: "هل تقدمون خدمة ما بعد البيع؟",
    answer:
      "نعم، نقدم دعماً فنياً مستمراً على مدار الساعة، وصيانة دورية مجانية خلال فترة الضمان، وخدمات إضافية بتكلفة مخفضة بعد انتهاء الضمان لضمان استمرارية أداء أنظمتك.",
  },
] as const;

/* ============ المدونة ============ */
export type BlogPost = {
  id: string;
  title: string;
  excerpt: string;
  category: string;
  date: string;
  readTime: string;
  comments: number;
  image: string;
  featured?: boolean;
};

export const BLOG_POSTS: BlogPost[] = [
  {
    id: "b1",
    title: "كيفية اختيار الكاميرا الأمنية المناسبة لمنزلك",
    excerpt:
      "دليل شامل لاختيار أفضل كاميرا مراقبة لمنزلك يشمل الدقة، زاوية الرؤية، الرؤية الليلية، والميزات الذكية التي تحتاجها لحماية منزلك بفعالية.",
    category: "نصائح",
    date: "15 يناير 2025",
    readTime: "8 دقائق",
    comments: 12,
    image: "/images/blog-1.png",
    featured: true,
  },
  {
    id: "b2",
    title: "كيف تحمي منزلك من السرقة بأحدث التقنيات",
    excerpt:
      "تعرّف على أحدث تقنيات الحماية المنزلية من كاميرات ذكية إلى أنظمة إنذار متكاملة.",
    category: "أخبار",
    date: "10 يناير 2025",
    readTime: "6 دقائق",
    comments: 8,
    image: "/images/blog-2.png",
  },
  {
    id: "b3",
    title: "أهمية كاميرات المراقبة في المنزل العصري",
    excerpt:
      "لماذا أصبحت كاميرات المراقبة ضرورة لكل منزل عصري وما الفوائد الأمنية والعملية.",
    category: "نصائح",
    date: "5 يناير 2025",
    readTime: "5 دقائق",
    comments: 5,
    image: "/images/blog-3.png",
  },
  {
    id: "b4",
    title: "نصائح لتوفير الطاقة بالألواح الشمسية",
    excerpt:
      "كيف ترفع كفاءة نظامك الشمسي وتوفر أكثر من 70% من فاتورة الكهرباء.",
    category: "طاقة",
    date: "2 يناير 2025",
    readTime: "7 دقائق",
    comments: 15,
    image: "/images/blog-4.png",
  },
] as const;
