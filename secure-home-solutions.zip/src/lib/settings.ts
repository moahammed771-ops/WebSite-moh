import { db } from "@/lib/db";
import { COMPANY } from "@/lib/site-data";

export type SettingType = "text" | "json" | "number" | "boolean";

export const DEFAULT_SETTINGS: Record<string, { value: string; type: SettingType }> = {
  "company.name": { value: COMPANY.name, type: "text" },
  "company.nameAr": { value: COMPANY.nameAr, type: "text" },
  "company.phone": { value: COMPANY.phone, type: "text" },
  "company.phoneRaw": { value: COMPANY.phoneRaw, type: "text" },
  "company.email": { value: COMPANY.email, type: "text" },
  "company.address": { value: COMPANY.address, type: "text" },
  "company.hours": { value: COMPANY.hours, type: "text" },
  "company.whatsapp": { value: COMPANY.whatsapp, type: "text" },
  "company.founded": { value: COMPANY.founded, type: "text" },
  "hero.badge": { value: "الأمان هو أولويتنا", type: "text" },
  "hero.title": { value: "حلول أمان منزلية متكاملة", type: "text" },
  "hero.desc": {
    value:
      "نقدم لك أفضل الحلول الأمنية المتكاملة بأعلى جودة وأسعار منافسة مع خدمة على مدار الساعة وفريق فني محترف.",
    type: "text",
  },
  "stats.projects": { value: "320", type: "number" },
  "stats.clients": { value: "280", type: "number" },
  "stats.experience": { value: "6", type: "number" },
  "stats.team": { value: "48", type: "number" },
  "social.facebook": { value: "#", type: "text" },
  "social.twitter": { value: "#", type: "text" },
  "social.instagram": { value: "#", type: "text" },
  "social.linkedin": { value: "#", type: "text" },
  "seo.title": {
    value: "Secure Home Solutions | حلول أمان منزلية متكاملة",
    type: "text",
  },
  "seo.description": {
    value:
      "شركة متخصصة في تصميم وتنفيذ أنظمة كاميرات المراقبة، أنظمة الإنتركم، أنظمة إنذار الحريق، وأنظمة الطاقة الشمسية",
    type: "text",
  },
};

export async function getSetting(key: string): Promise<string | null> {
  try {
    const row = await db.siteSetting.findUnique({ where: { key } });
    if (row) return row.value;
    return DEFAULT_SETTINGS[key]?.value ?? null;
  } catch {
    return DEFAULT_SETTINGS[key]?.value ?? null;
  }
}

export async function getAllSettings(): Promise<Record<string, string>> {
  const result: Record<string, string> = {};
  // start with defaults
  for (const [k, v] of Object.entries(DEFAULT_SETTINGS)) {
    result[k] = v.value;
  }
  try {
    const rows = await db.siteSetting.findMany();
    for (const r of rows) {
      result[r.key] = r.value;
    }
  } catch {
    // ignore — use defaults
  }
  return result;
}

export async function setSetting(key: string, value: string, type: SettingType = "text") {
  await db.siteSetting.upsert({
    where: { key },
    create: { key, value, type },
    update: { value, type },
  });
}

export async function setManySettings(items: Record<string, string>) {
  await Promise.all(
    Object.entries(items).map(([key, value]) => {
      const type = DEFAULT_SETTINGS[key]?.type ?? "text";
      return db.siteSetting.upsert({
        where: { key },
        create: { key, value, type },
        update: { value, type },
      });
    })
  );
}

export async function getStats() {
  const [quotes, subscribers, messages, projects, blogPosts, services, testimonials, team, faqs, chats] = await Promise.all([
    db.quoteRequest.count(),
    db.newsletterSubscriber.count({ where: { active: true } }),
    db.message.count({ where: { status: "new" } }),
    db.project.count(),
    db.blogPost.count({ where: { published: true } }),
    db.service.count(),
    db.testimonial.count({ where: { published: true } }),
    db.teamMember.count(),
    db.fAQ.count({ where: { published: true } }),
    db.chatLog.count(),
  ]);
  const newQuotes = await db.quoteRequest.count({ where: { status: "new" } });
  const chatSessions = await db.chatLog.groupBy({
    by: ["sessionId"],
    _count: true,
  });
  return {
    quotes,
    newQuotes,
    subscribers,
    messages,
    projects,
    blogPosts,
    services,
    testimonials,
    team,
    faqs,
    chats,
    chatSessions: chatSessions.length,
  };
}

export async function getRecentActivity(limit = 8) {
  const [quotes, messages, subs, chats] = await Promise.all([
    db.quoteRequest.findMany({
      orderBy: { createdAt: "desc" },
      take: 5,
      select: { id: true, name: true, service: true, status: true, createdAt: true },
    }),
    db.message.findMany({
      orderBy: { createdAt: "desc" },
      take: 5,
      select: { id: true, name: true, subject: true, status: true, createdAt: true },
    }),
    db.newsletterSubscriber.findMany({
      orderBy: { createdAt: "desc" },
      take: 5,
      select: { id: true, email: true, createdAt: true },
    }),
    db.chatLog.findMany({
      orderBy: { createdAt: "desc" },
      take: 5,
      select: { id: true, sessionId: true, role: true, content: true, createdAt: true },
    }),
  ]);
  return { quotes, messages, subs, chats };
}

// Get quotes grouped by service for the chart
export async function getQuotesByService() {
  const quotes = await db.quoteRequest.findMany({
    select: { service: true, createdAt: true },
  });
  const byService = new Map<string, number>();
  for (const q of quotes) {
    byService.set(q.service, (byService.get(q.service) || 0) + 1);
  }
  return Array.from(byService.entries())
    .map(([service, count]) => ({ service, count }))
    .sort((a, b) => b.count - a.count);
}

// Get quotes trend (last 7 days)
export async function getQuotesTrend() {
  const quotes = await db.quoteRequest.findMany({
    select: { createdAt: true },
    orderBy: { createdAt: "desc" },
    take: 500,
  });
  const days: { date: string; label: string; count: number }[] = [];
  const now = new Date();
  for (let i = 6; i >= 0; i--) {
    const d = new Date(now);
    d.setDate(d.getDate() - i);
    d.setHours(0, 0, 0, 0);
    const next = new Date(d);
    next.setDate(next.getDate() + 1);
    const count = quotes.filter(
      (q) => q.createdAt >= d && q.createdAt < next
    ).length;
    days.push({
      date: d.toISOString().slice(0, 10),
      label: d.toLocaleDateString("ar", { weekday: "short", day: "numeric" }),
      count,
    });
  }
  return days;
}

// Get quotes by status
export async function getQuotesByStatus() {
  const statuses = ["new", "contacted", "won", "lost"];
  const result: { status: string; count: number }[] = [];
  for (const s of statuses) {
    const count = await db.quoteRequest.count({ where: { status: s } });
    result.push({ status: s, count });
  }
  return result;
}
