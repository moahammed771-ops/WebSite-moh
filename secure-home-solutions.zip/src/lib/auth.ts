import { cookies } from "next/headers";
import { db } from "@/lib/db";
import crypto from "crypto";

const SESSION_COOKIE = "sh_admin_session";
const ADMIN_USERNAME = "admin";
const ADMIN_PASSWORD = "admin123"; // demo credentials

function hashPassword(pw: string): string {
  return crypto.createHash("sha256").update(pw).digest("hex");
}

export function verifyCredentials(username: string, password: string): boolean {
  return username === ADMIN_USERNAME && password === ADMIN_PASSWORD;
}

export async function createSession(username: string): Promise<string> {
  const token = crypto.randomBytes(32).toString("hex");
  // Persist session to DB so it survives server restarts
  try {
    await db.siteSetting.upsert({
      where: { key: `session:${token}` },
      create: {
        key: `session:${token}`,
        value: JSON.stringify({ username, createdAt: Date.now() }),
        type: "json",
      },
      update: {
        value: JSON.stringify({ username, createdAt: Date.now() }),
      },
    });
  } catch {
    // ignore DB errors
  }
  return token;
}

export async function getSession(token?: string): Promise<{ username: string } | null> {
  if (!token) return null;
  try {
    const row = await db.siteSetting.findUnique({
      where: { key: `session:${token}` },
    });
    if (!row) return null;
    const data = JSON.parse(row.value);
    // expire after 24h
    if (Date.now() - data.createdAt > 24 * 60 * 60 * 1000) {
      await db.siteSetting.delete({ where: { key: `session:${token}` } }).catch(() => {});
      return null;
    }
    return { username: data.username };
  } catch {
    return null;
  }
}

export async function destroySession(token?: string) {
  if (!token) return;
  try {
    await db.siteSetting.delete({ where: { key: `session:${token}` } });
  } catch {
    // ignore
  }
}

export async function getAuthToken(): Promise<string | undefined> {
  const store = await cookies();
  return store.get(SESSION_COOKIE)?.value;
}

export async function requireAdmin() {
  const token = await getAuthToken();
  const session = await getSession(token);
  if (!session) {
    throw new Error("UNAUTHORIZED");
  }
  return session;
}

export async function isAuthenticated(): Promise<boolean> {
  const token = await getAuthToken();
  return !!(await getSession(token));
}

export const SESSION_COOKIE_NAME = SESSION_COOKIE;
export const ADMIN_CREDENTIALS = {
  username: ADMIN_USERNAME,
  password: ADMIN_PASSWORD,
};

// Ensure a default admin exists in DB (for record)
export async function ensureAdminUser() {
  try {
    const existing = await db.adminUser.findUnique({
      where: { username: ADMIN_USERNAME },
    });
    if (!existing) {
      await db.adminUser.create({
        data: {
          username: ADMIN_USERNAME,
          password: hashPassword(ADMIN_PASSWORD),
          name: "مدير الموقع",
          role: "admin",
        },
      });
    }
  } catch {
    // ignore
  }
}
