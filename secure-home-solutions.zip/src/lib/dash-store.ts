"use client";

import { create } from "zustand";

export type DashPage =
  | "overview"
  | "quotes"
  | "messages"
  | "subscribers"
  | "chats"
  | "settings";

type DashState = {
  page: DashPage;
  setPage: (p: DashPage) => void;
  sidebarOpen: boolean;
  setSidebarOpen: (v: boolean) => void;
};

export const useDash = create<DashState>((set) => ({
  page: "overview",
  setPage: (page) => {
    set({ page, sidebarOpen: false });
    if (typeof window !== "undefined") window.scrollTo(0, 0);
  },
  sidebarOpen: false,
  setSidebarOpen: (sidebarOpen) => set({ sidebarOpen }),
}));
