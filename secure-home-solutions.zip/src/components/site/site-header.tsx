"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import { usePathname } from "next/navigation";
import {
  ShieldCheck,
  Phone,
  MapPin,
  Search,
  LogIn,
  Menu,
  X,
  ChevronLeft,
  Clock,
  LayoutDashboard,
} from "lucide-react";
import { COMPANY, NAV_LINKS } from "@/lib/site-data";
import { cn } from "@/lib/utils";
import { Button } from "@/components/ui/button";

export function SiteHeader({ onSearch }: { onSearch: () => void }) {
  const [scrolled, setScrolled] = useState(false);
  const [mobileOpen, setMobileOpen] = useState(false);
  const pathname = usePathname();

  // Active link based on the current route
  const isActive = (href: string) => {
    if (href === "/") return pathname === "/";
    return pathname === href || pathname.startsWith(href + "/");
  };

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 24);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  // Close the mobile menu whenever the route changes
  useEffect(() => {
    setMobileOpen(false);
  }, [pathname]);

  return (
    <header
      className={cn(
        "fixed inset-x-0 top-0 z-50 transition-all duration-300",
        scrolled
          ? "bg-ink/95 backdrop-blur-md shadow-lg shadow-black/20"
          : "bg-ink/80 backdrop-blur-sm"
      )}
    >
      {/* Top bar */}
      <div
        className={cn(
          "hidden md:block border-b border-white/10 transition-all duration-300",
          scrolled ? "h-0 overflow-hidden opacity-0" : "h-10 opacity-100"
        )}
      >
        <div className="container mx-auto flex h-10 max-w-7xl items-center justify-between px-4 text-xs text-white/70">
          <div className="flex items-center gap-5">
            <span className="flex items-center gap-1.5">
              <MapPin className="h-3.5 w-3.5 text-brand" />
              {COMPANY.address}
            </span>
            <span className="flex items-center gap-1.5">
              <Clock className="h-3.5 w-3.5 text-brand" />
              {COMPANY.hours}
            </span>
          </div>
          <div className="flex items-center gap-5">
            <span className="flex items-center gap-1.5">
              <ShieldCheck className="h-3.5 w-3.5 text-teal" />
              معتمدون من Hikvision ووكلاء Dahua
            </span>
            <a
              href={`tel:${COMPANY.phoneRaw}`}
              className="flex items-center gap-1.5 font-medium text-white transition-colors hover:text-brand"
              dir="ltr"
            >
              <Phone className="h-3.5 w-3.5 text-brand" />
              {COMPANY.phone}
            </a>
          </div>
        </div>
      </div>

      {/* Main nav */}
      <div className="container mx-auto flex h-16 max-w-7xl items-center justify-between px-4 md:h-20">
        {/* Logo */}
        <Link href="/" className="flex items-center gap-3 shrink-0">
          <span className="relative grid h-11 w-11 place-items-center rounded-xl bg-gradient-to-br from-brand to-brand-dark shadow-lg shadow-brand/30">
            <ShieldCheck className="h-6 w-6 text-white" />
            <span className="absolute -bottom-1 -left-1 h-3 w-3 rounded-full bg-teal ring-2 ring-ink" />
          </span>
          <span className="flex flex-col leading-tight">
            <span className="text-lg font-extrabold tracking-tight text-white">
              Secure <span className="text-brand">Home</span>
            </span>
            <span className="text-[10px] font-medium uppercase tracking-[0.25em] text-white/50">
              SOLUTIONS
            </span>
          </span>
        </Link>

        {/* Desktop nav */}
        <nav className="hidden lg:flex items-center gap-1">
          {NAV_LINKS.map((link) => (
            <Link
              key={link.href}
              href={link.href}
              className={cn(
                "relative rounded-lg px-3.5 py-2 text-sm font-medium transition-colors",
                isActive(link.href)
                  ? "text-white"
                  : "text-white/70 hover:text-white"
              )}
            >
              {link.label}
              {isActive(link.href) && (
                <span className="absolute inset-x-3 -bottom-0.5 h-0.5 rounded-full bg-brand" />
              )}
            </Link>
          ))}
        </nav>

        {/* Actions */}
        <div className="flex items-center gap-2">
          <button
            onClick={onSearch}
            className="hidden md:flex items-center gap-2 rounded-lg border border-white/15 bg-white/5 px-3 py-2 text-xs text-white/60 transition-colors hover:border-brand/50 hover:text-white"
          >
            <Search className="h-4 w-4" />
            <span>بحث في الموقع</span>
            <kbd className="rounded bg-white/10 px-1.5 py-0.5 text-[10px] font-mono">
              ⌘K
            </kbd>
          </button>

          <Button
            asChild
            variant="ghost"
            className="hidden md:flex text-white/80 hover:text-white hover:bg-white/10"
            onClick={() => setMobileOpen(false)}
          >
            <Link href="/#dashboard">
              <LayoutDashboard className="ml-1.5 h-4 w-4" />
              لوحة التحكم
            </Link>
          </Button>
          <Button
            asChild
            variant="ghost"
            className="hidden md:flex text-white/80 hover:text-white hover:bg-white/10"
          >
            <Link href="/#dashboard">
              <LogIn className="ml-1.5 h-4 w-4" />
              دخول
            </Link>
          </Button>

          <Button
            asChild
            className="hidden md:inline-flex bg-brand text-white shadow-lg shadow-brand/30 hover:bg-brand-dark"
          >
            <Link href="/contact">
              تواصل معنا الآن
              <ChevronLeft className="mr-1 h-4 w-4" />
            </Link>
          </Button>

          {/* Mobile toggle */}
          <button
            onClick={() => setMobileOpen((v) => !v)}
            className="grid h-10 w-10 place-items-center rounded-lg bg-white/10 text-white lg:hidden"
            aria-label="القائمة"
          >
            {mobileOpen ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
          </button>
        </div>
      </div>

      {/* Mobile menu */}
      <div
        className={cn(
          "lg:hidden overflow-hidden border-t border-white/10 bg-ink/98 backdrop-blur-md transition-all duration-300",
          mobileOpen ? "max-h-[520px]" : "max-h-0"
        )}
      >
        <nav className="container mx-auto flex max-w-7xl flex-col gap-1 px-4 py-4">
          {NAV_LINKS.map((link) => (
            <Link
              key={link.href}
              href={link.href}
              onClick={() => setMobileOpen(false)}
              className="flex items-center justify-between rounded-lg px-3 py-3 text-sm font-medium text-white/80 transition-colors hover:bg-white/5 hover:text-white"
            >
              {link.label}
              <ChevronLeft className="h-4 w-4 text-white/30" />
            </Link>
          ))}
          <div className="mt-3 flex flex-col gap-2 border-t border-white/10 pt-3">
            <Link
              href="/#dashboard"
              onClick={() => setMobileOpen(false)}
              className="flex items-center gap-2 rounded-lg bg-white/5 px-3 py-3 text-sm font-medium text-white/80 transition-colors hover:bg-white/10 hover:text-white"
            >
              <LayoutDashboard className="h-4 w-4 text-brand" />
              لوحة التحكم
              <ChevronLeft className="mr-auto h-4 w-4 text-white/30" />
            </Link>
            <a
              href={`tel:${COMPANY.phoneRaw}`}
              className="flex items-center gap-2 px-3 py-2 text-sm text-white/80"
              dir="ltr"
            >
              <Phone className="h-4 w-4 text-brand" />
              {COMPANY.phone}
            </a>
            <Button
              asChild
              className="bg-brand text-white hover:bg-brand-dark"
              onClick={() => setMobileOpen(false)}
            >
              <Link href="/contact">تواصل معنا الآن</Link>
            </Button>
          </div>
        </nav>
      </div>
    </header>
  );
}
