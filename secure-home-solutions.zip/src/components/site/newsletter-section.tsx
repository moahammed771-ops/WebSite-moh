"use client";

import { useState } from "react";
import { Mail, Send, Loader2, CheckCircle2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useToast } from "@/hooks/use-toast";

export function NewsletterSection() {
  const [loading, setLoading] = useState(false);
  const [done, setDone] = useState(false);
  const { toast } = useToast();

  async function onSubmit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    setLoading(true);
    const fd = new FormData(e.currentTarget);
    try {
      const res = await fetch("/api/newsletter", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email: fd.get("email") }),
      });
      if (!res.ok) throw new Error("failed");
      setDone(true);
      toast({ title: "تم الاشتراك بنجاح", description: "شكراً لاشتراكك في نشرتنا البريدية." });
    } catch {
      toast({ variant: "destructive", title: "تعذّر الاشتراك", description: "حاول مرة أخرى لاحقاً." });
    } finally {
      setLoading(false);
    }
  }

  return (
    <section className="relative bg-white py-16">
      <div className="container mx-auto max-w-7xl px-4">
        <div className="relative overflow-hidden rounded-3xl bg-gradient-to-l from-brand to-brand-dark p-8 shadow-2xl md:p-12">
          <div className="absolute inset-0 grid-pattern opacity-20" />
          <div className="absolute -top-16 -left-16 h-56 w-56 rounded-full bg-white/10 blur-2xl" />
          <div className="absolute -bottom-16 -right-16 h-56 w-56 rounded-full bg-gold/20 blur-2xl" />
          <div className="relative grid items-center gap-6 md:grid-cols-2">
            <div>
              <div className="inline-flex items-center gap-2 rounded-full bg-white/15 px-4 py-1.5 text-sm font-medium text-white backdrop-blur-sm">
                <Mail className="h-4 w-4" />
                النشرة البريدية
              </div>
              <h2 className="mt-4 text-2xl font-extrabold leading-tight text-white sm:text-3xl">
                اشترك في نشرتنا البريدية
              </h2>
              <p className="mt-2 text-sm text-white/85 sm:text-base">
                كن أول من يعرف عن أحدث العروض والمنتجات ونصائح الأمان.
              </p>
            </div>
            <div>
              {done ? (
                <div className="flex items-center gap-3 rounded-2xl bg-white/15 p-5 text-white backdrop-blur-sm">
                  <CheckCircle2 className="h-8 w-8 shrink-0" />
                  <div>
                    <div className="font-bold">تم الاشتراك!</div>
                    <div className="text-sm text-white/80">
                      ستصلك آخر المستجدات على بريدك.
                    </div>
                  </div>
                </div>
              ) : (
                <form
                  onSubmit={onSubmit}
                  className="flex flex-col gap-3 sm:flex-row"
                >
                  <Input
                    name="email"
                    type="email"
                    required
                    placeholder="بريدك الإلكتروني"
                    dir="ltr"
                    className="h-12 border-white/20 bg-white/95 text-ink placeholder:text-muted-foreground"
                  />
                  <Button
                    type="submit"
                    disabled={loading}
                    size="lg"
                    className="h-12 shrink-0 bg-ink text-white shadow-lg hover:bg-ink/90"
                  >
                    {loading ? (
                      <Loader2 className="h-5 w-5 animate-spin" />
                    ) : (
                      <>
                        اشترك
                        <Send className="mr-2 h-4 w-4" />
                      </>
                    )}
                  </Button>
                </form>
              )}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
