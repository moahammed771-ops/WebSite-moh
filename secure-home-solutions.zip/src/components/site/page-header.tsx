import Link from "next/link";
import { ChevronLeft, Home } from "lucide-react";
import { cn } from "@/lib/utils";

export type BreadcrumbItem = { label: string; href?: string };

type PageHeaderProps = {
  title: string;
  /** Word/phrase inside the title to render with the brand gradient. */
  highlight?: string;
  subtitle?: string;
  eyebrow?: string;
  breadcrumb?: BreadcrumbItem[];
  className?: string;
};

/**
 * PageHeader — reusable dark banner for inner pages.
 * Ink background with grid pattern, eyebrow badge, big gradient title,
 * subtitle and a breadcrumb trail.
 */
export function PageHeader({
  title,
  highlight,
  subtitle,
  eyebrow,
  breadcrumb,
  className,
}: PageHeaderProps) {
  const renderTitle = () => {
    if (!highlight) return title;
    const parts = title.split(highlight);
    return parts.map((part, idx, arr) => (
      <span key={idx}>
        {part}
        {idx < arr.length - 1 && (
          <span className="text-gradient-brand">{highlight}</span>
        )}
      </span>
    ));
  };

  return (
    <section
      className={cn(
        "relative overflow-hidden bg-ink pt-32 pb-16 md:pt-40 md:pb-24",
        className
      )}
    >
      <div className="absolute inset-0 grid-pattern-dark opacity-40" />
      <div className="absolute -top-32 right-1/4 h-80 w-80 rounded-full bg-brand/15 blur-[120px]" />
      <div className="absolute -bottom-32 left-1/4 h-80 w-80 rounded-full bg-teal/10 blur-[120px]" />

      <div className="container relative mx-auto max-w-7xl px-4 text-center">
        {eyebrow && (
          <div className="inline-flex items-center gap-2 rounded-full border border-brand/30 bg-brand/10 px-4 py-1.5 text-sm font-medium text-brand backdrop-blur-sm">
            <span className="h-1.5 w-1.5 rounded-full bg-brand" />
            {eyebrow}
          </div>
        )}

        <h1 className="mt-5 text-4xl font-extrabold leading-[1.15] tracking-tight text-white sm:text-5xl lg:text-6xl">
          {renderTitle()}
        </h1>

        {subtitle && (
          <p className="mx-auto mt-5 max-w-2xl text-base leading-relaxed text-white/70 sm:text-lg">
            {subtitle}
          </p>
        )}

        {breadcrumb && breadcrumb.length > 0 && (
          <nav
            aria-label="breadcrumb"
            className="mt-7 flex items-center justify-center"
          >
            <ol className="flex flex-wrap items-center gap-1.5 text-sm">
              <li>
                <Link
                  href="/"
                  className="flex items-center gap-1 text-white/60 transition-colors hover:text-brand"
                >
                  <Home className="h-3.5 w-3.5" />
                  الرئيسية
                </Link>
              </li>
              {breadcrumb.map((item, i) => {
                const isLast = i === breadcrumb.length - 1;
                return (
                  <li key={i} className="flex items-center gap-1.5">
                    <ChevronLeft className="h-3.5 w-3.5 text-white/30" />
                    {item.href && !isLast ? (
                      <Link
                        href={item.href}
                        className="text-white/60 transition-colors hover:text-brand"
                      >
                        {item.label}
                      </Link>
                    ) : (
                      <span className="font-medium text-brand">{item.label}</span>
                    )}
                  </li>
                );
              })}
            </ol>
          </nav>
        )}
      </div>

      {/* Bottom wave */}
      <div className="absolute bottom-0 left-0 right-0">
        <svg viewBox="0 0 1440 60" className="w-full" preserveAspectRatio="none">
          <path d="M0 60 L0 30 Q 360 0 720 30 T 1440 30 L1440 60 Z" fill="#ffffff" />
        </svg>
      </div>
    </section>
  );
}
