"use client";

import Link from "next/link";
import { ShieldCheck, ChevronLeft, CheckCircle2 } from "lucide-react";
import { COMPANY, ABOUT_BADGES, STATS_PRIMARY } from "@/lib/site-data";
import { useReveal, useCountUp } from "@/hooks/use-reveal";
import { Button } from "@/components/ui/button";

function StatItem({
  icon: Icon,
  value,
  suffix,
  label,
}: {
  icon: typeof ShieldCheck;
  value: number;
  suffix: string;
  label: string;
}) {
  const { ref, value: v } = useCountUp(value);
  return (
    <div className="group relative overflow-hidden rounded-2xl border border-border bg-white p-5 text-center shadow-sm transition-all hover:-translate-y-1 hover:border-brand/30 hover:shadow-xl hover:shadow-brand/10">
      <div className="absolute -right-6 -top-6 h-20 w-20 rounded-full bg-brand/5 transition-transform group-hover:scale-150" />
      <span className="relative mx-auto grid h-12 w-12 place-items-center rounded-xl bg-brand/10 text-brand">
        <Icon className="h-6 w-6" />
      </span>
      <div className="relative mt-3 flex items-baseline justify-center gap-0.5">
        <span
          ref={ref}
          className="text-3xl font-extrabold text-ink sm:text-4xl"
        >
          {v}
        </span>
        <span className="text-2xl font-extrabold text-brand">{suffix}</span>
      </div>
      <div className="relative mt-1 text-sm font-medium text-muted-foreground">
        {label}
      </div>
    </div>
  );
}

export function AboutSection() {
  const { ref, inView } = useReveal();

  return (
    <section id="about" className="relative bg-white py-20 md:py-28">
      <div className="container mx-auto max-w-7xl px-4">
        <div
          ref={ref}
          className={`reveal ${inView ? "in-view" : ""} grid items-center gap-12 lg:grid-cols-2`}
        >
          {/* Visual side */}
          <div className="relative">
            <div className="relative overflow-hidden rounded-3xl bg-gradient-to-br from-ink to-[#16233a] p-8 shadow-2xl">
              <div className="absolute inset-0 grid-pattern-dark opacity-30" />
              <div className="relative">
                <div className="inline-flex items-center gap-2 rounded-full border border-brand/30 bg-brand/10 px-3 py-1 text-xs font-medium text-brand">
                  <ShieldCheck className="h-3.5 w-3.5" />
                  من نحن
                </div>
                <h3 className="mt-5 text-2xl font-bold leading-snug text-white">
                  شريكك الموثوق في حلول الأمان والحماية
                </h3>
                <div className="mt-6 space-y-3">
                  {ABOUT_BADGES.map((b) => (
                    <div
                      key={b.label}
                      className="flex items-center gap-3 rounded-xl border border-white/10 bg-white/5 p-3 backdrop-blur-sm"
                    >
                      <span className="grid h-10 w-10 shrink-0 place-items-center rounded-lg bg-brand/20 text-brand">
                        <b.icon className="h-5 w-5" />
                      </span>
                      <span className="text-sm font-medium text-white/90">
                        {b.label}
                      </span>
                      <CheckCircle2 className="mr-auto h-5 w-5 text-teal" />
                    </div>
                  ))}
                </div>
              </div>
            </div>

            {/* Floating accent */}
            <div className="absolute -bottom-6 -left-6 hidden rounded-2xl bg-brand p-5 text-white shadow-xl sm:block">
              <div className="text-3xl font-extrabold">+{6}</div>
              <div className="text-xs font-medium text-white/80">سنوات خبرة</div>
            </div>
          </div>

          {/* Text side */}
          <div>
            <div className="inline-flex items-center gap-2 rounded-full bg-brand/10 px-4 py-1.5 text-sm font-medium text-brand">
              <span className="h-1.5 w-1.5 rounded-full bg-brand" />
              من نحن
            </div>
            <h2 className="mt-4 text-3xl font-extrabold leading-tight text-ink sm:text-4xl lg:text-5xl">
              شريكك الموثوق في{" "}
              <span className="text-gradient-brand">حلول الأمان</span>
            </h2>
            <p className="mt-5 text-base leading-relaxed text-muted-foreground sm:text-lg">
              نحن شركة رائدة متخصصة في تصميم وتنفيذ أنظمة الأمان والحماية بأعلى
              المعايير العالمية. نقدم حلولاً شاملة تشمل كاميرات المراقبة، أنظمة
              الإنتركم، إنذار الحريق، وأنظمة الطاقة الشمسية. مع فريق من المهندسين
              والفنيين المعتمدين، نضمن لك تركيباً احترافياً ودعماً فنياً على مدار
              الساعة.
            </p>
            <p className="mt-4 text-base leading-relaxed text-muted-foreground">
              نستخدم أحدث التقنيات من أفضل الشركات المصنعة عالمياً لنقدم لك أفضل
              حلول الأمان. معتمدون من Hikvision ووكلاء Dahua المعتمدون.
            </p>

            <div className="mt-7 flex flex-wrap gap-3">
              <Button
                asChild
                className="bg-brand text-white shadow-lg shadow-brand/30 hover:bg-brand-dark"
              >
                <Link href="/services">
                  اكتشف خدماتنا
                  <ChevronLeft className="mr-1 h-4 w-4" />
                </Link>
              </Button>
              <Button asChild variant="outline">
                <Link href="/about">مسيرة النجاح</Link>
              </Button>
            </div>
          </div>
        </div>

        {/* Stats */}
        <div className="mt-16 grid grid-cols-1 gap-4 sm:grid-cols-3">
          {STATS_PRIMARY.map((s) => (
            <StatItem key={s.label} {...s} />
          ))}
        </div>
      </div>
    </section>
  );
}
