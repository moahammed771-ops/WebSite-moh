"use client";

import Link from "next/link";
import { ArrowLeft, PhoneCall, MessageCircle } from "lucide-react";
import { COMPANY } from "@/lib/site-data";
import { Button } from "@/components/ui/button";

type CtaBandProps = {
  title?: string;
  highlight?: string;
  desc?: string;
  primaryLabel?: string;
  primaryHref?: string;
  secondaryLabel?: string;
  secondaryHref?: string;
};

/**
 * CtaBand — compact reusable call-to-action band for inner pages.
 * Dark ink background with brand/teal glows and two action buttons.
 */
export function CtaBand({
  title = "هل أنت مستعد لتأمين ممتلكاتك؟",
  highlight = "تأمين",
  desc = "تواصل معنا اليوم واحصل على استشارة مجانية من فريقنا من المهندسين المعتمدين. نقدم لك الحل الأمثل لاحتياجاتك بأفضل الأسعار.",
  primaryLabel = "اطلب عرض سعر مجاني",
  primaryHref = "/contact",
  secondaryLabel = "اتصل بنا الآن",
}: CtaBandProps) {
  const renderTitle = () => {
    if (!highlight) return title;
    const parts = title.split(highlight);
    return parts.map((part, idx, arr) => (
      <span key={idx}>
        {part}
        {idx < arr.length - 1 && (
          <span className="text-gradient-brand">{highlight}</span>
        )}
      </span>
    ));
  };

  return (
    <section className="relative overflow-hidden bg-ink py-16 md:py-20">
      <div className="absolute inset-0 grid-pattern-dark opacity-40" />
      <div className="absolute -top-24 right-1/4 h-72 w-72 rounded-full bg-brand/20 blur-[120px]" />
      <div className="absolute -bottom-24 left-1/4 h-72 w-72 rounded-full bg-teal/15 blur-[120px]" />

      <div className="container relative mx-auto max-w-4xl px-4 text-center">
        <h2 className="text-3xl font-extrabold leading-tight text-white sm:text-4xl lg:text-5xl">
          {renderTitle()}
        </h2>
        <p className="mx-auto mt-4 max-w-2xl text-base leading-relaxed text-white/70 sm:text-lg">
          {desc}
        </p>
        <div className="mt-8 flex flex-wrap items-center justify-center gap-3">
          <Button
            asChild
            size="lg"
            className="bg-brand text-white shadow-xl shadow-brand/30 hover:bg-brand-dark"
          >
            <Link href={primaryHref}>
              {primaryLabel}
              <ArrowLeft className="mr-1 h-4 w-4" />
            </Link>
          </Button>
          <Button
            asChild
            size="lg"
            variant="outline"
            className="border-white/25 bg-white/5 text-white backdrop-blur-sm hover:bg-white/10 hover:text-white"
          >
            <a href={`tel:${COMPANY.phoneRaw}`} dir="ltr">
              <PhoneCall className="ml-1.5 h-4 w-4" />
              {secondaryLabel}
            </a>
          </Button>
        </div>

        <div className="mt-6 flex flex-wrap items-center justify-center gap-x-6 gap-y-2 text-xs text-white/50">
          <span className="flex items-center gap-1.5">
            <MessageCircle className="h-3.5 w-3.5 text-teal" />
            دعم فني على مدار الساعة
          </span>
          <span className="flex items-center gap-1.5">
            <PhoneCall className="h-3.5 w-3.5 text-brand" />
            {COMPANY.phone}
          </span>
          <span>ضمان رسمي حتى 5 سنوات</span>
        </div>
      </div>
    </section>
  );
}
