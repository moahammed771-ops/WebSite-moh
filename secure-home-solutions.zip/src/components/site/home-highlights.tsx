"use client";

import Link from "next/link";
import Image from "next/image";
import { ArrowLeft, ChevronLeft, Star, Quote, Compass } from "lucide-react";
import {
  EXPLORE_PAGES,
  SERVICES,
  WHY_US,
  TESTIMONIALS,
} from "@/lib/site-data";
import { useReveal } from "@/hooks/use-reveal";
import { cn } from "@/lib/utils";
import { Button } from "@/components/ui/button";

/* ============ استكشاف الصفحات ============ */
export function ExplorePagesSection() {
  const { ref, inView } = useReveal();

  return (
    <section
      id="explore"
      className="relative bg-gradient-to-b from-white to-[#fff7f1] py-20 md:py-28"
    >
      <div className="container mx-auto max-w-7xl px-4">
        <div className="mx-auto max-w-2xl text-center">
          <div className="inline-flex items-center gap-2 rounded-full bg-brand/10 px-4 py-1.5 text-sm font-medium text-brand">
            <Compass className="h-3.5 w-3.5" />
            استكشف الموقع
          </div>
          <h2 className="mt-4 text-3xl font-extrabold leading-tight text-ink sm:text-4xl lg:text-5xl">
            تصفّح <span className="text-gradient-brand">صفحاتنا</span>
          </h2>
          <p className="mt-4 text-base text-muted-foreground sm:text-lg">
            كل ما تحتاجه عن شركة Secure Home Solutions وحلول الأمان المتكاملة في
            مكان واحد — اختر الصفحة التي تهمك.
          </p>
        </div>

        <div
          ref={ref}
          className={cn(
            "reveal mt-14 grid gap-6 sm:grid-cols-2 lg:grid-cols-3",
            inView && "in-view"
          )}
        >
          {EXPLORE_PAGES.map((p, i) => (
            <Link
              key={p.href}
              href={p.href}
              className="group relative flex flex-col overflow-hidden rounded-3xl border border-border bg-white p-7 shadow-sm transition-all hover:-translate-y-2 hover:shadow-2xl"
              style={{ transitionDelay: `${i * 60}ms` }}
            >
              <div
                className="absolute -left-12 -top-12 h-40 w-40 rounded-full opacity-10 blur-2xl transition-opacity group-hover:opacity-30"
                style={{ background: p.accent }}
              />
              <div className="relative flex items-center justify-between">
                <span
                  className="grid h-16 w-16 place-items-center rounded-2xl text-white shadow-lg transition-transform group-hover:scale-110 group-hover:-rotate-6"
                  style={{
                    background: `linear-gradient(135deg, ${p.accent}, ${p.accent}cc)`,
                    boxShadow: `0 12px 30px -8px ${p.accent}66`,
                  }}
                >
                  <p.icon className="h-8 w-8" />
                </span>
                <ArrowLeft className="h-5 w-5 text-muted-foreground transition-all group-hover:translate-x-[-4px] group-hover:text-brand" />
              </div>
              <h3 className="relative mt-5 text-xl font-extrabold text-ink">
                {p.title}
              </h3>
              <p className="relative mt-2 flex-1 text-sm leading-relaxed text-muted-foreground">
                {p.desc}
              </p>
              <span
                className="relative mt-5 inline-flex items-center gap-1 text-sm font-bold"
                style={{ color: p.accent }}
              >
                عرض الصفحة
                <ChevronLeft className="h-4 w-4 transition-transform group-hover:-translate-x-1" />
              </span>
            </Link>
          ))}
        </div>
      </div>
    </section>
  );
}

/* ============ معاينة الخدمات (3 بطاقات) ============ */
export function ServicesPreview() {
  const { ref, inView } = useReveal();
  const items = SERVICES.slice(0, 3);

  return (
    <section id="services-preview" className="relative bg-white py-20 md:py-28">
      <div className="container mx-auto max-w-7xl px-4">
        <div className="mx-auto max-w-2xl text-center">
          <div className="inline-flex items-center gap-2 rounded-full bg-brand/10 px-4 py-1.5 text-sm font-medium text-brand">
            <span className="h-1.5 w-1.5 rounded-full bg-brand" />
            خدماتنا
          </div>
          <h2 className="mt-4 text-3xl font-extrabold leading-tight text-ink sm:text-4xl lg:text-5xl">
            حلول أمان <span className="text-gradient-brand">متكاملة</span>
          </h2>
          <p className="mt-4 text-base text-muted-foreground sm:text-lg">
            نقدم مجموعة شاملة من خدمات الأمان والطاقة المصممة بأحدث التقنيات
            العالمية.
          </p>
        </div>

        <div
          ref={ref}
          className={cn(
            "reveal mt-14 grid gap-6 md:grid-cols-3",
            inView && "in-view"
          )}
        >
          {items.map((s, i) => (
            <Link
              key={s.id}
              href={`/services/${s.id}`}
              className="group relative flex flex-col overflow-hidden rounded-3xl border border-border bg-white shadow-sm transition-all hover:-translate-y-2 hover:shadow-2xl"
              style={{ transitionDelay: `${i * 80}ms` }}
            >
              <div className="relative h-44 overflow-hidden bg-ink">
                <Image
                  src={s.image}
                  alt={s.title}
                  fill
                  sizes="(max-width: 768px) 100vw, 33vw"
                  className="object-cover transition-transform duration-700 group-hover:scale-110"
                />
                <div
                  className="absolute inset-0 opacity-60 mix-blend-multiply"
                  style={{
                    background: `linear-gradient(135deg, ${s.accent}99, transparent 60%)`,
                  }}
                />
                <span
                  className="absolute top-4 right-4 grid h-12 w-12 place-items-center rounded-xl text-white shadow-lg"
                  style={{ backgroundColor: `${s.accent}e6` }}
                >
                  <s.icon className="h-6 w-6" />
                </span>
                <span className="absolute bottom-4 right-4 text-5xl font-black text-white/30">
                  {s.num}
                </span>
              </div>
              <div className="flex flex-1 flex-col p-6">
                <h3 className="text-xl font-extrabold text-ink">{s.title}</h3>
                <p className="mt-2 flex-1 text-sm leading-relaxed text-muted-foreground">
                  {s.desc}
                </p>
                <span
                  className="mt-4 inline-flex items-center gap-1 text-sm font-bold"
                  style={{ color: s.accent }}
                >
                  عرض التفاصيل
                  <ChevronLeft className="h-4 w-4 transition-transform group-hover:-translate-x-1" />
                </span>
              </div>
            </Link>
          ))}
        </div>

        <div className="mt-10 text-center">
          <Button
            asChild
            size="lg"
            variant="outline"
            className="border-brand/30 text-brand hover:bg-brand hover:text-white"
          >
            <Link href="/services">
              عرض جميع الخدمات
              <ArrowLeft className="mr-1 h-4 w-4" />
            </Link>
          </Button>
        </div>
      </div>
    </section>
  );
}

/* ============ معاينة لماذا نحن (3 بطاقات) ============ */
export function WhyUsPreview() {
  const { ref, inView } = useReveal();
  const items = WHY_US.slice(0, 3);

  return (
    <section
      id="why-us-preview"
      className="relative bg-gradient-to-b from-[#fff7f1] to-white py-20 md:py-28"
    >
      <div className="container mx-auto max-w-7xl px-4">
        <div className="mx-auto max-w-2xl text-center">
          <div className="inline-flex items-center gap-2 rounded-full bg-brand/10 px-4 py-1.5 text-sm font-medium text-brand">
            <Star className="h-3.5 w-3.5" />
            لماذا نحن
          </div>
          <h2 className="mt-4 text-3xl font-extrabold leading-tight text-ink sm:text-4xl lg:text-5xl">
            لماذا يختارنا <span className="text-gradient-brand">العملاء؟</span>
          </h2>
          <p className="mt-4 text-base text-muted-foreground sm:text-lg">
            نجمع بين الخبرة والتقنية والأسعار المنافسة لنقدم لك تجربة أمان
            استثنائية.
          </p>
        </div>

        <div
          ref={ref}
          className={cn(
            "reveal mt-14 grid gap-6 md:grid-cols-3",
            inView && "in-view"
          )}
        >
          {items.map((item, i) => (
            <div
              key={item.title}
              className="group relative overflow-hidden rounded-2xl border border-border bg-white p-6 shadow-sm transition-all hover:-translate-y-1.5 hover:shadow-xl"
              style={{ transitionDelay: `${i * 60}ms` }}
            >
              <div
                className="absolute -left-10 -top-10 h-32 w-32 rounded-full opacity-10 blur-2xl transition-opacity group-hover:opacity-30"
                style={{ background: item.color }}
              />
              <div className="relative flex items-start gap-4">
                <span
                  className="grid h-14 w-14 shrink-0 place-items-center rounded-2xl text-white shadow-lg transition-transform group-hover:scale-110 group-hover:-rotate-6"
                  style={{
                    background: `linear-gradient(135deg, ${item.color}, ${item.color}cc)`,
                    boxShadow: `0 10px 28px -8px ${item.color}66`,
                  }}
                >
                  <item.icon className="h-7 w-7" />
                </span>
                <div className="flex-1">
                  <h3 className="text-lg font-bold text-ink">{item.title}</h3>
                  <p className="mt-1.5 text-sm leading-relaxed text-muted-foreground">
                    {item.desc}
                  </p>
                </div>
              </div>
            </div>
          ))}
        </div>

        <div className="mt-10 text-center">
          <Button asChild size="lg" variant="outline">
            <Link href="/about">
              تعرّف علينا أكثر
              <ArrowLeft className="mr-1 h-4 w-4" />
            </Link>
          </Button>
        </div>
      </div>
    </section>
  );
}

/* ============ معاينة آراء العملاء (3 بطاقات) ============ */
export function TestimonialsPreview() {
  const { ref, inView } = useReveal();
  const items = TESTIMONIALS.slice(0, 3);

  return (
    <section
      id="testimonials-preview"
      className="relative overflow-hidden bg-gradient-to-b from-white to-[#fff7f1] py-20 md:py-28"
    >
      <div className="container mx-auto max-w-7xl px-4">
        <div className="mx-auto max-w-2xl text-center">
          <div className="inline-flex items-center gap-2 rounded-full bg-brand/10 px-4 py-1.5 text-sm font-medium text-brand">
            <Star className="h-3.5 w-3.5" />
            آراء العملاء
          </div>
          <h2 className="mt-4 text-3xl font-extrabold leading-tight text-ink sm:text-4xl lg:text-5xl">
            ماذا يقول <span className="text-gradient-brand">عملاؤنا؟</span>
          </h2>
          <p className="mt-4 text-base text-muted-foreground sm:text-lg">
            ثقة عملائنا هي أكبر إنجازاتنا. إليك بعض تجاربهم الحقيقية معنا.
          </p>
        </div>

        <div className="mt-8 flex flex-wrap items-center justify-center gap-4">
          <div className="flex items-center gap-3 rounded-2xl border border-border bg-white px-6 py-3 shadow-sm">
            <div className="flex items-center gap-0.5">
              {[...Array(5)].map((_, i) => (
                <Star key={i} className="h-5 w-5 fill-gold text-gold" />
              ))}
            </div>
            <div className="text-sm">
              <span className="font-bold text-ink">4.9/5</span>
              <span className="text-muted-foreground"> من +280 تقييم</span>
            </div>
          </div>
          <div className="flex items-center gap-3 rounded-2xl border border-border bg-white px-6 py-3 text-sm shadow-sm">
            <span className="font-bold text-ink">99%</span>
            <span className="text-muted-foreground">رضا العملاء</span>
          </div>
        </div>

        <div
          ref={ref}
          className={cn(
            "reveal mt-12 grid gap-6 md:grid-cols-3",
            inView && "in-view"
          )}
        >
          {items.map((t, i) => (
            <div
              key={t.id}
              className="group relative flex flex-col rounded-3xl border border-border bg-white p-6 shadow-sm transition-all hover:-translate-y-1.5 hover:shadow-xl"
              style={{ transitionDelay: `${i * 60}ms` }}
            >
              <Quote
                className="absolute -top-3 left-6 h-10 w-10 rotate-180"
                style={{ color: `${t.color}22` }}
              />
              <div className="relative flex items-center gap-1">
                {[...Array(t.rating)].map((_, j) => (
                  <Star key={j} className="h-4 w-4 fill-gold text-gold" />
                ))}
              </div>
              <p className="relative mt-4 flex-1 text-sm leading-relaxed text-foreground/85">
                &ldquo;{t.text}&rdquo;
              </p>
              <div className="mt-5 flex items-center gap-3 border-t border-border pt-4">
                <span
                  className="grid h-12 w-12 shrink-0 place-items-center rounded-full text-sm font-bold text-white shadow-lg"
                  style={{
                    background: `linear-gradient(135deg, ${t.color}, ${t.color}cc)`,
                  }}
                >
                  {t.initials}
                </span>
                <div>
                  <div className="font-bold text-ink">{t.name}</div>
                  <div className="text-xs text-muted-foreground">{t.role}</div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
