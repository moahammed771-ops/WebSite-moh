"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import { Cookie, X, Settings, Check } from "lucide-react";
import { Button } from "@/components/ui/button";

const STORAGE_KEY = "sh-cookie-consent";

export function CookieBanner() {
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    const consent = localStorage.getItem(STORAGE_KEY);
    if (!consent) {
      const t = setTimeout(() => setVisible(true), 1500);
      return () => clearTimeout(t);
    }
  }, []);

  function accept() {
    localStorage.setItem(STORAGE_KEY, "accepted");
    setVisible(false);
  }
  function reject() {
    localStorage.setItem(STORAGE_KEY, "rejected");
    setVisible(false);
  }

  if (!visible) return null;

  return (
    <div className="fixed inset-x-4 bottom-4 z-40 mx-auto max-w-3xl animate-slide-fade-in">
      <div className="flex flex-col gap-4 rounded-2xl border border-border bg-white p-5 shadow-2xl sm:flex-row sm:items-center">
        <span className="grid h-12 w-12 shrink-0 place-items-center rounded-xl bg-brand/10 text-brand">
          <Cookie className="h-6 w-6" />
        </span>
        <p className="flex-1 text-sm leading-relaxed text-muted-foreground">
          نستخدم ملفات تعريف الارتباط (الكوكيز) لتحسين تجربتك على موقعنا. باستخدامك
          لموقعنا، فإنك توافق على استخدامنا لها.{" "}
          <Link href="#" className="font-medium text-brand hover:underline">
            اقرأ المزيد
          </Link>
        </p>
        <div className="flex shrink-0 items-center gap-2">
          <Button
            size="sm"
            variant="outline"
            onClick={reject}
            className="border-border text-muted-foreground"
          >
            <Settings className="ml-1 h-3.5 w-3.5" />
            الإعدادات
          </Button>
          <Button size="sm" onClick={accept} className="bg-brand text-white hover:bg-brand-dark">
            <Check className="ml-1 h-3.5 w-3.5" />
            قبول
          </Button>
          <button
            onClick={reject}
            aria-label="إغلاق"
            className="grid h-8 w-8 place-items-center rounded-lg text-muted-foreground hover:bg-muted"
          >
            <X className="h-4 w-4" />
          </button>
        </div>
      </div>
    </div>
  );
}
