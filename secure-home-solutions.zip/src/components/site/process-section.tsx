"use client";

import { useReveal } from "@/hooks/use-reveal";
import { PROCESS_STEPS } from "@/lib/site-data";
import { cn } from "@/lib/utils";

export function ProcessSection() {
  const { ref, inView } = useReveal();

  return (
    <section id="process" className="relative overflow-hidden bg-white py-20 md:py-28">
      <div className="absolute inset-0 grid-pattern opacity-50" />
      <div className="container relative mx-auto max-w-7xl px-4">
        <div className="mx-auto max-w-2xl text-center">
          <div className="inline-flex items-center gap-2 rounded-full bg-brand/10 px-4 py-1.5 text-sm font-medium text-brand">
            <span className="h-1.5 w-1.5 rounded-full bg-brand" />
            كيف نعمل
          </div>
          <h2 className="mt-4 text-3xl font-extrabold leading-tight text-ink sm:text-4xl lg:text-5xl">
            خطوات <span className="text-gradient-brand">عملنا</span>
          </h2>
          <p className="mt-4 text-base text-muted-foreground sm:text-lg">
            نعمل بأسلوب منظم لضمان تقديم أفضل الخدمات الأمنية لمنزلك. من
            الاستشارة الأولية إلى التثبيت والتشغيل، نضمن جودة عالية ورضا تام.
          </p>
        </div>

        <div
          ref={ref}
          className={cn(
            "reveal relative mt-16 grid gap-6 md:grid-cols-5",
            inView && "in-view"
          )}
        >
          {/* Connector line (desktop) */}
          <div className="absolute top-9 right-[10%] left-[10%] hidden h-0.5 bg-gradient-to-l from-brand via-brand/40 to-transparent md:block" />

          {PROCESS_STEPS.map((step, i) => (
            <div
              key={step.num}
              className="relative flex flex-col items-center text-center"
              style={{ transitionDelay: `${i * 100}ms` }}
            >
              <div className="relative">
                <span className="relative z-10 grid h-18 w-18 place-items-center rounded-2xl bg-white shadow-xl ring-1 ring-border transition-transform hover:-translate-y-1.5">
                  <span
                    className="grid h-14 w-14 place-items-center rounded-xl text-white shadow-lg"
                    style={{
                      background:
                        i === 0
                          ? "linear-gradient(135deg, #f05100, #c44100)"
                          : i === PROCESS_STEPS.length - 1
                          ? "linear-gradient(135deg, #009588, #006c63)"
                          : "linear-gradient(135deg, #0b1220, #1e293b)",
                    }}
                  >
                    <step.icon className="h-7 w-7" />
                  </span>
                </span>
                <span className="absolute -top-2 -left-2 z-20 grid h-7 w-7 place-items-center rounded-full bg-gold text-xs font-extrabold text-ink shadow-lg ring-2 ring-white">
                  {step.num}
                </span>
              </div>
              <h3 className="mt-4 text-base font-bold text-ink sm:text-lg">
                {step.title}
              </h3>
              <p className="mt-1.5 text-xs leading-relaxed text-muted-foreground sm:text-sm">
                {step.desc}
              </p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
