"use client";

import Link from "next/link";
import Image from "next/image";
import { Check, ChevronLeft, ArrowLeft } from "lucide-react";
import { SERVICES } from "@/lib/site-data";
import { useReveal } from "@/hooks/use-reveal";
import { cn } from "@/lib/utils";
import { Button } from "@/components/ui/button";

export function ServicesSection() {
  const { ref, inView } = useReveal();

  return (
    <section id="services" className="relative bg-white py-20 md:py-28">
      <div className="container mx-auto max-w-7xl px-4">
        <div className="mx-auto max-w-2xl text-center">
          <div className="inline-flex items-center gap-2 rounded-full bg-brand/10 px-4 py-1.5 text-sm font-medium text-brand">
            <span className="h-1.5 w-1.5 rounded-full bg-brand" />
            خدماتنا
          </div>
          <h2 className="mt-4 text-3xl font-extrabold leading-tight text-ink sm:text-4xl lg:text-5xl">
            خدماتنا <span className="text-gradient-brand">المتميزة</span>
          </h2>
          <p className="mt-4 text-base text-muted-foreground sm:text-lg">
            نقدم مجموعة شاملة من حلول الأمان والطاقة المصممة لتلبية احتياجاتك
            بأحدث التقنيات الأكثر طلباً.
          </p>
        </div>

        <div
          ref={ref}
          className={cn(
            "reveal mt-14 grid gap-6 md:grid-cols-2",
            inView && "in-view"
          )}
        >
          {SERVICES.map((s, i) => (
            <article
              key={s.id}
              id={s.id}
              className="group relative overflow-hidden rounded-3xl border border-border bg-white shadow-sm transition-all hover:-translate-y-1 hover:shadow-2xl"
              style={{ transitionDelay: `${i * 80}ms` }}
            >
              <div className="grid grid-cols-1 sm:grid-cols-5">
                {/* Image */}
                <div className="relative sm:col-span-2 h-52 sm:h-full overflow-hidden bg-ink">
                  <Image
                    src={s.image}
                    alt={s.title}
                    fill
                    sizes="(max-width: 640px) 100vw, 40vw"
                    className="object-cover transition-transform duration-700 group-hover:scale-110"
                  />
                  <div
                    className="absolute inset-0 opacity-60 mix-blend-multiply"
                    style={{
                      background: `linear-gradient(135deg, ${s.accent}99, transparent 60%)`,
                    }}
                  />
                  <span
                    className="absolute top-4 right-4 grid h-12 w-12 place-items-center rounded-xl text-white shadow-lg backdrop-blur-sm"
                    style={{ backgroundColor: `${s.accent}e6` }}
                  >
                    <s.icon className="h-6 w-6" />
                  </span>
                  <span
                    className="absolute bottom-4 right-4 text-5xl font-black text-white/30"
                    style={{ textShadow: "0 2px 10px rgba(0,0,0,0.4)" }}
                  >
                    {s.num}
                  </span>
                </div>

                {/* Content */}
                <div className="sm:col-span-3 p-6 md:p-7">
                  <h3 className="text-xl font-extrabold text-ink sm:text-2xl">
                    {s.title}
                  </h3>
                  <p className="mt-2 text-sm leading-relaxed text-muted-foreground">
                    {s.desc}
                  </p>
                  <ul className="mt-4 grid grid-cols-1 gap-2 sm:grid-cols-2">
                    {s.features.map((f) => (
                      <li
                        key={f}
                        className="flex items-center gap-2 text-sm text-ink/80"
                      >
                        <span
                          className="grid h-5 w-5 shrink-0 place-items-center rounded-full text-white"
                          style={{ backgroundColor: s.accent }}
                        >
                          <Check className="h-3 w-3" />
                        </span>
                        {f}
                      </li>
                    ))}
                  </ul>
                  <Link
                    href={`/services/${s.id}`}
                    className="mt-5 inline-flex items-center gap-1 text-sm font-bold transition-colors hover:gap-2"
                    style={{ color: s.accent }}
                  >
                    عرض التفاصيل
                    <ChevronLeft className="h-4 w-4" />
                  </Link>
                </div>
              </div>
            </article>
          ))}
        </div>

        {/* Bottom note */}
        <div className="mt-12 flex flex-col items-center justify-between gap-4 rounded-2xl border border-brand/15 bg-gradient-to-l from-brand/5 to-transparent p-6 text-center sm:flex-row sm:text-right">
          <div>
            <h3 className="text-lg font-bold text-ink">
              هل تحتاج استشارة مجانية؟
            </h3>
            <p className="mt-1 text-sm text-muted-foreground">
              فريقنا جاهز لمساعدتك في اختيار الحل المناسب لاحتياجاتك.
            </p>
          </div>
          <div className="flex flex-wrap items-center justify-center gap-3">
            <Button
              asChild
              className="bg-ink text-white hover:bg-ink/90"
            >
              <Link href="#assistant">
                جرّب المساعد الذكي
                <ArrowLeft className="mr-1 h-4 w-4" />
              </Link>
            </Button>
            <Button
              asChild
              className="bg-brand text-white shadow-lg shadow-brand/30 hover:bg-brand-dark"
            >
              <Link href="/contact">اطلب عرض سعر</Link>
            </Button>
          </div>
        </div>
      </div>
    </section>
  );
}
