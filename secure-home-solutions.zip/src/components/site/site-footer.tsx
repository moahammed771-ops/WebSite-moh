"use client";

import Link from "next/link";
import {
  ShieldCheck,
  Phone,
  Mail,
  MapPin,
  Clock,
  Facebook,
  Twitter,
  Instagram,
  Linkedin,
  Send,
  ArrowUp,
} from "lucide-react";
import { COMPANY, QUICK_LINKS, FOOTER_SERVICES, FOOTER_CERTS } from "@/lib/site-data";

export function SiteFooter() {
  return (
    <footer className="relative overflow-hidden bg-ink text-white">
      <div className="absolute inset-0 grid-pattern-dark opacity-30" />
      <div className="absolute -top-24 right-1/3 h-72 w-72 rounded-full bg-brand/10 blur-[120px]" />

      <div className="container relative mx-auto max-w-7xl px-4 py-16">
        <div className="grid gap-10 lg:grid-cols-12">
          {/* Brand */}
          <div className="lg:col-span-4">
            <Link href="/" className="flex items-center gap-3">
              <span className="grid h-12 w-12 place-items-center rounded-xl bg-gradient-to-br from-brand to-brand-dark shadow-lg shadow-brand/30">
                <ShieldCheck className="h-6 w-6 text-white" />
              </span>
              <span className="flex flex-col leading-tight">
                <span className="text-xl font-extrabold">
                  Secure <span className="text-brand">Home</span>
                </span>
                <span className="text-[10px] font-medium uppercase tracking-[0.25em] text-white/40">
                  SOLUTIONS
                </span>
              </span>
            </Link>
            <p className="mt-5 text-sm leading-relaxed text-white/60">
              شركة رائدة متخصصة في تصميم وتنفيذ أنظمة الأمان والحماية بأعلى
              المعايير العالمية. نقدم حلولاً شاملة بأحدث التقنيات من أفضل الشركات
              المصنعة عالمياً.
            </p>

            {/* Social */}
            <div className="mt-6 flex items-center gap-2">
              {[
                { icon: Facebook, label: "Facebook" },
                { icon: Twitter, label: "Twitter" },
                { icon: Instagram, label: "Instagram" },
                { icon: Linkedin, label: "LinkedIn" },
              ].map((s) => (
                <a
                  key={s.label}
                  href="#"
                  aria-label={s.label}
                  className="grid h-10 w-10 place-items-center rounded-lg border border-white/10 bg-white/5 text-white/70 transition-colors hover:border-brand hover:bg-brand hover:text-white"
                >
                  <s.icon className="h-4 w-4" />
                </a>
              ))}
            </div>
          </div>

          {/* Quick links */}
          <div className="lg:col-span-2">
            <h3 className="text-sm font-bold uppercase tracking-wider text-white">
              روابط سريعة
            </h3>
            <ul className="mt-4 space-y-2.5">
              {QUICK_LINKS.map((l) => (
                <li key={l.href}>
                  <Link
                    href={l.href}
                    className="text-sm text-white/60 transition-colors hover:text-brand"
                  >
                    {l.label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Services */}
          <div className="lg:col-span-3">
            <h3 className="text-sm font-bold uppercase tracking-wider text-white">
              خدماتنا
            </h3>
            <ul className="mt-4 grid grid-cols-1 gap-2.5 sm:grid-cols-2 lg:grid-cols-1">
              {FOOTER_SERVICES.map((l) => (
                <li key={l.label}>
                  <Link
                    href={l.href}
                    className="text-sm text-white/60 transition-colors hover:text-brand"
                  >
                    {l.label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Contact */}
          <div className="lg:col-span-3">
            <h3 className="text-sm font-bold uppercase tracking-wider text-white">
              تواصل معنا
            </h3>
            <ul className="mt-4 space-y-3">
              <li className="flex items-start gap-3">
                <MapPin className="mt-0.5 h-4 w-4 shrink-0 text-brand" />
                <span className="text-sm text-white/70">{COMPANY.address}</span>
              </li>
              <li className="flex items-center gap-3">
                <Phone className="h-4 w-4 shrink-0 text-brand" />
                <a
                  href={`tel:${COMPANY.phoneRaw}`}
                  className="text-sm text-white/70 transition-colors hover:text-brand"
                  dir="ltr"
                >
                  {COMPANY.phone}
                </a>
              </li>
              <li className="flex items-center gap-3">
                <Mail className="h-4 w-4 shrink-0 text-brand" />
                <a
                  href={`mailto:${COMPANY.email}`}
                  className="text-sm text-white/70 transition-colors hover:text-brand"
                  dir="ltr"
                >
                  {COMPANY.email}
                </a>
              </li>
              <li className="flex items-center gap-3">
                <Clock className="h-4 w-4 shrink-0 text-brand" />
                <span className="text-sm text-white/70">{COMPANY.hours}</span>
              </li>
            </ul>
          </div>
        </div>

        {/* Certs strip */}
        <div className="mt-12 border-t border-white/10 pt-8">
          <div className="flex flex-wrap items-center justify-center gap-3">
            {FOOTER_CERTS.map((c) => (
              <div
                key={c.label}
                className="flex items-center gap-1.5 rounded-full border border-white/10 bg-white/5 px-3 py-1.5 text-xs text-white/70"
              >
                <c.icon className="h-3.5 w-3.5 text-brand" />
                {c.label}
              </div>
            ))}
          </div>
        </div>

        {/* Copyright */}
        <div className="mt-8 flex flex-col items-center justify-between gap-4 border-t border-white/10 pt-6 sm:flex-row">
          <p className="text-xs text-white/50">
            © {new Date().getFullYear()} Secure Home Solutions. جميع الحقوق
            محفوظة.
          </p>
          <p className="flex items-center gap-1.5 text-xs text-white/50">
            صُنع بكل
            <span className="text-brand">♥</span>
            في اليمن — Secure Home Solutions
          </p>
          <button
            type="button"
            onClick={() => window.scrollTo({ top: 0, behavior: "smooth" })}
            className="flex items-center gap-1.5 rounded-full border border-white/10 bg-white/5 px-3 py-1.5 text-xs text-white/70 transition-colors hover:border-brand hover:bg-brand hover:text-white"
          >
            <ArrowUp className="h-3.5 w-3.5" />
            العودة للأعلى
          </button>
        </div>
      </div>
    </footer>
  );
}
