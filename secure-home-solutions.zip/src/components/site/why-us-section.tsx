"use client";

import { useReveal } from "@/hooks/use-reveal";
import { WHY_US } from "@/lib/site-data";
import { cn } from "@/lib/utils";
import { TrendingUp } from "lucide-react";

export function WhyUsSection() {
  const { ref, inView } = useReveal();

  return (
    <section id="why-us" className="relative bg-gradient-to-b from-white to-[#fff7f1] py-20 md:py-28">
      <div className="container mx-auto max-w-7xl px-4">
        <div className="mx-auto max-w-2xl text-center">
          <div className="inline-flex items-center gap-2 rounded-full bg-brand/10 px-4 py-1.5 text-sm font-medium text-brand">
            <TrendingUp className="h-3.5 w-3.5" />
            لماذا نحن
          </div>
          <h2 className="mt-4 text-3xl font-extrabold leading-tight text-ink sm:text-4xl lg:text-5xl">
            لماذا يختارنا <span className="text-gradient-brand">العملاء؟</span>
          </h2>
          <p className="mt-4 text-base text-muted-foreground sm:text-lg">
            نجمع بين الخبرة والتقنية والأسعار المنافسة لنقدم لك تجربة أمان
            استثنائية تستحق ثقتك.
          </p>
        </div>

        <div
          ref={ref}
          className={cn(
            "reveal mt-14 grid gap-6 sm:grid-cols-2 lg:grid-cols-3",
            inView && "in-view"
          )}
        >
          {WHY_US.map((item, i) => (
            <div
              key={item.title}
              className="group relative overflow-hidden rounded-2xl border border-border bg-white p-6 shadow-sm transition-all hover:-translate-y-1.5 hover:shadow-xl"
              style={{ transitionDelay: `${i * 50}ms` }}
            >
              <div
                className="absolute -left-10 -top-10 h-32 w-32 rounded-full opacity-10 blur-2xl transition-opacity group-hover:opacity-30"
                style={{ background: item.color }}
              />
              <div className="relative flex items-start gap-4">
                <span
                  className="grid h-14 w-14 shrink-0 place-items-center rounded-2xl text-white shadow-lg transition-transform group-hover:scale-110 group-hover:-rotate-6"
                  style={{
                    background: `linear-gradient(135deg, ${item.color}, ${item.color}cc)`,
                    boxShadow: `0 10px 28px -8px ${item.color}66`,
                  }}
                >
                  <item.icon className="h-7 w-7" />
                </span>
                <div className="flex-1">
                  <h3 className="text-lg font-bold text-ink">{item.title}</h3>
                  <p className="mt-1.5 text-sm leading-relaxed text-muted-foreground">
                    {item.desc}
                  </p>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
