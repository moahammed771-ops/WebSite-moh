"use client";

import { useEffect, useState, useCallback } from "react";
import Link from "next/link";
import Image from "next/image";
import {
  ChevronLeft,
  ChevronRight,
  ShieldCheck,
  Award,
  Flame,
  Cctv,
} from "lucide-react";
import { HERO_SLIDES, HERO_FEATURES, CERTIFICATIONS } from "@/lib/site-data";
import { cn } from "@/lib/utils";
import { Button } from "@/components/ui/button";

export function HeroSection() {
  const [current, setCurrent] = useState(0);

  const next = useCallback(
    () => setCurrent((c) => (c + 1) % HERO_SLIDES.length),
    []
  );
  const prev = useCallback(
    () => setCurrent((c) => (c - 1 + HERO_SLIDES.length) % HERO_SLIDES.length),
    []
  );

  useEffect(() => {
    const id = setInterval(next, 6500);
    return () => clearInterval(id);
  }, [next]);

  return (
    <section id="home" className="relative min-h-screen overflow-hidden bg-ink">
      {/* Slides background */}
      <div className="absolute inset-0">
        {HERO_SLIDES.map((slide, i) => (
          <div
            key={i}
            className={cn(
              "absolute inset-0 transition-opacity duration-1000",
              i === current ? "opacity-100" : "opacity-0"
            )}
          >
            <Image
              src={slide.image}
              alt={slide.title}
              fill
              priority={i === 0}
              sizes="100vw"
              className="object-cover"
            />
          </div>
        ))}
        <div className="absolute inset-0 hero-overlay" />
        <div className="absolute inset-0 grid-pattern-dark opacity-40" />
      </div>

      {/* Content */}
      <div className="container relative z-10 mx-auto flex min-h-screen max-w-7xl flex-col justify-center px-4 pt-28 pb-32 md:pt-32">
        <div className="grid items-center gap-10 lg:grid-cols-12">
          {/* Text */}
          <div className="lg:col-span-7">
            {HERO_SLIDES.map((slide, i) => (
              <div
                key={i}
                className={cn(
                  "transition-all duration-700",
                  i === current
                    ? "opacity-100 translate-y-0"
                    : "absolute opacity-0 -translate-y-4 pointer-events-none"
                )}
              >
                <div className="inline-flex items-center gap-2 rounded-full border border-brand/30 bg-brand/10 px-4 py-1.5 text-sm font-medium text-brand backdrop-blur-sm">
                  <span className="relative flex h-2 w-2">
                    <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-brand opacity-75" />
                    <span className="relative inline-flex h-2 w-2 rounded-full bg-brand" />
                  </span>
                  {slide.eyebrow}
                </div>

                <h1 className="mt-6 text-4xl font-extrabold leading-[1.15] tracking-tight text-white sm:text-5xl lg:text-6xl xl:text-7xl">
                  {slide.title.split(slide.highlight).map((part, idx, arr) => (
                    <span key={idx}>
                      {part}
                      {idx < arr.length - 1 && (
                        <span className="relative text-gradient-brand">
                          {slide.highlight}
                          <svg
                            className="absolute -bottom-2 right-0 w-full"
                            height="10"
                            viewBox="0 0 200 10"
                            preserveAspectRatio="none"
                          >
                            <path
                              d="M0 8 Q 100 0 200 8"
                              stroke="#f05100"
                              strokeWidth="3"
                              fill="none"
                              strokeLinecap="round"
                            />
                          </svg>
                        </span>
                      )}
                    </span>
                  ))}
                </h1>

                <p className="mt-6 max-w-xl text-base leading-relaxed text-white/75 sm:text-lg">
                  {slide.description}
                </p>

                <div className="mt-8 flex flex-wrap items-center gap-3">
                  <Button
                    asChild
                    size="lg"
                    className="group bg-brand text-white shadow-xl shadow-brand/30 hover:bg-brand-dark"
                  >
                    <Link href="#quote">
                      اطلب خدمتك الآن
                      <ChevronLeft className="mr-1 h-5 w-5 transition-transform group-hover:-translate-x-1" />
                    </Link>
                  </Button>
                  <Button
                    asChild
                    size="lg"
                    variant="outline"
                    className="border-white/25 bg-white/5 text-white backdrop-blur-sm hover:bg-white/10 hover:text-white"
                  >
                    <Link href="/services">استكشف خدماتنا</Link>
                  </Button>
                </div>
              </div>
            ))}

            {/* Feature badges */}
            <div className="mt-10 grid grid-cols-2 gap-3 sm:grid-cols-4">
              {HERO_FEATURES.map((f) => (
                <div
                  key={f.label}
                  className="flex items-center gap-2 rounded-xl border border-white/10 bg-white/5 px-3 py-2.5 backdrop-blur-sm"
                >
                  <span className="grid h-8 w-8 place-items-center rounded-lg bg-brand/20 text-brand">
                    <f.icon className="h-4 w-4" />
                  </span>
                  <span className="text-xs font-medium text-white/85 sm:text-sm">
                    {f.label}
                  </span>
                </div>
              ))}
            </div>
          </div>

          {/* Side card */}
          <div className="hidden lg:col-span-5 lg:block">
            <div className="relative ml-auto max-w-sm">
              {/* Floating cert card */}
              <div className="glass rounded-2xl p-6 shadow-2xl">
                <div className="flex items-center justify-between">
                  <span className="text-sm font-medium text-white/70">
                    {HERO_SLIDES[current].tag}
                  </span>
                  <span className="text-xs text-white/50">0{current + 1} / 0{HERO_SLIDES.length}</span>
                </div>
                <div className="mt-5 grid grid-cols-2 gap-3">
                  {CERTIFICATIONS.map((c) => (
                    <div
                      key={c.label}
                      className="rounded-xl border border-white/10 bg-white/5 p-3 text-center"
                    >
                      <div className="text-sm font-bold text-white">{c.label}</div>
                      <div className="mt-0.5 text-[11px] text-white/50">{c.sub}</div>
                    </div>
                  ))}
                </div>
                <div className="mt-5 flex items-center gap-2 border-t border-white/10 pt-4">
                  <span className="grid h-9 w-9 place-items-center rounded-lg bg-teal/20 text-teal">
                    <ShieldCheck className="h-5 w-5" />
                  </span>
                  <div className="text-xs leading-tight text-white/70">
                    تركيب احترافي معتمد بأحدث التقنيات وأفضل الماركات العالمية
                  </div>
                </div>
              </div>

              {/* Floating badges */}
              <div className="absolute -top-4 -right-4 flex items-center gap-1.5 rounded-full bg-brand px-3 py-1.5 text-xs font-bold text-white shadow-lg animate-float">
                <Award className="h-3.5 w-3.5" />
                أفضل شركة أمن 2024
              </div>
              <div className="absolute -bottom-4 -left-4 flex items-center gap-1.5 rounded-full bg-teal px-3 py-1.5 text-xs font-bold text-white shadow-lg animate-float [animation-delay:1.5s]">
                <Cctv className="h-3.5 w-3.5" />
                +320 مشروع منجز
              </div>
            </div>
          </div>
        </div>

        {/* Slider controls */}
        <div className="mt-12 flex items-center justify-between">
          <div className="flex items-center gap-2">
            {HERO_SLIDES.map((_, i) => (
              <button
                key={i}
                onClick={() => setCurrent(i)}
                aria-label={`الشريحة ${i + 1}`}
                className={cn(
                  "h-2 rounded-full transition-all duration-300",
                  i === current
                    ? "w-10 bg-brand"
                    : "w-2 bg-white/30 hover:bg-white/50"
                )}
              />
            ))}
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={prev}
              aria-label="السابق"
              className="grid h-11 w-11 place-items-center rounded-full border border-white/20 bg-white/5 text-white backdrop-blur-sm transition-colors hover:bg-brand hover:border-brand"
            >
              <ChevronRight className="h-5 w-5" />
            </button>
            <button
              onClick={next}
              aria-label="التالي"
              className="grid h-11 w-11 place-items-center rounded-full border border-white/20 bg-white/5 text-white backdrop-blur-sm transition-colors hover:bg-brand hover:border-brand"
            >
              <ChevronLeft className="h-5 w-5" />
            </button>
          </div>
        </div>
      </div>

      {/* Bottom wave */}
      <div className="absolute bottom-0 left-0 right-0 z-10">
        <svg viewBox="0 0 1440 80" className="w-full" preserveAspectRatio="none">
          <path d="M0 80 L0 40 Q 360 0 720 40 T 1440 40 L1440 80 Z" fill="#ffffff" />
        </svg>
      </div>
    </section>
  );
}
