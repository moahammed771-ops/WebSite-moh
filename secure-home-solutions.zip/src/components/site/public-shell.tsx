"use client";

import { useEffect, useState } from "react";
import { SiteHeader } from "@/components/site/site-header";
import { SiteFooter } from "@/components/site/site-footer";
import { SmartAssistant } from "@/components/site/smart-assistant";
import { CookieBanner } from "@/components/site/cookie-banner";
import { BackToTop } from "@/components/site/back-to-top";
import { SearchDialog } from "@/components/site/search-dialog";

/**
 * PublicShell — shared layout wrapper for every public-facing page.
 * Renders the site header, page content, footer, smart assistant,
 * cookie banner, back-to-top button and the global search dialog (⌘K).
 */
export function PublicShell({ children }: { children: React.ReactNode }) {
  const [searchOpen, setSearchOpen] = useState(false);

  // Global ⌘K / Ctrl+K shortcut to open the search palette.
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === "k") {
        e.preventDefault();
        setSearchOpen((v) => !v);
      }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, []);

  return (
    <div className="flex min-h-screen flex-col bg-background">
      <SiteHeader onSearch={() => setSearchOpen(true)} />
      <main className="flex-1">{children}</main>
      <SiteFooter />
      <BackToTop />
      <SmartAssistant />
      <CookieBanner />
      <SearchDialog open={searchOpen} onOpenChange={setSearchOpen} />
    </div>
  );
}
