"use client";

import { Check, X, ArrowLeft } from "lucide-react";
import Link from "next/link";
import { COMPARISON_SERVICES, COMPARISON_FEATURES } from "@/lib/site-data";
import { useReveal } from "@/hooks/use-reveal";
import { cn } from "@/lib/utils";
import { Button } from "@/components/ui/button";

export function ComparisonSection() {
  const { ref, inView } = useReveal();

  return (
    <section
      id="comparison"
      className="relative overflow-hidden bg-white py-20 md:py-28"
    >
      <div className="container mx-auto max-w-7xl px-4">
        <div className="mx-auto max-w-2xl text-center">
          <div className="inline-flex items-center gap-2 rounded-full bg-brand/10 px-4 py-1.5 text-sm font-medium text-brand">
            <span className="h-1.5 w-1.5 rounded-full bg-brand" />
            مقارنة الخدمات
          </div>
          <h2 className="mt-4 text-3xl font-extrabold leading-tight text-ink sm:text-4xl lg:text-5xl">
            قارن بين <span className="text-gradient-brand">خدماتنا</span>
          </h2>
          <p className="mt-4 text-base text-muted-foreground sm:text-lg">
            جدول مقارنة شامل يساعدك على اختيار الخدمة الأنسب لاحتياجاتك بكل
            وضوح وشفافية.
          </p>
        </div>

        <div
          ref={ref}
          className={cn(
            "reveal mt-12 overflow-hidden rounded-3xl border border-border shadow-xl",
            inView && "in-view"
          )}
        >
          {/* Desktop table */}
          <div className="hidden overflow-x-auto md:block">
            <table className="w-full border-collapse">
              <thead>
                <tr className="bg-ink">
                  <th className="w-1/5 p-5 text-right text-sm font-bold text-white/70">
                    الميزة
                  </th>
                  {COMPARISON_SERVICES.map((s) => (
                    <th key={s.id} className="w-1/5 p-5 text-center">
                      <div className="flex flex-col items-center gap-2">
                        <span
                          className="grid h-14 w-14 place-items-center rounded-2xl text-white shadow-lg"
                          style={{
                            background: `linear-gradient(135deg, ${s.accent}, ${s.accent}cc)`,
                          }}
                        >
                          <s.icon className="h-7 w-7" />
                        </span>
                        <span className="text-base font-bold text-white">
                          {s.name}
                        </span>
                        <span className="text-xs text-white/50">
                          يبدأ من {s.startPrice}
                        </span>
                      </div>
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {COMPARISON_FEATURES.map((f, i) => (
                  <tr
                    key={f.label}
                    className={cn(
                      "border-t border-border transition-colors hover:bg-secondary/40",
                      i % 2 === 0 ? "bg-white" : "bg-secondary/20"
                    )}
                  >
                    <td className="p-4 text-right text-sm font-medium text-ink">
                      {f.label}
                    </td>
                    {f.values.map((v, j) => (
                      <td key={j} className="p-4 text-center">
                        {v ? (
                          <span className="mx-auto grid h-8 w-8 place-items-center rounded-full bg-teal/15 text-teal">
                            <Check className="h-5 w-5" />
                          </span>
                        ) : (
                          <span className="mx-auto grid h-8 w-8 place-items-center rounded-full bg-muted text-muted-foreground">
                            <X className="h-4 w-4" />
                          </span>
                        )}
                      </td>
                    ))}
                  </tr>
                ))}
                {/* Price + warranty row */}
                <tr className="border-t-2 border-border bg-ink">
                  <td className="p-5 text-right text-sm font-bold text-white/70">
                    سعر البداية
                  </td>
                  {COMPARISON_SERVICES.map((s) => (
                    <td key={s.id} className="p-5 text-center">
                      <span className="text-xl font-extrabold text-brand">
                        {s.startPrice}
                      </span>
                    </td>
                  ))}
                </tr>
                <tr className="bg-ink">
                  <td className="p-5 text-right text-sm font-bold text-white/70">
                    الضمان
                  </td>
                  {COMPARISON_SERVICES.map((s) => (
                    <td key={s.id} className="p-5 text-center text-sm font-medium text-white/80">
                      {s.warranty}
                    </td>
                  ))}
                </tr>
                <tr className="bg-ink">
                  <td className="p-5"></td>
                  {COMPARISON_SERVICES.map((s) => (
                    <td key={s.id} className="p-5 text-center">
                      <Button
                        asChild
                        size="sm"
                        className="bg-brand text-white hover:bg-brand-dark"
                      >
                        <Link href="/contact">اطلب الآن</Link>
                      </Button>
                    </td>
                  ))}
                </tr>
              </tbody>
            </table>
          </div>

          {/* Mobile cards */}
          <div className="grid gap-4 p-4 md:hidden">
            {COMPARISON_SERVICES.map((s) => (
              <div
                key={s.id}
                className="rounded-2xl border border-border bg-white p-5 shadow-sm"
              >
                <div className="flex items-center gap-3 border-b border-border pb-4">
                  <span
                    className="grid h-12 w-12 place-items-center rounded-xl text-white shadow-lg"
                    style={{ backgroundColor: s.accent }}
                  >
                    <s.icon className="h-6 w-6" />
                  </span>
                  <div className="flex-1">
                    <div className="font-bold text-ink">{s.name}</div>
                    <div className="text-xs text-muted-foreground">
                      يبدأ من {s.startPrice} · ضمان {s.warranty}
                    </div>
                  </div>
                </div>
                <ul className="mt-3 space-y-2">
                  {COMPARISON_FEATURES.map((f, i) => {
                    const v = f.values[COMPARISON_SERVICES.indexOf(s)];
                    return (
                      <li
                        key={i}
                        className="flex items-center justify-between text-sm"
                      >
                        <span className="text-muted-foreground">{f.label}</span>
                        {v ? (
                          <Check className="h-4 w-4 text-teal" />
                        ) : (
                          <X className="h-4 w-4 text-muted-foreground" />
                        )}
                      </li>
                    );
                  })}
                </ul>
              </div>
            ))}
          </div>
        </div>

        <div className="mt-8 text-center">
          <Button asChild size="lg" className="bg-ink text-white hover:bg-ink/90">
            <Link href="/contact">
              احصل على استشارة مجانية
              <ArrowLeft className="mr-1 h-4 w-4" />
            </Link>
          </Button>
        </div>
      </div>
    </section>
  );
}
