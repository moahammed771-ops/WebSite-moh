"use client";

import { useState } from "react";
import { Phone, Send, Loader2, CheckCircle2, Mail, MapPin, Clock } from "lucide-react";
import { COMPANY, SERVICES } from "@/lib/site-data";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";

export function QuoteSection() {
  const [loading, setLoading] = useState(false);
  const [done, setDone] = useState(false);
  const { toast } = useToast();

  async function onSubmit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    setLoading(true);
    const fd = new FormData(e.currentTarget);
    const payload = Object.fromEntries(fd.entries());
    try {
      const res = await fetch("/api/quote", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      });
      if (!res.ok) throw new Error("فشل الإرسال");
      setDone(true);
      toast({
        title: "تم إرسال طلبك بنجاح",
        description: "سيتواصل معك فريقنا في أقرب وقت ممكن.",
      });
    } catch {
      toast({
        variant: "destructive",
        title: "حدث خطأ",
        description: "تعذّر إرسال الطلب، يرجى المحاولة مرة أخرى.",
      });
    } finally {
      setLoading(false);
    }
  }

  return (
    <section id="quote" className="relative overflow-hidden bg-ink py-20 md:py-28">
      <div className="absolute inset-0 grid-pattern-dark opacity-40" />
      <div className="absolute -top-32 -left-32 h-80 w-80 rounded-full bg-brand/20 blur-[120px]" />
      <div className="absolute -bottom-32 -right-32 h-80 w-80 rounded-full bg-teal/15 blur-[120px]" />

      <div className="container relative mx-auto max-w-7xl px-4">
        <div className="grid gap-10 lg:grid-cols-2 lg:gap-16">
          {/* Info */}
          <div>
            <div className="inline-flex items-center gap-2 rounded-full border border-brand/30 bg-brand/10 px-4 py-1.5 text-sm font-medium text-brand">
              <span className="h-1.5 w-1.5 rounded-full bg-brand" />
              طلب عرض سعر
            </div>
            <h2 className="mt-4 text-3xl font-extrabold leading-tight text-white sm:text-4xl lg:text-5xl">
              هل تحتاج إلى نظام أمان{" "}
              <span className="text-gradient-brand">متكامل؟</span>
            </h2>
            <p className="mt-4 text-base leading-relaxed text-white/70 sm:text-lg">
              تواصل معنا الآن واحصل على استشارة مجانية. فريقنا من المهندسين
              المعتمدين جاهز لمساعدتك في تصميم الحل الأمثل لاحتياجاتك.
            </p>

            <div className="mt-8 space-y-3">
              <a
                href={`tel:${COMPANY.phoneRaw}`}
                className="group flex items-center gap-4 rounded-2xl border border-white/10 bg-white/5 p-4 transition-colors hover:border-brand/40 hover:bg-white/10"
              >
                <span className="grid h-12 w-12 place-items-center rounded-xl bg-brand/20 text-brand">
                  <Phone className="h-5 w-5" />
                </span>
                <div>
                  <div className="text-xs text-white/50">اتصل بنا الآن</div>
                  <div className="text-lg font-bold text-white" dir="ltr">
                    {COMPANY.phone}
                  </div>
                </div>
              </a>
              <div className="flex items-center gap-4 rounded-2xl border border-white/10 bg-white/5 p-4">
                <span className="grid h-12 w-12 place-items-center rounded-xl bg-teal/20 text-teal">
                  <Mail className="h-5 w-5" />
                </span>
                <div>
                  <div className="text-xs text-white/50">البريد الإلكتروني</div>
                  <div className="text-sm font-bold text-white" dir="ltr">
                    {COMPANY.email}
                  </div>
                </div>
              </div>
              <div className="flex items-center gap-4 rounded-2xl border border-white/10 bg-white/5 p-4">
                <span className="grid h-12 w-12 place-items-center rounded-xl bg-gold/20 text-gold">
                  <MapPin className="h-5 w-5" />
                </span>
                <div>
                  <div className="text-xs text-white/50">العنوان</div>
                  <div className="text-sm font-bold text-white">
                    {COMPANY.address}
                  </div>
                </div>
              </div>
              <div className="flex items-center gap-4 rounded-2xl border border-white/10 bg-white/5 p-4">
                <span className="grid h-12 w-12 place-items-center rounded-xl bg-brand/20 text-brand">
                  <Clock className="h-5 w-5" />
                </span>
                <div>
                  <div className="text-xs text-white/50">ساعات العمل</div>
                  <div className="text-sm font-bold text-white">
                    {COMPANY.hours}
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Form */}
          <div className="relative">
            <div className="rounded-3xl bg-white p-6 shadow-2xl md:p-8">
              {done ? (
                <div className="flex min-h-[420px] flex-col items-center justify-center text-center">
                  <span className="grid h-20 w-20 place-items-center rounded-full bg-teal/15 text-teal">
                    <CheckCircle2 className="h-10 w-10" />
                  </span>
                  <h3 className="mt-5 text-2xl font-extrabold text-ink">
                    تم استلام طلبك!
                  </h3>
                  <p className="mt-2 max-w-sm text-sm text-muted-foreground">
                    شكراً لتواصلك مع Secure Home Solutions. سيتواصل معك أحد
                    مستشارينا خلال 24 ساعة.
                  </p>
                  <Button
                    className="mt-6 bg-brand text-white hover:bg-brand-dark"
                    onClick={() => setDone(false)}
                  >
                    إرسال طلب آخر
                  </Button>
                </div>
              ) : (
                <form onSubmit={onSubmit} className="space-y-4">
                  <h3 className="text-xl font-extrabold text-ink">
                    اطلب عرض سعر مجاني
                  </h3>
                  <p className="-mt-2 text-sm text-muted-foreground">
                    املأ النموذج وسنعاود الاتصال بك خلال 24 ساعة.
                  </p>
                  <div className="grid gap-4 sm:grid-cols-2">
                    <div className="space-y-1.5">
                      <Label htmlFor="name">الاسم الكامل *</Label>
                      <Input id="name" name="name" required placeholder="مثال: أحمد محمد" />
                    </div>
                    <div className="space-y-1.5">
                      <Label htmlFor="phone">رقم الجوال *</Label>
                      <Input
                        id="phone"
                        name="phone"
                        required
                        placeholder="7xxxxxxxx"
                        dir="ltr"
                        inputMode="tel"
                      />
                    </div>
                  </div>
                  <div className="grid gap-4 sm:grid-cols-2">
                    <div className="space-y-1.5">
                      <Label htmlFor="email">البريد الإلكتروني</Label>
                      <Input
                        id="email"
                        name="email"
                        type="email"
                        placeholder="you@example.com"
                        dir="ltr"
                      />
                    </div>
                    <div className="space-y-1.5">
                      <Label htmlFor="service">الخدمة المطلوبة *</Label>
                      <Select name="service" required>
                        <SelectTrigger id="service" className="w-full">
                          <SelectValue placeholder="اختر الخدمة" />
                        </SelectTrigger>
                        <SelectContent>
                          {SERVICES.map((s) => (
                            <SelectItem key={s.id} value={s.title}>
                              {s.title}
                            </SelectItem>
                          ))}
                          <SelectItem value="استشارة عامة">استشارة عامة</SelectItem>
                          <SelectItem value="صيانة ودعم">صيانة ودعم</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </div>
                  <div className="space-y-1.5">
                    <Label htmlFor="message">تفاصيل المشروع</Label>
                    <Textarea
                      id="message"
                      name="message"
                      rows={4}
                      placeholder="أخبرنا عن متطلباتك، حجم المنشأة، الموقع..."
                    />
                  </div>
                  <Button
                    type="submit"
                    disabled={loading}
                    className="w-full bg-brand text-white shadow-lg shadow-brand/30 hover:bg-brand-dark"
                    size="lg"
                  >
                    {loading ? (
                      <>
                        <Loader2 className="ml-2 h-4 w-4 animate-spin" />
                        جارٍ الإرسال...
                      </>
                    ) : (
                      <>
                        إرسال الطلب
                        <Send className="mr-2 h-4 w-4" />
                      </>
                    )}
                  </Button>
                  <p className="text-center text-xs text-muted-foreground">
                    بالضغط على إرسال، فإنك توافق على سياسة الخصوصية الخاصة بنا.
                  </p>
                </form>
              )}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
