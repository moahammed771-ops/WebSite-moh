"use client";

import { useState, useMemo } from "react";
import { Search, ChevronDown, MessageCircleQuestion, ArrowLeft } from "lucide-react";
import Link from "next/link";
import { FAQ_ITEMS } from "@/lib/site-data";
import { useReveal } from "@/hooks/use-reveal";
import { cn } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";

const CATEGORIES = ["الكل", "كاميرات", "صيانة", "ضمان", "تقنية", "أسعار", "طاقة"];

export function FaqSection() {
  const [query, setQuery] = useState("");
  const [category, setCategory] = useState("الكل");
  const [openId, setOpenId] = useState<string | null>(FAQ_ITEMS[0].id);
  const { ref, inView } = useReveal();

  const filtered = useMemo(() => {
    return FAQ_ITEMS.filter((f) => {
      const matchCat = category === "الكل" || f.category === category;
      const matchQ =
        !query ||
        f.question.includes(query) ||
        f.answer.includes(query);
      return matchCat && matchQ;
    });
  }, [query, category]);

  return (
    <section id="faq" className="relative bg-gradient-to-b from-white to-[#fff7f1] py-20 md:py-28">
      <div className="container mx-auto max-w-4xl px-4">
        <div className="mx-auto max-w-2xl text-center">
          <div className="inline-flex items-center gap-2 rounded-full bg-brand/10 px-4 py-1.5 text-sm font-medium text-brand">
            <MessageCircleQuestion className="h-3.5 w-3.5" />
            أسئلة شائعة
          </div>
          <h2 className="mt-4 text-3xl font-extrabold leading-tight text-ink sm:text-4xl lg:text-5xl">
            الأسئلة <span className="text-gradient-brand">الشائعة</span>
          </h2>
          <p className="mt-4 text-base text-muted-foreground sm:text-lg">
            إجابات على أكثر الأسئلة شيوعاً. لم تجد إجابتك؟ تواصل معنا مباشرة.
          </p>
        </div>

        {/* Search */}
        <div className="relative mt-8">
          <Search className="absolute right-4 top-1/2 h-5 w-5 -translate-y-1/2 text-muted-foreground" />
          <Input
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="ابحث عن إجابتك هنا..."
            className="h-12 rounded-2xl border-border bg-white pr-12 text-base shadow-sm focus-visible:border-brand focus-visible:ring-brand/20"
          />
        </div>

        {/* Categories */}
        <div className="mt-4 flex flex-wrap items-center justify-center gap-2">
          {CATEGORIES.map((c) => (
            <button
              key={c}
              onClick={() => setCategory(c)}
              className={cn(
                "rounded-full border px-3.5 py-1.5 text-xs font-medium transition-all",
                category === c
                  ? "border-brand bg-brand text-white"
                  : "border-border bg-white text-muted-foreground hover:border-brand/40 hover:text-brand"
              )}
            >
              {c}
            </button>
          ))}
        </div>

        {/* FAQ list */}
        <div
          ref={ref}
          className={cn("reveal mt-8 space-y-3", inView && "in-view")}
        >
          {filtered.length === 0 && (
            <div className="rounded-2xl border border-border bg-white p-8 text-center text-sm text-muted-foreground">
              لا توجد نتائج مطابقة لبحثك. جرّب كلمة أخرى أو{" "}
              <Link href="/contact" className="font-medium text-brand hover:underline">
                تواصل معنا
              </Link>
              .
            </div>
          )}
          {filtered.map((item) => {
            const open = openId === item.id;
            return (
              <div
                key={item.id}
                className={cn(
                  "overflow-hidden rounded-2xl border bg-white shadow-sm transition-all",
                  open ? "border-brand/40 shadow-md" : "border-border"
                )}
              >
                <button
                  onClick={() => setOpenId(open ? null : item.id)}
                  className="flex w-full items-center gap-3 p-5 text-right"
                >
                  <span
                    className={cn(
                      "grid h-8 w-8 shrink-0 place-items-center rounded-lg text-sm font-bold transition-colors",
                      open
                        ? "bg-brand text-white"
                        : "bg-brand/10 text-brand"
                    )}
                  >
                    ؟
                  </span>
                  <span className="flex-1 text-sm font-bold text-ink sm:text-base">
                    {item.question}
                  </span>
                  <span
                    className={cn(
                      "flex shrink-0 items-center gap-1.5 text-xs text-muted-foreground",
                      "rounded-full bg-secondary px-2 py-1"
                    )}
                  >
                    {item.category}
                  </span>
                  <ChevronDown
                    className={cn(
                      "h-5 w-5 shrink-0 text-muted-foreground transition-transform duration-300",
                      open && "rotate-180 text-brand"
                    )}
                  />
                </button>
                <div
                  className={cn(
                    "grid transition-all duration-300",
                    open
                      ? "grid-rows-[1fr] opacity-100"
                      : "grid-rows-[0fr] opacity-0"
                  )}
                >
                  <div className="overflow-hidden">
                    <div className="border-t border-border px-5 py-4 pr-16 text-sm leading-relaxed text-muted-foreground">
                      {item.answer}
                    </div>
                  </div>
                </div>
              </div>
            );
          })}
        </div>

        {/* CTA */}
        <div className="mt-10 rounded-2xl border border-brand/15 bg-white p-6 text-center shadow-sm">
          <h3 className="text-lg font-bold text-ink">لم تجد إجابة لسؤالك؟</h3>
          <p className="mt-1 text-sm text-muted-foreground">
            فريقنا جاهز للإجابة على جميع استفساراتك على مدار الساعة.
          </p>
          <div className="mt-4 flex flex-wrap items-center justify-center gap-3">
            <Button asChild className="bg-brand text-white hover:bg-brand-dark">
              <Link href="/contact">
                اطرح سؤالك
                <ArrowLeft className="mr-1 h-4 w-4" />
              </Link>
            </Button>
            <Button asChild variant="outline">
              <Link href="#assistant">جرّب المساعد الذكي</Link>
            </Button>
          </div>
        </div>
      </div>
    </section>
  );
}
