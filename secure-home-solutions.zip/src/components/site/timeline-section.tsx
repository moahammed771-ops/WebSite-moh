"use client";

import { useReveal } from "@/hooks/use-reveal";
import { TIMELINE } from "@/lib/site-data";
import { cn } from "@/lib/utils";

export function TimelineSection() {
  const { ref, inView } = useReveal();

  return (
    <section id="journey" className="relative overflow-hidden bg-ink py-20 md:py-28">
      <div className="absolute inset-0 grid-pattern-dark opacity-40" />
      <div className="absolute -top-32 right-1/4 h-72 w-72 rounded-full bg-brand/15 blur-[100px]" />
      <div className="absolute -bottom-32 left-1/4 h-72 w-72 rounded-full bg-teal/15 blur-[100px]" />

      <div className="container relative mx-auto max-w-7xl px-4">
        <div className="mx-auto max-w-2xl text-center">
          <div className="inline-flex items-center gap-2 rounded-full border border-brand/30 bg-brand/10 px-4 py-1.5 text-sm font-medium text-brand">
            <span className="h-1.5 w-1.5 rounded-full bg-brand" />
            مسيرة النجاح
          </div>
          <h2 className="mt-4 text-3xl font-extrabold leading-tight text-white sm:text-4xl lg:text-5xl">
            رحلتنا نحو <span className="text-gradient-brand">التميّز</span>
          </h2>
          <p className="mt-4 text-base text-white/65 sm:text-lg">
            من انطلاقتنا في 2019 إلى اليوم، نواصل تقديم أفضل حلول الأمان بثقة
            وابتكار.
          </p>
        </div>

        <div
          ref={ref}
          className={cn(
            "reveal mt-16 grid gap-6 md:grid-cols-4",
            inView && "in-view"
          )}
        >
          {TIMELINE.map((item, i) => (
            <div key={item.year} className="relative">
              {/* connector line */}
              {i < TIMELINE.length - 1 && (
                <div className="absolute top-7 left-0 hidden h-px w-full bg-gradient-to-l from-brand/40 to-transparent md:block" />
              )}
              <div className="relative">
                <div className="flex items-center gap-3 md:block">
                  <span className="relative z-10 grid h-14 w-14 shrink-0 place-items-center rounded-2xl bg-gradient-to-br from-brand to-brand-dark text-white shadow-lg shadow-brand/30">
                    <item.icon className="h-7 w-7" />
                  </span>
                  <div className="md:mt-4">
                    <div className="text-2xl font-extrabold text-brand">
                      {item.year}
                    </div>
                  </div>
                </div>
                <div className="mt-3 md:mt-2">
                  <h3 className="text-lg font-bold text-white">{item.title}</h3>
                  <p className="mt-2 text-sm leading-relaxed text-white/60">
                    {item.desc}
                  </p>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
