"use client";

import { useEffect, useRef, useState } from "react";
import {
  Bot,
  X,
  Send,
  Sparkles,
  User,
  Loader2,
  ChevronLeft,
  PhoneCall,
} from "lucide-react";
import Link from "next/link";
import { ASSISTANT_SUGGESTIONS, ASSISTANT_CAPABILITIES, COMPANY } from "@/lib/site-data";
import { cn } from "@/lib/utils";

type Msg = { role: "user" | "assistant"; content: string };

const WELCOME: Msg = {
  role: "assistant",
  content:
    "مرحباً بك في Secure Home Solutions! 👋\nأنا مساعدك الذكي للأسئلة حول أنظمة كاميرات المراقبة، الإنتركم، إنذار الحريق، والطاقة الشمسية. كيف يمكنني مساعدتك اليوم؟",
};

export function SmartAssistant() {
  const [open, setOpen] = useState(false);
  const [messages, setMessages] = useState<Msg[]>([WELCOME]);
  const [input, setInput] = useState("");
  const [loading, setLoading] = useState(false);
  const [hasNew, setHasNew] = useState(true);
  const scrollRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLTextAreaElement>(null);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages, loading]);

  useEffect(() => {
    if (open) {
      setHasNew(false);
      setTimeout(() => inputRef.current?.focus(), 200);
    }
  }, [open]);

  // Keyboard shortcut
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape" && open) setOpen(false);
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [open]);

  async function send(text?: string) {
    const content = (text ?? input).trim();
    if (!content || loading) return;
    const next: Msg[] = [...messages, { role: "user", content }];
    setMessages(next);
    setInput("");
    setLoading(true);
    try {
      const res = await fetch("/api/chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          messages: next.map((m) => ({ role: m.role, content: m.content })),
        }),
      });
      if (!res.ok) throw new Error("failed");
      const data = await res.json();
      setMessages((prev) => [
        ...prev,
        { role: "assistant", content: data.reply },
      ]);
    } catch {
      setMessages((prev) => [
        ...prev,
        {
          role: "assistant",
          content:
            "عذراً، تعذّر الاتصال بالخادم حالياً. يمكنك الاتصال بنا مباشرة على " +
            COMPANY.phone,
        },
      ]);
    } finally {
      setLoading(false);
    }
  }

  return (
    <>
      {/* Floating button */}
      <button
        id="assistant"
        onClick={() => setOpen((v) => !v)}
        aria-label="المساعد الذكي"
        className="fixed bottom-6 right-6 z-50 flex items-center gap-2 rounded-full bg-brand px-4 py-3 text-white shadow-2xl shadow-brand/40 transition-all hover:scale-105 hover:bg-brand-dark"
      >
        <span className="relative">
          {open ? <X className="h-6 w-6" /> : <Bot className="h-6 w-6" />}
          {hasNew && !open && (
            <span className="absolute -top-1 -right-1 flex h-3 w-3">
              <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-gold opacity-75" />
              <span className="relative inline-flex h-3 w-3 rounded-full bg-gold ring-2 ring-brand" />
            </span>
          )}
        </span>
        {!open && (
          <span className="hidden text-sm font-bold sm:inline">
            المساعد الذكي
          </span>
        )}
      </button>

      {/* Chat panel */}
      <div
        className={cn(
          "fixed bottom-24 right-4 left-4 z-50 mx-auto flex max-w-md flex-col overflow-hidden rounded-3xl bg-white shadow-2xl transition-all duration-300 sm:left-auto sm:right-6 sm:w-[400px]",
          open
            ? "translate-y-0 opacity-100 pointer-events-auto"
            : "translate-y-8 opacity-0 pointer-events-none"
        )}
        style={{ height: "min(620px, 80vh)" }}
      >
        {/* Header */}
        <div className="relative overflow-hidden bg-gradient-to-l from-brand to-brand-dark p-4 text-white">
          <div className="absolute inset-0 grid-pattern opacity-20" />
          <div className="relative flex items-center gap-3">
            <span className="relative grid h-11 w-11 place-items-center rounded-xl bg-white/15 backdrop-blur-sm">
              <Bot className="h-6 w-6" />
              <span className="absolute -bottom-0.5 -right-0.5 h-3.5 w-3.5 rounded-full bg-teal ring-2 ring-brand" />
            </span>
            <div className="flex-1">
              <div className="flex items-center gap-1.5">
                <span className="font-bold">المساعد الذكي</span>
                <Sparkles className="h-3.5 w-3.5 text-gold" />
              </div>
              <div className="flex items-center gap-1.5 text-xs text-white/80">
                <span className="h-1.5 w-1.5 rounded-full bg-teal animate-pulse" />
                متصل الآن · يرد خلال ثوانٍ
              </div>
            </div>
            <button
              onClick={() => setOpen(false)}
              aria-label="إغلاق"
              className="grid h-8 w-8 place-items-center rounded-lg bg-white/10 transition-colors hover:bg-white/20"
            >
              <X className="h-4 w-4" />
            </button>
          </div>
          {/* Capabilities strip */}
          <div className="relative mt-3 flex flex-wrap gap-1.5">
            {ASSISTANT_CAPABILITIES.map((c) => (
              <span
                key={c.label}
                className="flex items-center gap-1 rounded-full bg-white/10 px-2 py-0.5 text-[10px] text-white/85 backdrop-blur-sm"
              >
                <c.icon className="h-2.5 w-2.5" />
                {c.label}
              </span>
            ))}
          </div>
        </div>

        {/* Messages */}
        <div
          ref={scrollRef}
          className="flex-1 space-y-4 overflow-y-auto bg-[#fafbfc] p-4"
        >
          {messages.map((m, i) => (
            <MessageBubble key={i} msg={m} />
          ))}
          {loading && (
            <div className="flex items-start gap-2">
              <span className="grid h-8 w-8 shrink-0 place-items-center rounded-lg bg-gradient-to-br from-brand to-brand-dark text-white">
                <Bot className="h-4 w-4" />
              </span>
              <div className="rounded-2xl rounded-tr-sm bg-white px-4 py-3 shadow-sm">
                <div className="flex items-center gap-1">
                  <span className="h-2 w-2 animate-bounce rounded-full bg-brand [animation-delay:0ms]" />
                  <span className="h-2 w-2 animate-bounce rounded-full bg-brand [animation-delay:150ms]" />
                  <span className="h-2 w-2 animate-bounce rounded-full bg-brand [animation-delay:300ms]" />
                </div>
              </div>
            </div>
          )}

          {/* Suggestions (only at start) */}
          {messages.length === 1 && !loading && (
            <div className="space-y-2 pt-2">
              <div className="px-1 text-xs font-medium text-muted-foreground">
                أسئلة شائعة:
              </div>
              {ASSISTANT_SUGGESTIONS.map((s) => (
                <button
                  key={s.text}
                  onClick={() => send(s.text)}
                  className="flex w-full items-center gap-2 rounded-xl border border-border bg-white p-3 text-right text-sm shadow-sm transition-all hover:border-brand/40 hover:shadow-md"
                >
                  <span className="grid h-8 w-8 shrink-0 place-items-center rounded-lg bg-brand/10 text-brand">
                    <s.icon className="h-4 w-4" />
                  </span>
                  <span className="flex-1 text-foreground">{s.text}</span>
                  <ChevronLeft className="h-4 w-4 text-muted-foreground" />
                </button>
              ))}
            </div>
          )}
        </div>

        {/* Input */}
        <div className="border-t border-border bg-white p-3">
          <form
            onSubmit={(e) => {
              e.preventDefault();
              send();
            }}
            className="flex items-end gap-2"
          >
            <textarea
              ref={inputRef}
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === "Enter" && !e.shiftKey) {
                  e.preventDefault();
                  send();
                }
              }}
              rows={1}
              placeholder="اكتب رسالتك هنا..."
              className="max-h-28 min-h-[44px] flex-1 resize-none rounded-2xl border border-border bg-secondary/50 px-4 py-3 text-sm outline-none transition-colors focus:border-brand focus:bg-white"
            />
            <button
              type="submit"
              disabled={loading || !input.trim()}
              aria-label="إرسال"
              className="grid h-11 w-11 shrink-0 place-items-center rounded-2xl bg-brand text-white shadow-lg shadow-brand/30 transition-colors hover:bg-brand-dark disabled:opacity-40"
            >
              {loading ? (
                <Loader2 className="h-5 w-5 animate-spin" />
              ) : (
                <Send className="h-5 w-5" />
              )}
            </button>
          </form>
          <div className="mt-2 flex items-center justify-between px-1 text-[10px] text-muted-foreground">
            <span>مدعوم بالذكاء الاصطناعي</span>
            <Link
              href={`tel:${COMPANY.phoneRaw}`}
              className="flex items-center gap-1 font-medium text-brand hover:underline"
            >
              <PhoneCall className="h-3 w-3" />
              تواصل مع فريق البشر
            </Link>
          </div>
        </div>
      </div>
    </>
  );
}

function MessageBubble({ msg }: { msg: Msg }) {
  const isUser = msg.role === "user";
  return (
    <div className={cn("flex items-start gap-2", isUser && "flex-row-reverse")}>
      <span
        className={cn(
          "grid h-8 w-8 shrink-0 place-items-center rounded-lg text-white shadow-sm",
          isUser
            ? "bg-ink"
            : "bg-gradient-to-br from-brand to-brand-dark"
        )}
      >
        {isUser ? <User className="h-4 w-4" /> : <Bot className="h-4 w-4" />}
      </span>
      <div
        className={cn(
          "max-w-[78%] whitespace-pre-wrap rounded-2xl px-4 py-2.5 text-sm leading-relaxed shadow-sm",
          isUser
            ? "rounded-tl-sm bg-brand text-white"
            : "rounded-tr-sm bg-white text-foreground"
        )}
      >
        {msg.content}
      </div>
    </div>
  );
}
