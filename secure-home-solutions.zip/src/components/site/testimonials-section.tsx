"use client";

import { Star, Quote } from "lucide-react";
import { TESTIMONIALS } from "@/lib/site-data";
import { useReveal } from "@/hooks/use-reveal";
import { cn } from "@/lib/utils";

export function TestimonialsSection() {
  const { ref, inView } = useReveal();

  return (
    <section
      id="testimonials"
      className="relative overflow-hidden bg-gradient-to-b from-white to-[#fff7f1] py-20 md:py-28"
    >
      <div className="container mx-auto max-w-7xl px-4">
        <div className="mx-auto max-w-2xl text-center">
          <div className="inline-flex items-center gap-2 rounded-full bg-brand/10 px-4 py-1.5 text-sm font-medium text-brand">
            <Star className="h-3.5 w-3.5" />
            آراء العملاء
          </div>
          <h2 className="mt-4 text-3xl font-extrabold leading-tight text-ink sm:text-4xl lg:text-5xl">
            ماذا يقول <span className="text-gradient-brand">عملاؤنا؟</span>
          </h2>
          <p className="mt-4 text-base text-muted-foreground sm:text-lg">
            ثقة عملائنا هي أكبر إنجازاتنا. إليك بعض تجاربهم الحقيقية معنا.
          </p>
        </div>

        {/* Rating summary */}
        <div className="mt-8 flex flex-wrap items-center justify-center gap-4">
          <div className="flex items-center gap-3 rounded-2xl border border-border bg-white px-6 py-3 shadow-sm">
            <div className="flex items-center gap-0.5">
              {[...Array(5)].map((_, i) => (
                <Star key={i} className="h-5 w-5 fill-gold text-gold" />
              ))}
            </div>
            <div className="text-sm">
              <span className="font-bold text-ink">4.9/5</span>
              <span className="text-muted-foreground"> من +280 تقييم</span>
            </div>
          </div>
          <div className="flex items-center gap-3 rounded-2xl border border-border bg-white px-6 py-3 text-sm shadow-sm">
            <span className="font-bold text-ink">99%</span>
            <span className="text-muted-foreground">رضا العملاء</span>
          </div>
        </div>

        {/* Testimonials grid */}
        <div
          ref={ref}
          className={cn(
            "reveal mt-12 grid gap-6 md:grid-cols-2 lg:grid-cols-3",
            inView && "in-view"
          )}
        >
          {TESTIMONIALS.map((t, i) => (
            <div
              key={t.id}
              className="group relative flex flex-col rounded-3xl border border-border bg-white p-6 shadow-sm transition-all hover:-translate-y-1.5 hover:shadow-xl"
              style={{ transitionDelay: `${i * 60}ms` }}
            >
              <Quote
                className="absolute -top-3 left-6 h-10 w-10 rotate-180 text-brand/15"
                style={{ color: `${t.color}22` }}
              />
              <div className="relative flex items-center gap-1">
                {[...Array(t.rating)].map((_, j) => (
                  <Star key={j} className="h-4 w-4 fill-gold text-gold" />
                ))}
              </div>
              <p className="relative mt-4 flex-1 text-sm leading-relaxed text-foreground/85">
                &ldquo;{t.text}&rdquo;
              </p>
              <div className="mt-5 flex items-center gap-3 border-t border-border pt-4">
                <span
                  className="grid h-12 w-12 shrink-0 place-items-center rounded-full text-sm font-bold text-white shadow-lg"
                  style={{
                    background: `linear-gradient(135deg, ${t.color}, ${t.color}cc)`,
                  }}
                >
                  {t.initials}
                </span>
                <div>
                  <div className="font-bold text-ink">{t.name}</div>
                  <div className="text-xs text-muted-foreground">{t.role}</div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
