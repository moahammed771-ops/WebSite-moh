"use client";

import { useState, useMemo } from "react";
import Link from "next/link";
import { ShoppingCart, Eye, Check, Star } from "lucide-react";
import { PRODUCTS, PRODUCT_FILTERS } from "@/lib/site-data";
import { useReveal } from "@/hooks/use-reveal";
import { cn } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";

export function ProductsSection() {
  const [filter, setFilter] = useState<string>("الكل");
  const [cart, setCart] = useState<string[]>([]);
  const { ref, inView } = useReveal();
  const { toast } = useToast();

  const filtered = useMemo(() => {
    if (filter === "الكل") return PRODUCTS;
    return PRODUCTS.filter((p) => p.category === filter);
  }, [filter]);

  function addToCart(name: string) {
    setCart((c) => [...c, name]);
    toast({
      title: "تمت الإضافة إلى السلة",
      description: `تمت إضافة ${name} إلى سلة المشتريات.`,
    });
  }

  return (
    <section
      id="products"
      className="relative overflow-hidden bg-ink py-20 md:py-28"
    >
      <div className="absolute inset-0 grid-pattern-dark opacity-40" />
      <div className="absolute -top-32 right-1/4 h-80 w-80 rounded-full bg-brand/15 blur-[120px]" />
      <div className="absolute -bottom-32 left-1/4 h-80 w-80 rounded-full bg-teal/10 blur-[120px]" />

      <div className="container relative mx-auto max-w-7xl px-4">
        <div className="mx-auto max-w-2xl text-center">
          <div className="inline-flex items-center gap-2 rounded-full border border-brand/30 bg-brand/10 px-4 py-1.5 text-sm font-medium text-brand">
            <span className="h-1.5 w-1.5 rounded-full bg-brand" />
            منتجاتنا المتميزة
          </div>
          <h2 className="mt-4 text-3xl font-extrabold leading-tight text-white sm:text-4xl lg:text-5xl">
            أحدث <span className="text-gradient-brand">المنتجات</span>
          </h2>
          <p className="mt-4 text-base text-white/65 sm:text-lg">
            تشكيلة مختارة من أفضل منتجات الشركات العالمية المعتمدة بأسعار
            تنافسية وضمان رسمي.
          </p>
        </div>

        {/* Filters */}
        <div className="mt-8 flex flex-wrap items-center justify-center gap-2">
          {PRODUCT_FILTERS.map((f) => (
            <button
              key={f}
              onClick={() => setFilter(f)}
              className={cn(
                "rounded-full border px-4 py-2 text-sm font-medium transition-all",
                filter === f
                  ? "border-brand bg-brand text-white shadow-lg shadow-brand/30"
                  : "border-white/15 bg-white/5 text-white/60 hover:border-brand/40 hover:text-white"
              )}
            >
              {f}
            </button>
          ))}
        </div>

        {/* Products grid */}
        <div
          ref={ref}
          className={cn(
            "reveal mt-10 grid gap-6 sm:grid-cols-2 lg:grid-cols-3",
            inView && "in-view"
          )}
        >
          {filtered.map((p, i) => {
            const inCart = cart.includes(p.name);
            return (
              <article
                key={p.id}
                className="group relative overflow-hidden rounded-3xl border border-white/10 bg-gradient-to-br from-white/10 to-white/[0.03] p-6 backdrop-blur-sm transition-all hover:-translate-y-1.5 hover:border-brand/40 hover:shadow-2xl"
                style={{ transitionDelay: `${i * 60}ms` }}
              >
                {/* Badge */}
                <span
                  className="absolute top-4 left-4 rounded-full px-3 py-1 text-xs font-bold text-white shadow-lg"
                  style={{ backgroundColor: p.accent }}
                >
                  {p.badge}
                </span>

                {/* Icon */}
                <div className="flex justify-center pt-4">
                  <span
                    className="grid h-24 w-24 place-items-center rounded-2xl text-white shadow-xl transition-transform group-hover:scale-110 group-hover:rotate-3"
                    style={{
                      background: `linear-gradient(135deg, ${p.accent}, ${p.accent}88)`,
                      boxShadow: `0 16px 40px -10px ${p.accent}66`,
                    }}
                  >
                    <p.icon className="h-12 w-12" />
                  </span>
                </div>

                {/* Info */}
                <div className="mt-5 text-center">
                  <div className="text-xs font-medium uppercase tracking-wider text-white/40">
                    {p.brand}
                  </div>
                  <h3 className="mt-1 text-lg font-bold text-white">
                    {p.name}
                  </h3>
                  <div className="mt-0.5 text-xs text-white/50" dir="ltr">
                    {p.model}
                  </div>
                  <div className="mt-2 flex items-center justify-center gap-1">
                    {[...Array(5)].map((_, j) => (
                      <Star
                        key={j}
                        className="h-3.5 w-3.5 fill-gold text-gold"
                      />
                    ))}
                    <span className="mr-1 text-xs text-white/50">(4.9)</span>
                  </div>
                </div>

                {/* Price + actions */}
                <div className="mt-5 flex items-center justify-between border-t border-white/10 pt-4">
                  <div>
                    <div className="text-xs text-white/40">السعر</div>
                    <div className="text-xl font-extrabold text-brand">
                      {p.price}
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    <Button
                      asChild
                      size="icon"
                      variant="outline"
                      className="border-white/15 bg-white/5 text-white hover:bg-white/10 hover:text-white"
                    >
                      <Link href="/contact" aria-label="عرض التفاصيل">
                        <Eye className="h-4 w-4" />
                      </Link>
                    </Button>
                    <Button
                      size="sm"
                      onClick={() => addToCart(p.name)}
                      disabled={inCart}
                      className="bg-brand text-white hover:bg-brand-dark disabled:opacity-60"
                    >
                      {inCart ? (
                        <>
                          <Check className="ml-1 h-4 w-4" />
                          أُضيف
                        </>
                      ) : (
                        <>
                          <ShoppingCart className="ml-1 h-4 w-4" />
                          أضف للسلة
                        </>
                      )}
                    </Button>
                  </div>
                </div>
              </article>
            );
          })}
        </div>

        {/* Cart bar */}
        {cart.length > 0 && (
          <div className="mt-8 flex items-center justify-between rounded-2xl border border-brand/30 bg-brand/10 p-4 backdrop-blur-sm animate-slide-fade-in">
            <div className="flex items-center gap-3 text-white">
              <ShoppingCart className="h-6 w-6 text-brand" />
              <span className="font-bold">
                {cart.length} منتج في السلة
              </span>
            </div>
            <Button asChild className="bg-brand text-white hover:bg-brand-dark">
              <Link href="/contact">
                إتمام الطلب
                <ShoppingCart className="mr-1 h-4 w-4" />
              </Link>
            </Button>
          </div>
        )}
      </div>
    </section>
  );
}
