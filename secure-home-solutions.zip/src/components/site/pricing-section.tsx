"use client";

import Link from "next/link";
import { Check, Star, ArrowLeft, ShieldCheck } from "lucide-react";
import { PRICING_PLANS } from "@/lib/site-data";
import { useReveal } from "@/hooks/use-reveal";
import { cn } from "@/lib/utils";
import { Button } from "@/components/ui/button";

export function PricingSection() {
  const { ref, inView } = useReveal();

  return (
    <section id="pricing" className="relative overflow-hidden bg-ink py-20 md:py-28">
      <div className="absolute inset-0 grid-pattern-dark opacity-40" />
      <div className="absolute -top-32 left-1/4 h-80 w-80 rounded-full bg-brand/15 blur-[120px]" />
      <div className="absolute -bottom-32 right-1/4 h-80 w-80 rounded-full bg-teal/15 blur-[120px]" />

      <div className="container relative mx-auto max-w-7xl px-4">
        <div className="mx-auto max-w-2xl text-center">
          <div className="inline-flex items-center gap-2 rounded-full border border-brand/30 bg-brand/10 px-4 py-1.5 text-sm font-medium text-brand">
            <span className="h-1.5 w-1.5 rounded-full bg-brand" />
            الأسعار
          </div>
          <h2 className="mt-4 text-3xl font-extrabold leading-tight text-white sm:text-4xl lg:text-5xl">
            باقات تناسب <span className="text-gradient-brand">احتياجاتك</span>
          </h2>
          <p className="mt-4 text-base text-white/65 sm:text-lg">
            اختر الباقة المناسبة لك أو تواصل معنا لعرض سعر مخصص. جميع الباقات تشمل
            تركيباً احترافياً وضماناً رسمياً.
          </p>
        </div>

        <div
          ref={ref}
          className={cn(
            "reveal mt-14 grid items-stretch gap-6 lg:grid-cols-3",
            inView && "in-view"
          )}
        >
          {PRICING_PLANS.map((plan, i) => (
            <div
              key={plan.id}
              className={cn(
                "relative flex flex-col overflow-hidden rounded-3xl border p-7 transition-all hover:-translate-y-1",
                plan.popular
                  ? "border-brand bg-gradient-to-b from-white to-[#fff7f1] shadow-2xl lg:scale-105 lg:shadow-brand/20"
                  : "border-white/10 bg-white/5 backdrop-blur-sm"
              )}
              style={{ transitionDelay: `${i * 80}ms` }}
            >
              {plan.popular && (
                <span className="absolute -top-px left-1/2 -translate-x-1/2 rounded-b-xl bg-brand px-4 py-1.5 text-xs font-bold text-white shadow-lg">
                  ⭐ الأكثر طلباً
                </span>
              )}

              <div className="mt-2">
                <div className="flex items-center gap-2">
                  <span
                    className="grid h-10 w-10 place-items-center rounded-xl text-white shadow-lg"
                    style={{ backgroundColor: plan.accent }}
                  >
                    <ShieldCheck className="h-5 w-5" />
                  </span>
                  <h3
                    className={cn(
                      "text-xl font-extrabold",
                      plan.popular ? "text-ink" : "text-white"
                    )}
                  >
                    {plan.name}
                  </h3>
                </div>
                <p
                  className={cn(
                    "mt-2 text-sm",
                    plan.popular ? "text-muted-foreground" : "text-white/55"
                  )}
                >
                  {plan.tagline}
                </p>
              </div>

              <div className="mt-6 flex items-end gap-2">
                <span
                  className={cn(
                    "text-4xl font-extrabold sm:text-5xl",
                    plan.popular ? "text-ink" : "text-white"
                  )}
                >
                  {plan.price}
                </span>
                <span
                  className={cn(
                    "mb-1.5 text-xs",
                    plan.popular ? "text-muted-foreground" : "text-white/50"
                  )}
                >
                  {plan.period}
                </span>
              </div>

              <ul className="mt-6 flex-1 space-y-2.5">
                {plan.features.map((f) => (
                  <li
                    key={f}
                    className={cn(
                      "flex items-start gap-2 text-sm",
                      plan.popular ? "text-ink/80" : "text-white/75"
                    )}
                  >
                    <span
                      className="mt-0.5 grid h-5 w-5 shrink-0 place-items-center rounded-full text-white"
                      style={{ backgroundColor: plan.accent }}
                    >
                      <Check className="h-3 w-3" />
                    </span>
                    {f}
                  </li>
                ))}
              </ul>

              <Button
                asChild
                size="lg"
                className={cn(
                  "mt-7 w-full",
                  plan.popular
                    ? "bg-brand text-white shadow-lg shadow-brand/30 hover:bg-brand-dark"
                    : "bg-white/10 text-white hover:bg-white/20"
                )}
              >
                <Link href="/contact">
                  {plan.cta}
                  <ArrowLeft className="mr-1 h-4 w-4" />
                </Link>
              </Button>
            </div>
          ))}
        </div>

        {/* Guarantee strip */}
        <div className="mt-10 flex flex-wrap items-center justify-center gap-6 rounded-2xl border border-white/10 bg-white/5 px-6 py-5 text-sm text-white/70 backdrop-blur-sm">
          {[
            { icon: ShieldCheck, text: "ضمان رسمي حتى 5 سنوات" },
            { icon: Star, text: "تركيب احترافي معتمد" },
            { icon: Check, text: "دفع على دفعات متاحة" },
            { icon: ShieldCheck, text: "صيانة دورية مجانية" },
          ].map((g) => (
            <span key={g.text} className="flex items-center gap-2">
              <g.icon className="h-4 w-4 text-brand" />
              {g.text}
            </span>
          ))}
        </div>
      </div>
    </section>
  );
}
