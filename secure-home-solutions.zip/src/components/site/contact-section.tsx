"use client";

import { useState } from "react";
import {
  Phone,
  Mail,
  MapPin,
  Clock,
  Send,
  Loader2,
  CheckCircle2,
  MessageCircle,
  MapPinned,
} from "lucide-react";
import { COMPANY } from "@/lib/site-data";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { useToast } from "@/hooks/use-toast";

export function ContactSection() {
  const [loading, setLoading] = useState(false);
  const [done, setDone] = useState(false);
  const { toast } = useToast();

  async function onSubmit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    setLoading(true);
    const fd = new FormData(e.currentTarget);
    const payload = Object.fromEntries(fd.entries());
    try {
      const res = await fetch("/api/contact", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      });
      if (!res.ok) throw new Error("failed");
      setDone(true);
      toast({
        title: "تم إرسال رسالتك",
        description: "سنرد عليك في أقرب وقت ممكن.",
      });
    } catch {
      toast({
        variant: "destructive",
        title: "تعذّر الإرسال",
        description: "حاول مرة أخرى لاحقاً.",
      });
    } finally {
      setLoading(false);
    }
  }

  const INFO = [
    {
      icon: Phone,
      label: "الهاتف",
      value: COMPANY.phone,
      href: `tel:${COMPANY.phoneRaw}`,
      color: "#f05100",
      dir: "ltr" as const,
    },
    {
      icon: Mail,
      label: "البريد الإلكتروني",
      value: COMPANY.email,
      href: `mailto:${COMPANY.email}`,
      color: "#009588",
      dir: "ltr" as const,
    },
    {
      icon: MapPin,
      label: "العنوان",
      value: COMPANY.address,
      href: "#map",
      color: "#fcbb00",
    },
    {
      icon: Clock,
      label: "أوقات العمل",
      value: COMPANY.hours,
      color: "#104e64",
    },
  ];

  return (
    <section id="contact" className="relative bg-gradient-to-b from-[#fff7f1] to-white py-20 md:py-28">
      <div className="container mx-auto max-w-7xl px-4">
        <div className="mx-auto max-w-2xl text-center">
          <div className="inline-flex items-center gap-2 rounded-full bg-brand/10 px-4 py-1.5 text-sm font-medium text-brand">
            <MessageCircle className="h-3.5 w-3.5" />
            تواصل معنا
          </div>
          <h2 className="mt-4 text-3xl font-extrabold leading-tight text-ink sm:text-4xl lg:text-5xl">
            نحن هنا <span className="text-gradient-brand">لمساعدتك</span>
          </h2>
          <p className="mt-4 text-base text-muted-foreground sm:text-lg">
            هل لديك سؤال أو استفسار؟ فريقنا جاهز للرد عليك على مدار الساعة.
            تواصل معنا بالطريقة التي تناسبك.
          </p>
        </div>

        <div className="mt-12 grid gap-8 lg:grid-cols-2">
          {/* Info card */}
          <div className="relative overflow-hidden rounded-3xl bg-ink p-7 text-white shadow-2xl md:p-9">
            <div className="absolute inset-0 grid-pattern-dark opacity-30" />
            <div className="absolute -top-20 -left-20 h-56 w-56 rounded-full bg-brand/20 blur-3xl" />

            <div className="relative">
              <h3 className="text-2xl font-bold">معلومات الاتصال</h3>
              <p className="mt-2 text-sm text-white/60">
                يسعدنا تواصلك معنا عبر أي من القنوات التالية:
              </p>

              <div className="mt-7 space-y-4">
                {INFO.map((item) => (
                  <a
                    key={item.label}
                    href={item.href}
                    className="group flex items-center gap-4 rounded-2xl border border-white/10 bg-white/5 p-4 transition-all hover:border-brand/40 hover:bg-white/10"
                  >
                    <span
                      className="grid h-12 w-12 shrink-0 place-items-center rounded-xl text-white shadow-lg"
                      style={{
                        background: `linear-gradient(135deg, ${item.color}, ${item.color}cc)`,
                      }}
                    >
                      <item.icon className="h-5 w-5" />
                    </span>
                    <div className="min-w-0 flex-1">
                      <div className="text-xs text-white/50">{item.label}</div>
                      <div
                        className="truncate text-sm font-bold text-white"
                        dir={item.dir}
                      >
                        {item.value}
                      </div>
                    </div>
                  </a>
                ))}
              </div>

              {/* Quick action buttons */}
              <div className="mt-6 grid grid-cols-2 gap-3">
                <Button
                  asChild
                  className="bg-teal text-white shadow-lg shadow-teal/30 hover:bg-teal/90"
                >
                  <a
                    href={`https://wa.me/${COMPANY.phoneRaw.replace("+", "")}`}
                    target="_blank"
                    rel="noopener noreferrer"
                  >
                    <MessageCircle className="ml-1.5 h-4 w-4" />
                    واتساب
                  </a>
                </Button>
                <Button
                  asChild
                  className="bg-brand text-white shadow-lg shadow-brand/30 hover:bg-brand-dark"
                >
                  <a href={`tel:${COMPANY.phoneRaw}`}>
                    <Phone className="ml-1.5 h-4 w-4" />
                    اتصال مباشر
                  </a>
                </Button>
              </div>
            </div>
          </div>

          {/* Form */}
          <div className="rounded-3xl border border-border bg-white p-7 shadow-xl md:p-9">
            {done ? (
              <div className="flex min-h-[440px] flex-col items-center justify-center text-center">
                <span className="grid h-20 w-20 place-items-center rounded-full bg-teal/15 text-teal">
                  <CheckCircle2 className="h-10 w-10" />
                </span>
                <h3 className="mt-5 text-2xl font-extrabold text-ink">
                  تم إرسال رسالتك!
                </h3>
                <p className="mt-2 max-w-sm text-sm text-muted-foreground">
                  شكراً لتواصلك مع Secure Home Solutions. سنرد عليك في أقرب وقت
                  ممكن.
                </p>
                <Button
                  className="mt-6 bg-brand text-white hover:bg-brand-dark"
                  onClick={() => setDone(false)}
                >
                  إرسال رسالة أخرى
                </Button>
              </div>
            ) : (
              <form onSubmit={onSubmit} className="space-y-4">
                <h3 className="text-xl font-extrabold text-ink">أرسل لنا رسالة</h3>
                <div className="grid gap-4 sm:grid-cols-2">
                  <div className="space-y-1.5">
                    <Label htmlFor="c-name">الاسم *</Label>
                    <Input id="c-name" name="name" required placeholder="اسمك الكريم" />
                  </div>
                  <div className="space-y-1.5">
                    <Label htmlFor="c-phone">رقم الهاتف *</Label>
                    <Input
                      id="c-phone"
                      name="phone"
                      required
                      placeholder="7xxxxxxxx"
                      dir="ltr"
                      inputMode="tel"
                    />
                  </div>
                </div>
                <div className="grid gap-4 sm:grid-cols-2">
                  <div className="space-y-1.5">
                    <Label htmlFor="c-email">البريد الإلكتروني</Label>
                    <Input
                      id="c-email"
                      name="email"
                      type="email"
                      placeholder="you@example.com"
                      dir="ltr"
                    />
                  </div>
                  <div className="space-y-1.5">
                    <Label htmlFor="c-subject">الموضوع</Label>
                    <Input
                      id="c-subject"
                      name="subject"
                      placeholder="موضوع الرسالة"
                    />
                  </div>
                </div>
                <div className="space-y-1.5">
                  <Label htmlFor="c-message">الرسالة *</Label>
                  <Textarea
                    id="c-message"
                    name="message"
                    required
                    rows={5}
                    placeholder="اكتب رسالتك هنا..."
                  />
                </div>
                <Button
                  type="submit"
                  disabled={loading}
                  size="lg"
                  className="w-full bg-brand text-white shadow-lg shadow-brand/30 hover:bg-brand-dark"
                >
                  {loading ? (
                    <>
                      <Loader2 className="ml-2 h-4 w-4 animate-spin" />
                      جارٍ الإرسال...
                    </>
                  ) : (
                    <>
                      إرسال الرسالة
                      <Send className="mr-2 h-4 w-4" />
                    </>
                  )}
                </Button>
              </form>
            )}
          </div>
        </div>

        {/* Map */}
        <div
          id="map"
          className="relative mt-8 overflow-hidden rounded-3xl border border-border bg-ink p-2 shadow-xl"
        >
          <div className="relative h-72 overflow-hidden rounded-2xl bg-gradient-to-br from-[#0b1220] to-[#16233a] sm:h-80">
            <div className="absolute inset-0 grid-pattern-dark opacity-40" />
            {/* Stylized map placeholder */}
            <div className="absolute inset-0 flex items-center justify-center">
              <div className="text-center">
                <span className="relative mx-auto grid h-20 w-20 place-items-center rounded-full bg-brand shadow-2xl animate-pulse-ring">
                  <MapPinned className="h-9 w-9 text-white" />
                </span>
                <div className="mt-4 text-lg font-bold text-white">
                  {COMPANY.address}
                </div>
                <div className="mt-1 text-sm text-white/60" dir="ltr">
                  {COMPANY.addressEn}
                </div>
                <Button
                  asChild
                  size="sm"
                  className="mt-4 bg-brand text-white hover:bg-brand-dark"
                >
                  <a
                    href={`https://maps.google.com/?q=${encodeURIComponent(
                      COMPANY.addressEn
                    )}`}
                    target="_blank"
                    rel="noopener noreferrer"
                  >
                    <MapPin className="ml-1 h-3.5 w-3.5" />
                    افتح في خرائط Google
                  </a>
                </Button>
              </div>
            </div>
            {/* Decorative roads */}
            <svg
              className="absolute inset-0 h-full w-full opacity-20"
              preserveAspectRatio="none"
            >
              <path
                d="M0 120 Q 400 80 800 140 T 1440 100"
                stroke="#f05100"
                strokeWidth="3"
                fill="none"
              />
              <path
                d="M200 0 L 240 400"
                stroke="#009588"
                strokeWidth="2"
                fill="none"
              />
              <path
                d="M0 280 L 1440 240"
                stroke="#ffffff"
                strokeWidth="2"
                fill="none"
                opacity="0.5"
              />
            </svg>
          </div>
        </div>
      </div>
    </section>
  );
}
