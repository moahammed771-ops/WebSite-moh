"use client";

import { useEffect, useMemo, useState } from "react";
import Link from "next/link";
import {
  Search,
  X,
  Cctv,
  DoorClosed,
  Flame,
  SunMedium,
  ShieldCheck,
  PhoneCall,
  FileText,
  ArrowLeft,
} from "lucide-react";
import { SERVICES } from "@/lib/site-data";
import { COMPANY } from "@/lib/site-data";

type SearchResult = {
  title: string;
  desc: string;
  href: string;
  icon: React.ElementType;
  category: string;
};

const INDEX: SearchResult[] = [
  ...SERVICES.map((s) => ({
    title: s.title,
    desc: s.desc,
    href: `/services/${s.id}`,
    icon: s.icon,
    category: "خدمة",
  })),
  { title: "من نحن", desc: "تعرف على شركتنا وفريقنا المعتمد", href: "/about", icon: ShieldCheck, category: "صفحة" },
  { title: "لماذا نحن", desc: "مميزات اختيار Secure Home Solutions", href: "/about", icon: ShieldCheck, category: "صفحة" },
  { title: "كيف نعمل", desc: "خطوات عملنا من الاستشارة حتى الصيانة", href: "/services", icon: FileText, category: "صفحة" },
  { title: "مقارنة الخدمات", desc: "قارن بين ميزات خدماتنا الأربعة", href: "/services", icon: FileText, category: "صفحة" },
  { title: "المنتجات", desc: "أحدث منتجات Hikvision وDahua وHoneywell", href: "/services", icon: Cctv, category: "صفحة" },
  { title: "مشاريعنا", desc: "أحدث المشاريع المنجزة في اليمن", href: "/projects", icon: FileText, category: "صفحة" },
  { title: "الأسعار", desc: "باقات تناسب جميع الميزانيات", href: "/pricing", icon: FileText, category: "صفحة" },
  { title: "مسيرة النجاح", desc: "رحلتنا منذ 2019 حتى اليوم", href: "/about", icon: FileText, category: "صفحة" },
  { title: "قيمنا الأساسية", desc: "الجودة، الأمان، الابتكار، الثقة", href: "/about", icon: ShieldCheck, category: "صفحة" },
  { title: "فريقنا", desc: "تعرف على مهندسينا وفنيينا المعتمدين", href: "/about", icon: ShieldCheck, category: "صفحة" },
  { title: "آراء العملاء", desc: "تقييمات عملائنا الحقيقيين", href: "/", icon: FileText, category: "صفحة" },
  { title: "الأسئلة الشائعة", desc: "إجابات على أكثر الأسئلة شيوعاً", href: "/faq", icon: FileText, category: "صفحة" },
  { title: "المدونة", desc: "أحدث المقالات والنصائح الأمنية", href: "/blog", icon: FileText, category: "صفحة" },
  { title: "شركاؤنا", desc: "Hikvision, Dahua, Honeywell والمزيد", href: "/about", icon: ShieldCheck, category: "صفحة" },
  { title: "تواصل معنا", desc: "نموذج تواصل + خريطة الموقع + معلومات", href: "/contact", icon: PhoneCall, category: "صفحة" },
  { title: "طلب عرض سعر", desc: "احصل على عرض سعر مجاني الآن", href: "/contact", icon: FileText, category: "إجراء" },
  { title: "المساعد الذكي", desc: "اسأل مساعدنا الذكي عن أي استفسار", href: "/contact", icon: PhoneCall, category: "أداة" },
  { title: "اتصل بنا", desc: COMPANY.phone, href: `tel:${COMPANY.phoneRaw}`, icon: PhoneCall, category: "تواصل" },
  { title: "الباقة الأساسية", desc: "4 كاميرات HD ابتداءً من 299$", href: "/pricing", icon: Cctv, category: "باقة" },
  { title: "الباقة الاحترافية", desc: "8 كاميرات 4K الأكثر طلباً", href: "/pricing", icon: Cctv, category: "باقة" },
  { title: "باقة المؤسسات", desc: "حلول مخصصة للمنشآت الكبيرة", href: "/pricing", icon: Cctv, category: "باقة" },
];

const POPULAR = ["كاميرات مراقبة", "طاقة شمسية", "إنذار حريق", "طلب عرض سعر"];

export function SearchDialog({
  open,
  onOpenChange,
}: {
  open: boolean;
  onOpenChange: (v: boolean) => void;
}) {
  const [query, setQuery] = useState("");

  const results = useMemo(() => {
    const q = query.trim();
    if (!q) return INDEX.slice(0, 6);
    return INDEX.filter(
      (r) =>
        r.title.includes(q) ||
        r.desc.includes(q) ||
        r.category.includes(q)
    ).slice(0, 8);
  }, [query]);

  useEffect(() => {
    if (!open) return;
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") onOpenChange(false);
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [open, onOpenChange]);

  if (!open) return null;

  return (
    <div
      className="fixed inset-0 z-[70] flex items-start justify-center bg-ink/60 p-4 backdrop-blur-sm pt-[10vh]"
      onClick={() => onOpenChange(false)}
    >
      <div
        className="w-full max-w-2xl overflow-hidden rounded-2xl bg-white shadow-2xl animate-slide-fade-in"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex items-center gap-3 border-b border-border p-4">
          <Search className="h-5 w-5 text-muted-foreground" />
          <input
            autoFocus
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="ابحث عن الخدمات والمقالات والصفحات..."
            className="flex-1 bg-transparent text-base outline-none placeholder:text-muted-foreground"
          />
          <button
            onClick={() => onOpenChange(false)}
            className="grid h-8 w-8 place-items-center rounded-lg text-muted-foreground hover:bg-muted"
            aria-label="إغلاق"
          >
            <X className="h-4 w-4" />
          </button>
        </div>

        <div className="max-h-[60vh] overflow-y-auto p-2">
          {!query && (
            <div className="px-3 py-2">
              <div className="text-xs font-medium uppercase tracking-wider text-muted-foreground">
                عمليات بحث شائعة
              </div>
              <div className="mt-2 flex flex-wrap gap-2">
                {POPULAR.map((p) => (
                  <button
                    key={p}
                    onClick={() => setQuery(p)}
                    className="rounded-full border border-border bg-secondary px-3 py-1.5 text-sm text-foreground transition-colors hover:border-brand hover:text-brand"
                  >
                    {p}
                  </button>
                ))}
              </div>
            </div>
          )}

          <div className="mt-2 space-y-1">
            {results.map((r) => (
              <Link
                key={r.title}
                href={r.href}
                onClick={() => onOpenChange(false)}
                className="flex items-center gap-3 rounded-xl p-3 transition-colors hover:bg-secondary group"
              >
                <span className="grid h-10 w-10 shrink-0 place-items-center rounded-lg bg-brand/10 text-brand">
                  <r.icon className="h-5 w-5" />
                </span>
                <div className="min-w-0 flex-1">
                  <div className="flex items-center gap-2">
                    <span className="font-medium text-ink">{r.title}</span>
                    <span className="rounded-full bg-secondary px-2 py-0.5 text-[10px] text-muted-foreground">
                      {r.category}
                    </span>
                  </div>
                  <div className="truncate text-sm text-muted-foreground">
                    {r.desc}
                  </div>
                </div>
                <ArrowLeft className="h-4 w-4 shrink-0 text-muted-foreground opacity-0 transition-opacity group-hover:opacity-100" />
              </Link>
            ))}
            {results.length === 0 && (
              <div className="px-4 py-10 text-center text-sm text-muted-foreground">
                لا توجد نتائج مطابقة لـ &quot;{query}&quot;
              </div>
            )}
          </div>
        </div>

        <div className="flex items-center justify-between border-t border-border bg-secondary/50 px-4 py-2.5 text-xs text-muted-foreground">
          <span>اضغط Enter للفتح · Esc للإغلاق</span>
          <span className="flex items-center gap-1">
            مدعوم بـ <span className="font-bold text-brand">Secure Home AI</span>
          </span>
        </div>
      </div>
    </div>
  );
}
