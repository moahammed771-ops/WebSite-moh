"use client";

import { Facebook, Twitter, Linkedin, Mail, Users } from "lucide-react";
import { TEAM } from "@/lib/site-data";
import { useReveal } from "@/hooks/use-reveal";
import { cn } from "@/lib/utils";

export function TeamSection() {
  const { ref, inView } = useReveal();

  return (
    <section id="team" className="relative overflow-hidden bg-ink py-20 md:py-28">
      <div className="absolute inset-0 grid-pattern-dark opacity-30" />
      <div className="absolute -top-32 left-1/3 h-72 w-72 rounded-full bg-brand/15 blur-[120px]" />

      <div className="container relative mx-auto max-w-7xl px-4">
        <div className="mx-auto max-w-2xl text-center">
          <div className="inline-flex items-center gap-2 rounded-full border border-brand/30 bg-brand/10 px-4 py-1.5 text-sm font-medium text-brand">
            <Users className="h-3.5 w-3.5" />
            فريقنا المتميز
          </div>
          <h2 className="mt-4 text-3xl font-extrabold leading-tight text-white sm:text-4xl lg:text-5xl">
            تعرف على <span className="text-gradient-brand">فريقنا</span>
          </h2>
          <p className="mt-4 text-base text-white/65 sm:text-lg">
            فريق من المهندسين والفنيين المعتمدين الشغوفين بتقديم أفضل حلول
            الأمان لك.
          </p>
        </div>

        <div
          ref={ref}
          className={cn(
            "reveal mt-14 grid gap-6 sm:grid-cols-2 lg:grid-cols-3",
            inView && "in-view"
          )}
        >
          {TEAM.map((m, i) => (
            <div
              key={m.id}
              className="group relative overflow-hidden rounded-3xl border border-white/10 bg-white/5 p-6 text-center backdrop-blur-sm transition-all hover:-translate-y-2 hover:border-brand/40 hover:bg-white/10"
              style={{ transitionDelay: `${i * 60}ms` }}
            >
              {/* Avatar */}
              <div className="relative mx-auto w-fit">
                <span
                  className="grid h-24 w-24 place-items-center rounded-full text-3xl font-extrabold text-white shadow-2xl transition-transform group-hover:scale-105"
                  style={{
                    background: `linear-gradient(135deg, ${m.color}, ${m.color}aa)`,
                    boxShadow: `0 16px 40px -10px ${m.color}66`,
                  }}
                >
                  {m.initials}
                </span>
                <span className="absolute -bottom-1 -left-1 grid h-8 w-8 place-items-center rounded-full bg-teal text-white ring-4 ring-ink">
                  <span className="h-2.5 w-2.5 rounded-full bg-white" />
                </span>
              </div>

              {/* Info */}
              <h3 className="mt-5 text-lg font-bold text-white">{m.name}</h3>
              <div
                className="mt-1 text-sm font-medium"
                style={{ color: m.color }}
              >
                {m.role}
              </div>
              <p className="mt-3 text-xs leading-relaxed text-white/55">
                {m.desc}
              </p>

              {/* Social */}
              <div className="mt-5 flex items-center justify-center gap-2 border-t border-white/10 pt-4">
                {[
                  { icon: Facebook, label: "Facebook" },
                  { icon: Twitter, label: "Twitter" },
                  { icon: Linkedin, label: "LinkedIn" },
                  { icon: Mail, label: "Email" },
                ].map((s) => (
                  <a
                    key={s.label}
                    href="#"
                    aria-label={s.label}
                    className="grid h-9 w-9 place-items-center rounded-lg bg-white/5 text-white/60 transition-colors hover:bg-brand hover:text-white"
                  >
                    <s.icon className="h-4 w-4" />
                  </a>
                ))}
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
