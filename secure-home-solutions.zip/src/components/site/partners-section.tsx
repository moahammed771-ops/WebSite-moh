"use client";

import { ShieldCheck, Award } from "lucide-react";
import { PARTNERS } from "@/lib/site-data";
import { useReveal } from "@/hooks/use-reveal";
import { cn } from "@/lib/utils";

export function PartnersSection() {
  const { ref, inView } = useReveal();

  return (
    <section id="partners" className="relative overflow-hidden bg-white py-16 md:py-20">
      <div className="container mx-auto max-w-7xl px-4">
        <div className="mx-auto max-w-2xl text-center">
          <div className="inline-flex items-center gap-2 rounded-full bg-brand/10 px-4 py-1.5 text-sm font-medium text-brand">
            <Award className="h-3.5 w-3.5" />
            شركاؤنا
          </div>
          <h2 className="mt-4 text-2xl font-extrabold leading-tight text-ink sm:text-3xl">
            شركاء النجاح <span className="text-gradient-brand">المعتمدون</span>
          </h2>
          <p className="mt-3 text-sm text-muted-foreground sm:text-base">
            نتعاون مع كبرى الشركات العالمية المصنعة لأنظمة الأمان والطاقة لنقدم
            لك أفضل المنتجات الأصلية.
          </p>
        </div>

        <div
          ref={ref}
          className={cn(
            "reveal mt-10 grid grid-cols-2 gap-4 sm:grid-cols-3 lg:grid-cols-4",
            inView && "in-view"
          )}
        >
          {PARTNERS.map((p, i) => (
            <div
              key={p.name}
              className="group flex items-center gap-3 rounded-2xl border border-border bg-gradient-to-br from-white to-secondary/40 p-4 shadow-sm transition-all hover:-translate-y-1 hover:border-brand/30 hover:shadow-lg"
              style={{ transitionDelay: `${i * 40}ms` }}
            >
              <span className="grid h-12 w-12 shrink-0 place-items-center rounded-xl bg-ink text-white transition-colors group-hover:bg-brand">
                <ShieldCheck className="h-6 w-6" />
              </span>
              <div className="min-w-0">
                <div className="truncate text-sm font-bold text-ink">
                  {p.name}
                </div>
                <div className="truncate text-xs text-muted-foreground">
                  {p.desc}
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
