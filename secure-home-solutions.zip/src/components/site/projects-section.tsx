"use client";

import { useState, useMemo } from "react";
import Image from "next/image";
import Link from "next/link";
import { MapPin, ArrowLeft, CheckCircle2 } from "lucide-react";
import { PROJECTS, PROJECT_FILTERS } from "@/lib/site-data";
import { useReveal } from "@/hooks/use-reveal";
import { cn } from "@/lib/utils";
import { Button } from "@/components/ui/button";

export function ProjectsSection() {
  const [filter, setFilter] = useState<string>("الكل");
  const { ref, inView } = useReveal();

  const filtered = useMemo(() => {
    if (filter === "الكل") return PROJECTS;
    return PROJECTS.filter((p) => p.category === filter);
  }, [filter]);

  return (
    <section id="projects" className="relative bg-gradient-to-b from-[#fff7f1] to-white py-20 md:py-28">
      <div className="container mx-auto max-w-7xl px-4">
        <div className="mx-auto max-w-2xl text-center">
          <div className="inline-flex items-center gap-2 rounded-full bg-brand/10 px-4 py-1.5 text-sm font-medium text-brand">
            <span className="h-1.5 w-1.5 rounded-full bg-brand" />
            مشاريعنا
          </div>
          <h2 className="mt-4 text-3xl font-extrabold leading-tight text-ink sm:text-4xl lg:text-5xl">
            أحدث <span className="text-gradient-brand">مشاريعنا</span>
          </h2>
          <p className="mt-4 text-base text-muted-foreground sm:text-lg">
            نفخر بأكثر من 320 مشروعاً ناجحاً في مختلف أنحاء اليمن، إليكم نماذج
            من أعمالنا.
          </p>
        </div>

        {/* Filters */}
        <div className="mt-8 flex flex-wrap items-center justify-center gap-2">
          {PROJECT_FILTERS.map((f) => (
            <button
              key={f}
              onClick={() => setFilter(f)}
              className={cn(
                "rounded-full border px-4 py-2 text-sm font-medium transition-all",
                filter === f
                  ? "border-brand bg-brand text-white shadow-lg shadow-brand/30"
                  : "border-border bg-white text-muted-foreground hover:border-brand/40 hover:text-brand"
              )}
            >
              {f}
            </button>
          ))}
        </div>

        {/* Grid */}
        <div
          ref={ref}
          className={cn(
            "reveal mt-10 grid gap-6 sm:grid-cols-2 lg:grid-cols-3",
            inView && "in-view"
          )}
        >
          {filtered.map((p, i) => (
            <article
              key={p.id}
              className="group relative overflow-hidden rounded-3xl border border-border bg-white shadow-sm transition-all hover:-translate-y-2 hover:shadow-2xl"
              style={{ transitionDelay: `${i * 60}ms` }}
            >
              <div className="relative h-56 overflow-hidden bg-ink">
                <Image
                  src={p.image}
                  alt={p.title}
                  fill
                  sizes="(max-width: 640px) 100vw, (max-width: 1024px) 50vw, 33vw"
                  className="object-cover transition-transform duration-700 group-hover:scale-110"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-ink/90 via-ink/20 to-transparent" />
                <span className="absolute top-3 right-3 flex items-center gap-1.5 rounded-full bg-brand px-3 py-1 text-xs font-bold text-white shadow-lg">
                  <p.icon className="h-3.5 w-3.5" />
                  {p.category}
                </span>
                <div className="absolute bottom-3 right-3 left-3">
                  <h3 className="text-lg font-bold text-white drop-shadow-md">
                    {p.title}
                  </h3>
                  <div className="mt-1 flex items-center gap-1.5 text-xs text-white/80">
                    <MapPin className="h-3 w-3" />
                    {p.location}
                  </div>
                </div>
              </div>
              <div className="p-5">
                <p className="text-sm leading-relaxed text-muted-foreground">
                  {p.desc}
                </p>
                <div className="mt-3 flex flex-wrap gap-1.5">
                  {p.tags.map((t) => (
                    <span
                      key={t}
                      className="inline-flex items-center gap-1 rounded-full bg-brand/10 px-2.5 py-0.5 text-[11px] font-medium text-brand"
                    >
                      <CheckCircle2 className="h-3 w-3" />
                      {t}
                    </span>
                  ))}
                </div>
              </div>
            </article>
          ))}
        </div>

        {/* CTA */}
        <div className="mt-12 text-center">
          <Button
            asChild
            size="lg"
            className="bg-ink text-white shadow-lg hover:bg-ink/90"
          >
            <Link href="/contact">
              ابدأ مشروعك معنا
              <ArrowLeft className="mr-1 h-4 w-4" />
            </Link>
          </Button>
        </div>
      </div>
    </section>
  );
}
