"use client";

import Image from "next/image";
import Link from "next/link";
import { Calendar, Clock, MessageSquare, ArrowLeft, Newspaper } from "lucide-react";
import { BLOG_POSTS } from "@/lib/site-data";
import { useReveal } from "@/hooks/use-reveal";
import { cn } from "@/lib/utils";
import { Button } from "@/components/ui/button";

const CATEGORY_COLORS: Record<string, string> = {
  نصائح: "#f05100",
  أخبار: "#009588",
  طاقة: "#fcbb00",
};

export function BlogSection() {
  const { ref, inView } = useReveal();
  const featured = BLOG_POSTS.find((p) => p.featured) || BLOG_POSTS[0];
  const others = BLOG_POSTS.filter((p) => p.id !== featured.id);

  return (
    <section id="blog" className="relative bg-white py-20 md:py-28">
      <div className="container mx-auto max-w-7xl px-4">
        <div className="mx-auto max-w-2xl text-center">
          <div className="inline-flex items-center gap-2 rounded-full bg-brand/10 px-4 py-1.5 text-sm font-medium text-brand">
            <Newspaper className="h-3.5 w-3.5" />
            المدونة
          </div>
          <h2 className="mt-4 text-3xl font-extrabold leading-tight text-ink sm:text-4xl lg:text-5xl">
            أحدث <span className="text-gradient-brand">المقالات والنصائح</span>
          </h2>
          <p className="mt-4 text-base text-muted-foreground sm:text-lg">
            مقالات ونصائح متخصصة في مجال الأمان والطاقة لمساعدتك على اتخاذ
            القرار الأمثل.
          </p>
        </div>

        <div
          ref={ref}
          className={cn(
            "reveal mt-12 grid gap-6 lg:grid-cols-2",
            inView && "in-view"
          )}
        >
          {/* Featured post */}
          <article className="group relative overflow-hidden rounded-3xl border border-border bg-ink shadow-lg transition-all hover:-translate-y-1 hover:shadow-2xl">
            <div className="relative h-64 overflow-hidden sm:h-72">
              <Image
                src={featured.image}
                alt={featured.title}
                fill
                sizes="(max-width: 1024px) 100vw, 50vw"
                className="object-cover transition-transform duration-700 group-hover:scale-105"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-ink via-ink/40 to-transparent" />
              <span
                className="absolute top-4 right-4 rounded-full px-3 py-1 text-xs font-bold text-white shadow-lg"
                style={{
                  backgroundColor: CATEGORY_COLORS[featured.category] || "#f05100",
                }}
              >
                {featured.category}
              </span>
              <span className="absolute bottom-4 right-4 left-4">
                <h3 className="text-xl font-bold leading-snug text-white drop-shadow-md sm:text-2xl">
                  {featured.title}
                </h3>
              </span>
            </div>
            <div className="p-6">
              <p className="text-sm leading-relaxed text-white/65">
                {featured.excerpt}
              </p>
              <div className="mt-4 flex items-center justify-between border-t border-white/10 pt-4">
                <div className="flex items-center gap-4 text-xs text-white/50">
                  <span className="flex items-center gap-1">
                    <Calendar className="h-3.5 w-3.5" />
                    {featured.date}
                  </span>
                  <span className="flex items-center gap-1">
                    <Clock className="h-3.5 w-3.5" />
                    {featured.readTime}
                  </span>
                  <span className="flex items-center gap-1">
                    <MessageSquare className="h-3.5 w-3.5" />
                    {featured.comments}
                  </span>
                </div>
              </div>
              <Button
                asChild
                variant="outline"
                size="sm"
                className="mt-4 w-full border-white/15 bg-white/5 text-white hover:bg-white/10 hover:text-white"
              >
                <Link href={`/blog/${featured.id}`}>
                  اقرأ المزيد
                  <ArrowLeft className="mr-1 h-4 w-4" />
                </Link>
              </Button>
            </div>
          </article>

          {/* Other posts */}
          <div className="grid gap-4">
            {others.map((post, i) => (
              <Link
                href={`/blog/${post.id}`}
                key={post.id}
                className="group flex gap-4 overflow-hidden rounded-2xl border border-border bg-white p-3 shadow-sm transition-all hover:-translate-y-0.5 hover:border-brand/30 hover:shadow-lg"
                style={{ transitionDelay: `${i * 60}ms` }}
              >
                <div className="relative h-24 w-28 shrink-0 overflow-hidden rounded-xl sm:h-28 sm:w-36">
                  <Image
                    src={post.image}
                    alt={post.title}
                    fill
                    sizes="150px"
                    className="object-cover transition-transform duration-500 group-hover:scale-110"
                  />
                </div>
                <div className="flex min-w-0 flex-1 flex-col py-1">
                  <div className="flex items-center gap-2">
                    <span
                      className="rounded-full px-2 py-0.5 text-[10px] font-bold text-white"
                      style={{
                        backgroundColor:
                          CATEGORY_COLORS[post.category] || "#f05100",
                      }}
                    >
                      {post.category}
                    </span>
                    <span className="flex items-center gap-1 text-[10px] text-muted-foreground">
                      <Calendar className="h-3 w-3" />
                      {post.date}
                    </span>
                  </div>
                  <h3 className="mt-1.5 line-clamp-2 text-sm font-bold leading-snug text-ink transition-colors group-hover:text-brand">
                    {post.title}
                  </h3>
                  <p className="mt-1 line-clamp-2 text-xs text-muted-foreground">
                    {post.excerpt}
                  </p>
                  <div className="mt-auto flex items-center gap-3 pt-2 text-[10px] text-muted-foreground">
                    <span className="flex items-center gap-1">
                      <Clock className="h-3 w-3" />
                      {post.readTime}
                    </span>
                    <span className="flex items-center gap-1">
                      <MessageSquare className="h-3 w-3" />
                      {post.comments}
                    </span>
                  </div>
                </div>
              </Link>
            ))}
          </div>
        </div>

        {/* View all */}
        <div className="mt-10 text-center">
          <Button asChild size="lg" variant="outline" className="border-brand/30 text-brand hover:bg-brand hover:text-white">
            <Link href="/blog">
              تصفّح كل المقالات
              <ArrowLeft className="mr-1 h-4 w-4" />
            </Link>
          </Button>
        </div>
      </div>
    </section>
  );
}
