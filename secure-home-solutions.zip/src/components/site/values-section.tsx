"use client";

import { useReveal } from "@/hooks/use-reveal";
import { CORE_VALUES, VISION_MISSION, STATS_SECONDARY } from "@/lib/site-data";
import { useCountUp } from "@/hooks/use-reveal";
import { cn } from "@/lib/utils";

function StatBlock({
  value,
  suffix,
  label,
}: {
  value: number;
  suffix: string;
  label: string;
}) {
  const { ref, value: v } = useCountUp(value);
  return (
    <div className="text-center">
      <div className="flex items-baseline justify-center gap-0.5">
        <span ref={ref} className="text-3xl font-extrabold text-white sm:text-4xl">
          {v}
        </span>
        <span className="text-2xl font-extrabold text-brand">{suffix}</span>
      </div>
      <div className="mt-1 text-xs font-medium text-white/55 sm:text-sm">
        {label}
      </div>
    </div>
  );
}

export function ValuesSection() {
  const { ref, inView } = useReveal();

  return (
    <>
      {/* Core values */}
      <section id="values" className="relative bg-white py-20 md:py-28">
        <div className="container mx-auto max-w-7xl px-4">
          <div className="mx-auto max-w-2xl text-center">
            <div className="inline-flex items-center gap-2 rounded-full bg-brand/10 px-4 py-1.5 text-sm font-medium text-brand">
              <span className="h-1.5 w-1.5 rounded-full bg-brand" />
              قيمنا الأساسية
            </div>
            <h2 className="mt-4 text-3xl font-extrabold leading-tight text-ink sm:text-4xl lg:text-5xl">
              المبادئ التي <span className="text-gradient-brand">نؤمن بها</span>
            </h2>
            <p className="mt-4 text-base text-muted-foreground sm:text-lg">
              قيم راسخة توجّه كل ما نقوم به، من أول استشارة حتى آخر تركيب.
            </p>
          </div>

          <div
            ref={ref}
            className={cn(
              "reveal mt-14 grid gap-6 sm:grid-cols-2 lg:grid-cols-4",
              inView && "in-view"
            )}
          >
            {CORE_VALUES.map((v, i) => (
              <div
                key={v.title}
                className="group relative overflow-hidden rounded-2xl border border-border bg-white p-6 text-center shadow-sm transition-all hover:-translate-y-2 hover:shadow-2xl"
                style={{ transitionDelay: `${i * 60}ms` }}
              >
                <div
                  className="absolute inset-x-0 top-0 h-1.5 origin-right scale-x-0 transition-transform duration-500 group-hover:scale-x-100"
                  style={{ background: v.color }}
                />
                <span
                  className="relative mx-auto grid h-16 w-16 place-items-center rounded-2xl text-white shadow-lg transition-transform group-hover:scale-110 group-hover:rotate-6"
                  style={{
                    background: `linear-gradient(135deg, ${v.color}, ${v.color}cc)`,
                    boxShadow: `0 12px 30px -8px ${v.color}66`,
                  }}
                >
                  <v.icon className="h-8 w-8" />
                </span>
                <h3 className="mt-5 text-xl font-bold text-ink">{v.title}</h3>
                <p className="mt-2 text-sm leading-relaxed text-muted-foreground">
                  {v.desc}
                </p>
                <div
                  className="mt-4 text-5xl font-black opacity-[0.06]"
                  style={{ color: v.color }}
                >
                  0{i + 1}
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Vision & Mission */}
      <section className="relative overflow-hidden bg-gradient-to-b from-white to-[#fff7f1] py-20 md:py-28">
        <div className="container mx-auto max-w-7xl px-4">
          <div className="grid gap-6 lg:grid-cols-2">
            {VISION_MISSION.map((vm) => (
              <div
                key={vm.title}
                className="group relative overflow-hidden rounded-3xl border border-brand/15 bg-white p-8 shadow-sm transition-all hover:shadow-xl md:p-10"
              >
                <div className="absolute -left-12 -top-12 h-40 w-40 rounded-full bg-brand/5 transition-transform group-hover:scale-150" />
                <div className="relative">
                  <span className="grid h-14 w-14 place-items-center rounded-2xl bg-gradient-to-br from-brand to-brand-dark text-white shadow-lg shadow-brand/30">
                    <vm.icon className="h-7 w-7" />
                  </span>
                  <h3 className="mt-5 text-2xl font-extrabold text-ink sm:text-3xl">
                    {vm.title}
                  </h3>
                  <p className="mt-3 text-base leading-relaxed text-muted-foreground sm:text-lg">
                    {vm.desc}
                  </p>
                </div>
              </div>
            ))}
          </div>

          {/* Stats bar */}
          <div className="mt-10 grid grid-cols-2 gap-6 rounded-3xl bg-ink p-8 shadow-2xl sm:grid-cols-3 lg:grid-cols-6">
            {STATS_SECONDARY.map((s) => (
              <StatBlock key={s.label} {...s} />
            ))}
          </div>
        </div>
      </section>
    </>
  );
}
