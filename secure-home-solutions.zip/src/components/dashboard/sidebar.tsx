"use client";

import { useState, useEffect } from "react";
import Link from "next/link";
import { usePathname, useRouter } from "next/navigation";
import {
  LayoutDashboard,
  FileText,
  Mail,
  Users,
  Wrench,
  FolderKanban,
  Newspaper,
  Settings,
  LogOut,
  ShieldCheck,
  Menu,
  X,
  ExternalLink,
  Home,
  Star,
  MessageCircleQuestion,
  MessagesSquare,
  Bell,
  Database,
} from "lucide-react";
import { cn } from "@/lib/utils";
import { Button } from "@/components/ui/button";

function formatDate(d: Date | string) {
  const date = typeof d === "string" ? new Date(d) : d;
  return date.toLocaleString("ar", {
    month: "short",
    day: "numeric",
    hour: "2-digit",
    minute: "2-digit",
  });
}

const NAV = [
  { href: "/dashboard", label: "نظرة عامة", icon: LayoutDashboard },
  { href: "/dashboard/quotes", label: "طلبات عروض الأسعار", icon: FileText },
  { href: "/dashboard/messages", label: "الرسائل", icon: Mail },
  { href: "/dashboard/chats", label: "سجلات المساعد", icon: MessagesSquare },
  { href: "/dashboard/subscribers", label: "المشتركون", icon: Users },
  { section: "المحتوى" },
  { href: "/dashboard/services", label: "الخدمات", icon: Wrench },
  { href: "/dashboard/projects", label: "المشاريع", icon: FolderKanban },
  { href: "/dashboard/blog", label: "المدونة", icon: Newspaper },
  { href: "/dashboard/testimonials", label: "آراء العملاء", icon: Star },
  { href: "/dashboard/team", label: "الفريق", icon: Users },
  { href: "/dashboard/faqs", label: "الأسئلة الشائعة", icon: MessageCircleQuestion },
  { section: "النظام" },
  { href: "/dashboard/settings", label: "إعدادات الموقع", icon: Settings },
  { href: "/dashboard/database", label: "قاعدة البيانات", icon: Database },
];

export function DashboardSidebar() {
  const pathname = usePathname();
  const router = useRouter();
  const [open, setOpen] = useState(false);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    setOpen(false);
  }, [pathname]);

  async function logout() {
    setLoading(true);
    await fetch("/api/admin/auth/logout", { method: "POST" });
    window.location.href = "/dashboard/login";
  }

  return (
    <>
      {/* Mobile toggle */}
      <button
        onClick={() => setOpen((v) => !v)}
        className="fixed right-4 top-4 z-50 grid h-10 w-10 place-items-center rounded-lg bg-ink text-white shadow-lg lg:hidden"
        aria-label="القائمة"
      >
        {open ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
      </button>

      {/* Overlay */}
      {open && (
        <div
          className="fixed inset-0 z-30 bg-black/50 lg:hidden"
          onClick={() => setOpen(false)}
        />
      )}

      <aside
        className={cn(
          "fixed inset-y-0 right-0 z-40 flex w-72 flex-col bg-ink text-white transition-transform duration-300 lg:translate-x-0",
          open ? "translate-x-0" : "translate-x-full lg:translate-x-0"
        )}
      >
        {/* Brand */}
        <div className="flex items-center gap-3 border-b border-white/10 p-5">
          <span className="grid h-11 w-11 place-items-center rounded-xl bg-gradient-to-br from-brand to-brand-dark shadow-lg shadow-brand/30">
            <ShieldCheck className="h-6 w-6 text-white" />
          </span>
          <div className="flex-1">
            <div className="text-sm font-extrabold">
              Secure <span className="text-brand">Home</span>
            </div>
            <div className="text-[10px] uppercase tracking-wider text-white/40">
              لوحة التحكم
            </div>
          </div>
        </div>

        {/* Nav */}
        <nav className="flex-1 space-y-1 overflow-y-auto p-3">
          {NAV.map((item, idx) => {
            if ("section" in item) {
              return (
                <div key={`s-${idx}`} className="px-3 pt-4 pb-1 text-[10px] font-bold uppercase tracking-wider text-white/30">
                  {item.section}
                </div>
              );
            }
            const active =
              item.href === "/dashboard"
                ? pathname === "/dashboard"
                : pathname.startsWith(item.href);
            return (
              <Link
                key={item.href}
                href={item.href}
                className={cn(
                  "flex items-center gap-3 rounded-xl px-3 py-2.5 text-sm font-medium transition-colors",
                  active
                    ? "bg-brand text-white shadow-lg shadow-brand/30"
                    : "text-white/65 hover:bg-white/5 hover:text-white"
                )}
              >
                <item.icon className="h-5 w-5 shrink-0" />
                <span className="flex-1">{item.label}</span>
              </Link>
            );
          })}
        </nav>

        {/* Bottom */}
        <div className="space-y-1 border-t border-white/10 p-3">
          <Link
            href="/"
            target="_blank"
            className="flex items-center gap-3 rounded-xl px-3 py-2.5 text-sm font-medium text-white/65 transition-colors hover:bg-white/5 hover:text-white"
          >
            <Home className="h-5 w-5" />
            <span className="flex-1">زيارة الموقع</span>
            <ExternalLink className="h-3.5 w-3.5" />
          </Link>
          <button
            onClick={logout}
            disabled={loading}
            className="flex w-full items-center gap-3 rounded-xl px-3 py-2.5 text-sm font-medium text-red-300 transition-colors hover:bg-red-500/10"
          >
            <LogOut className="h-5 w-5" />
            <span className="flex-1">تسجيل الخروج</span>
          </button>
        </div>
      </aside>
    </>
  );
}

export function DashboardShell({ children }: { children: React.ReactNode }) {
  return (
    <div className="min-h-screen bg-secondary/40">
      <DashboardSidebar />
      <div className="lg:pr-72">
        <TopBar />
        <main className="min-h-screen p-4 pt-4 lg:p-8 lg:pt-6">{children}</main>
      </div>
    </div>
  );
}

function TopBar() {
  const [notifs, setNotifs] = useState(0);
  const [showNotif, setShowNotif] = useState(false);
  const [recent, setRecent] = useState<{ id: string; text: string; date: string }[]>([]);

  useEffect(() => {
    fetch("/api/admin/stats")
      .then((r) => r.json())
      .then((d) => {
        if (d.ok) {
          const n = (d.stats.newQuotes || 0) + (d.stats.messages || 0);
          setNotifs(n);
          const items: { id: string; text: string; date: string }[] = [];
          (d.activity.quotes || []).slice(0, 3).forEach((q: any) =>
            items.push({ id: q.id, text: `طلب جديد من ${q.name} - ${q.service}`, date: q.createdAt })
          );
          (d.activity.messages || []).slice(0, 3).forEach((m: any) =>
            items.push({ id: m.id, text: `رسالة من ${m.name}`, date: m.createdAt })
          );
          setRecent(items.slice(0, 6));
        }
      })
      .catch(() => {});
  }, []);

  return (
    <header className="sticky top-0 z-30 flex h-16 items-center justify-between border-b border-border bg-white/80 px-4 backdrop-blur-md lg:px-8">
      <div className="flex items-center gap-2 lg:hidden">
        <span className="grid h-9 w-9 place-items-center rounded-lg bg-gradient-to-br from-brand to-brand-dark">
          <ShieldCheck className="h-5 w-5 text-white" />
        </span>
      </div>
      <div className="hidden flex-1 lg:block" />
      <div className="flex items-center gap-2">
        {/* Notifications */}
        <div className="relative">
          <button
            onClick={() => setShowNotif((v) => !v)}
            className="relative grid h-10 w-10 place-items-center rounded-xl border border-border bg-white text-muted-foreground transition-colors hover:bg-secondary"
            aria-label="الإشعارات"
          >
            <Bell className="h-5 w-5" />
            {notifs > 0 && (
              <span className="absolute -top-1 -left-1 grid h-5 min-w-[20px] place-items-center rounded-full bg-brand px-1 text-[10px] font-bold text-white ring-2 ring-white">
                {notifs}
              </span>
            )}
          </button>
          {showNotif && (
            <>
              <div className="fixed inset-0 z-10" onClick={() => setShowNotif(false)} />
              <div className="absolute left-0 top-12 z-20 w-80 overflow-hidden rounded-2xl border border-border bg-white shadow-2xl">
                <div className="flex items-center justify-between border-b border-border bg-secondary/40 p-3">
                  <span className="text-sm font-bold text-ink">الإشعارات</span>
                  <span className="rounded-full bg-brand px-2 py-0.5 text-[10px] font-bold text-white">{notifs} جديد</span>
                </div>
                <div className="max-h-80 overflow-y-auto">
                  {recent.length ? (
                    recent.map((r) => (
                      <Link key={r.id} href="/dashboard/quotes" className="block border-b border-border p-3 last:border-0 hover:bg-secondary/40" onClick={() => setShowNotif(false)}>
                        <div className="text-xs font-medium text-ink">{r.text}</div>
                        <div className="mt-0.5 text-[10px] text-muted-foreground">{formatDate(r.date)}</div>
                      </Link>
                    ))
                  ) : (
                    <div className="p-6 text-center text-xs text-muted-foreground">لا توجد إشعارات</div>
                  )}
                </div>
                <Link href="/dashboard/quotes" className="block bg-secondary/40 p-2.5 text-center text-xs font-medium text-brand hover:underline" onClick={() => setShowNotif(false)}>
                  عرض كل الطلبات
                </Link>
              </div>
            </>
          )}
        </div>
        {/* Profile */}
        <div className="flex items-center gap-2 rounded-xl border border-border bg-white px-3 py-1.5">
          <span className="grid h-8 w-8 place-items-center rounded-lg bg-ink text-xs font-bold text-white">م</span>
          <div className="hidden text-right sm:block">
            <div className="text-xs font-bold text-ink">مدير الموقع</div>
            <div className="text-[10px] text-muted-foreground">admin</div>
          </div>
        </div>
      </div>
    </header>
  );
}
