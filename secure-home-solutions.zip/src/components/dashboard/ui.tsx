"use client";

import { cn } from "@/lib/utils";
import type { LucideIcon } from "lucide-react";

export function DashboardPageHeader({
  title,
  subtitle,
  action,
}: {
  title: string;
  subtitle?: string;
  action?: React.ReactNode;
}) {
  return (
    <div className="mb-6 flex flex-wrap items-end justify-between gap-4">
      <div>
        <h1 className="text-2xl font-extrabold text-ink sm:text-3xl">{title}</h1>
        {subtitle && (
          <p className="mt-1 text-sm text-muted-foreground">{subtitle}</p>
        )}
      </div>
      {action}
    </div>
  );
}

export function StatCard({
  icon: Icon,
  label,
  value,
  sub,
  color = "#f05100",
  trend,
}: {
  icon: LucideIcon;
  label: string;
  value: string | number;
  sub?: string;
  color?: string;
  trend?: string;
}) {
  return (
    <div className="relative overflow-hidden rounded-2xl border border-border bg-white p-5 shadow-sm">
      <div
        className="absolute -left-8 -top-8 h-24 w-24 rounded-full opacity-10 blur-2xl"
        style={{ background: color }}
      />
      <div className="relative flex items-start justify-between">
        <div>
          <div className="text-xs font-medium text-muted-foreground">{label}</div>
          <div className="mt-1 text-3xl font-extrabold text-ink">{value}</div>
          {sub && <div className="mt-0.5 text-xs text-muted-foreground">{sub}</div>}
        </div>
        <span
          className="grid h-12 w-12 shrink-0 place-items-center rounded-xl text-white shadow-lg"
          style={{
            background: `linear-gradient(135deg, ${color}, ${color}cc)`,
          }}
        >
          <Icon className="h-6 w-6" />
        </span>
      </div>
      {trend && (
        <div className="relative mt-3 inline-flex items-center gap-1 rounded-full bg-teal/10 px-2 py-0.5 text-xs font-medium text-teal">
          {trend}
        </div>
      )}
    </div>
  );
}

export function Badge({
  status,
}: {
  status: string;
}) {
  const map: Record<string, string> = {
    new: "bg-blue-100 text-blue-700",
    contacted: "bg-amber-100 text-amber-700",
    won: "bg-teal/15 text-teal",
    lost: "bg-red-100 text-red-700",
    read: "bg-secondary text-muted-foreground",
  };
  const labels: Record<string, string> = {
    new: "جديد",
    contacted: "تم التواصل",
    won: "تم الإغلاق",
    lost: "ملغي",
    read: "مقروء",
  };
  return (
    <span
      className={cn(
        "inline-flex items-center rounded-full px-2.5 py-0.5 text-xs font-medium",
        map[status] || "bg-secondary text-muted-foreground"
      )}
    >
      {labels[status] || status}
    </span>
  );
}

export function EmptyState({
  icon: Icon,
  title,
  desc,
}: {
  icon: LucideIcon;
  title: string;
  desc?: string;
}) {
  return (
    <div className="flex flex-col items-center justify-center rounded-2xl border border-dashed border-border bg-white py-16 text-center">
      <span className="grid h-16 w-16 place-items-center rounded-full bg-secondary text-muted-foreground">
        <Icon className="h-8 w-8" />
      </span>
      <h3 className="mt-4 text-lg font-bold text-ink">{title}</h3>
      {desc && <p className="mt-1 max-w-sm text-sm text-muted-foreground">{desc}</p>}
    </div>
  );
}

export function formatDate(d: Date | string) {
  const date = typeof d === "string" ? new Date(d) : d;
  return date.toLocaleString("ar", {
    year: "numeric",
    month: "short",
    day: "numeric",
    hour: "2-digit",
    minute: "2-digit",
  });
}
