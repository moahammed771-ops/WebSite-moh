import type { Metadata } from "next";
import Image from "next/image";
import Link from "next/link";
import { notFound } from "next/navigation";
import {
  Calendar,
  Clock,
  MessageSquare,
  ArrowLeft,
  ChevronLeft,
  ShieldCheck,
  User,
} from "lucide-react";
import { db } from "@/lib/db";
import { BLOG_POSTS, type BlogPost } from "@/lib/site-data";
import { PublicShell } from "@/components/site/public-shell";
import { PageHeader, type BreadcrumbItem } from "@/components/site/page-header";
import { CtaBand } from "@/components/site/cta-band";
import { Button } from "@/components/ui/button";

export const dynamic = "force-dynamic";

const CATEGORY_COLORS: Record<string, string> = {
  نصائح: "#f05100",
  أخبار: "#009588",
  طاقة: "#fcbb00",
};

type BlogDetail = {
  slug: string;
  title: string;
  excerpt: string;
  content: string;
  category: string;
  date: string;
  readTime: string;
  image: string;
};

function staticContent(post: BlogPost): string {
  return `${post.excerpt}

في هذا المقال، نستعرض بالتفصيل أهم النقاط التي يجب عليك معرفتها قبل اتخاذ قرارك. نحن في Secure Home Solutions نحرص على تقديم المعلومات الدقيقة والمفيدة لمساعدتك في اختيار الحل الأمثل لاحتياجاتك.

لماذا هذا الموضوع مهم؟

يعتبر هذا الموضوع من أكثر المواضيع التي تهم عملاءنا، حيث نحتاج جميعاً إلى حلول أمان موثوقة وفعّالة تحمي ممتلكاتنا وعائلاتنا. مع التطور المستمر للتقنيات، أصبح من الضروري البقاء على اطلاع بأحدث الحلول والممارسات المثلى.

أبرز النصائح

- اختر المنتجات المعتمدة من شركات عالمية موثوقة مثل Hikvision وDahua وHoneywell.
- تأكد من تركيب الأنظمة بواسطة فريق فني معتمد لضمان الأداء الأمثل.
- اطلب ضماناً رسمياً وصيانة دورية للحفاظ على كفاءة الأنظمة على المدى الطويل.
- استفد من التقنيات الذكية مثل التنبيهات الفورية والتحكم عن بعد عبر الهاتف.

خلاصة

نحن نلتزم بتقديم أفضل حلول الأمان والطاقة بأعلى معايير الجودة. إذا كان لديك أي استفسار أو تحتاج إلى استشارة مجانية، لا تتردد في التواصل معنا. فريقنا من المهندسين المعتمدين جاهز لمساعدتك في كل خطوة.`;
}

async function getPost(slug: string): Promise<BlogDetail | null> {
  // 1) Try the database.
  try {
    const row = await db.blogPost.findUnique({ where: { slug } });
    if (row && row.published) {
      return {
        slug: row.slug,
        title: row.title,
        excerpt: row.excerpt,
        content: row.content || row.excerpt,
        category: row.category,
        date: row.date,
        readTime: row.readTime,
        image: row.image,
      };
    }
  } catch {
    // DB may be unavailable — fall through to static data.
  }

  // 2) Fall back to static BLOG_POSTS by id.
  const staticPost: BlogPost | undefined = BLOG_POSTS.find((p) => p.id === slug);
  if (!staticPost) return null;
  return {
    slug: staticPost.id,
    title: staticPost.title,
    excerpt: staticPost.excerpt,
    content: staticContent(staticPost),
    category: staticPost.category,
    date: staticPost.date,
    readTime: staticPost.readTime,
    image: staticPost.image,
  };
}

export async function generateMetadata({
  params,
}: {
  params: Promise<{ slug: string }>;
}): Promise<Metadata> {
  const { slug } = await params;
  const post = await getPost(slug);
  if (!post) return { title: "المقال غير موجود" };
  return {
    title: `${post.title} | Secure Home Solutions`,
    description: post.excerpt,
  };
}

export default async function BlogDetailPage({
  params,
}: {
  params: Promise<{ slug: string }>;
}) {
  const { slug } = await params;
  const post = await getPost(slug);
  if (!post) notFound();

  const breadcrumb: BreadcrumbItem[] = [
    { label: "المدونة", href: "/blog" },
    { label: post.title },
  ];

  const related = BLOG_POSTS.filter((p) => p.id !== post.slug).slice(0, 3);
  const accent = CATEGORY_COLORS[post.category] || "#f05100";

  return (
    <PublicShell>
      <PageHeader
        eyebrow="المدونة"
        title={post.title}
        subtitle={post.excerpt}
        breadcrumb={breadcrumb}
      />

      {/* Article */}
      <article className="relative bg-white py-16 md:py-24">
        <div className="container mx-auto max-w-4xl px-4">
          {/* Meta */}
          <div className="flex flex-wrap items-center gap-4">
            <span
              className="rounded-full px-3 py-1 text-xs font-bold text-white shadow-lg"
              style={{ backgroundColor: accent }}
            >
              {post.category}
            </span>
            <span className="flex items-center gap-1.5 text-sm text-muted-foreground">
              <Calendar className="h-4 w-4" />
              {post.date}
            </span>
            <span className="flex items-center gap-1.5 text-sm text-muted-foreground">
              <Clock className="h-4 w-4" />
              {post.readTime}
            </span>
          </div>

          {/* Hero image */}
          <div className="relative mt-6 h-64 overflow-hidden rounded-3xl bg-ink shadow-xl sm:h-80 md:h-96">
            <Image
              src={post.image}
              alt={post.title}
              fill
              sizes="(max-width: 768px) 100vw, 768px"
              className="object-cover"
              priority
            />
            <div className="absolute inset-0 bg-gradient-to-t from-ink/60 via-transparent to-transparent" />
          </div>

          {/* Content */}
          <div className="mt-10">
            <h2 className="text-2xl font-extrabold leading-snug text-ink sm:text-3xl">
              {post.title}
            </h2>
            <div className="mt-6 text-base leading-loose text-foreground/85 sm:text-lg">
              <p className="whitespace-pre-line">{post.content}</p>
            </div>
          </div>

          {/* Author box */}
          <div className="mt-12 flex items-center gap-4 rounded-3xl border border-border bg-gradient-to-l from-brand/5 to-transparent p-6">
            <span className="grid h-16 w-16 shrink-0 place-items-center rounded-2xl bg-gradient-to-br from-brand to-brand-dark text-white shadow-lg shadow-brand/30">
              <User className="h-8 w-8" />
            </span>
            <div>
              <div className="text-xs font-medium uppercase tracking-wider text-brand">
                الكاتب
              </div>
              <div className="text-lg font-extrabold text-ink">
                فريق Secure Home Solutions
              </div>
              <p className="mt-1 text-sm text-muted-foreground">
                فريق من المهندسين والخبراء في حلول الأمان والطاقة المتكاملة،
                يشاركون خبراتهم ونصائحهم لمساعدتك على حماية ما يهمك.
              </p>
            </div>
          </div>

          {/* Share / back */}
          <div className="mt-8 flex flex-wrap items-center justify-between gap-4 border-t border-border pt-6">
            <Button asChild variant="outline">
              <Link href="/blog">
                <ChevronLeft className="ml-1 h-4 w-4" />
                العودة للمدونة
              </Link>
            </Button>
            <div className="flex items-center gap-2 text-sm text-muted-foreground">
              <MessageSquare className="h-4 w-4" />
              <span>شارك المقال</span>
              <span className="flex items-center gap-1">
                {["f", "t", "in"].map((s) => (
                  <a
                    key={s}
                    href="#"
                    aria-label="مشاركة"
                    className="grid h-9 w-9 place-items-center rounded-lg border border-border bg-white text-muted-foreground transition-colors hover:border-brand hover:bg-brand hover:text-white"
                  >
                    <span className="text-xs font-bold">{s}</span>
                  </a>
                ))}
              </span>
            </div>
          </div>
        </div>
      </article>

      {/* Related posts */}
      {related.length > 0 && (
        <section className="bg-gradient-to-b from-[#fff7f1] to-white py-16 md:py-24">
          <div className="container mx-auto max-w-7xl px-4">
            <div className="mx-auto max-w-2xl text-center">
              <div className="inline-flex items-center gap-2 rounded-full bg-brand/10 px-4 py-1.5 text-sm font-medium text-brand">
                <ShieldCheck className="h-3.5 w-3.5" />
                مقالات ذات صلة
              </div>
              <h2 className="mt-4 text-3xl font-extrabold leading-tight text-ink sm:text-4xl">
                اقرأ <span className="text-gradient-brand">المزيد</span>
              </h2>
            </div>
            <div className="mt-12 grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
              {related.map((p) => (
                <Link
                  key={p.id}
                  href={`/blog/${p.id}`}
                  className="group relative flex flex-col overflow-hidden rounded-3xl border border-border bg-white shadow-sm transition-all hover:-translate-y-2 hover:shadow-2xl"
                >
                  <div className="relative h-44 overflow-hidden bg-ink">
                    <Image
                      src={p.image}
                      alt={p.title}
                      fill
                      sizes="(max-width: 640px) 100vw, 33vw"
                      className="object-cover transition-transform duration-700 group-hover:scale-110"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-ink/80 via-ink/10 to-transparent" />
                    <span
                      className="absolute top-3 right-3 rounded-full px-2.5 py-1 text-[10px] font-bold text-white shadow-lg"
                      style={{
                        backgroundColor: CATEGORY_COLORS[p.category] || "#f05100",
                      }}
                    >
                      {p.category}
                    </span>
                  </div>
                  <div className="flex flex-1 flex-col p-5">
                    <h3 className="line-clamp-2 text-base font-bold leading-snug text-ink transition-colors group-hover:text-brand">
                      {p.title}
                    </h3>
                    <p className="mt-2 line-clamp-2 text-sm text-muted-foreground">
                      {p.excerpt}
                    </p>
                    <div className="mt-4 flex items-center gap-3 text-[11px] text-muted-foreground">
                      <span className="flex items-center gap-1">
                        <Calendar className="h-3 w-3" />
                        {p.date}
                      </span>
                      <span className="flex items-center gap-1">
                        <Clock className="h-3 w-3" />
                        {p.readTime}
                      </span>
                    </div>
                  </div>
                </Link>
              ))}
            </div>
            <div className="mt-10 text-center">
              <Button asChild size="lg" variant="outline">
                <Link href="/blog">
                  تصفّح كل المقالات
                  <ArrowLeft className="mr-1 h-4 w-4" />
                </Link>
              </Button>
            </div>
          </div>
        </section>
      )}

      <CtaBand />
    </PublicShell>
  );
}
