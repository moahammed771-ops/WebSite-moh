import type { Metadata } from "next";
import { PublicShell } from "@/components/site/public-shell";
import { PageHeader } from "@/components/site/page-header";
import { BlogSection } from "@/components/site/blog-section";
import { CtaBand } from "@/components/site/cta-band";

export const metadata: Metadata = {
  title: "المدونة | Secure Home Solutions",
  description:
    "أحدث المقالات والنصائح في مجال الأمان والطاقة — كاميرات المراقبة، أنظمة الإنذار، والطاقة الشمسية.",
};

export default function BlogPage() {
  return (
    <PublicShell>
      <PageHeader
        eyebrow="المدونة"
        title="أحدث المقالات والنصائح"
        highlight="المقالات"
        subtitle="مقالات ونصائح متخصصة في مجال الأمان والطاقة لمساعدتك على اتخاذ القرار الأمثل لحماية منشأتك."
        breadcrumb={[{ label: "المدونة" }]}
      />
      <BlogSection />
      <CtaBand
        title="هل أعجبتك مقالاتنا؟ اشترك ليصلك كل جديد"
        highlight="جديد"
        desc="كن أول من يطّلع على أحدث المقالات والنصائح والعروض الحصرية. تواصل معنا لأي استفسار."
        primaryLabel="تواصل معنا"
      />
    </PublicShell>
  );
}
