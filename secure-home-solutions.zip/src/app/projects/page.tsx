import type { Metadata } from "next";
import { PublicShell } from "@/components/site/public-shell";
import { PageHeader } from "@/components/site/page-header";
import { ProjectsSection } from "@/components/site/projects-section";
import { CtaBand } from "@/components/site/cta-band";

export const metadata: Metadata = {
  title: "مشاريعنا | Secure Home Solutions",
  description:
    "أكثر من 320 مشروعاً منجزاً في مختلف أنحاء اليمن — استعرض نماذج من أعمالنا في كاميرات المراقبة، الإنتركم، إنذار الحريق والطاقة الشمسية.",
};

export default function ProjectsPage() {
  return (
    <PublicShell>
      <PageHeader
        eyebrow="مشاريعنا"
        title="أحدث مشاريعنا المنجزة"
        highlight="مشاريعنا"
        subtitle="نفخر بأكثر من 320 مشروعاً ناجحاً في مختلف أنحاء اليمن. إليكم نماذج من أعمالنا التي تعكس جودتنا واحترافيتنا."
        breadcrumb={[{ label: "مشاريعنا" }]}
      />
      <ProjectsSection />
      <CtaBand
        title="هل أنت مستعد لبدء مشروعك القادم؟"
        highlight="مشروعك"
        desc="سواء كان مشروعك صغيراً أو كبيراً، فريقنا جاهز لتحويل رؤيتك إلى واقع بأعلى معايير الجودة والاحترافية."
      />
    </PublicShell>
  );
}
