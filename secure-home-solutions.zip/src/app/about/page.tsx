import type { Metadata } from "next";
import { PublicShell } from "@/components/site/public-shell";
import { PageHeader } from "@/components/site/page-header";
import { AboutSection } from "@/components/site/about-section";
import { WhyUsSection } from "@/components/site/why-us-section";
import { ValuesSection } from "@/components/site/values-section";
import { TimelineSection } from "@/components/site/timeline-section";
import { TeamSection } from "@/components/site/team-section";
import { PartnersSection } from "@/components/site/partners-section";
import { CtaBand } from "@/components/site/cta-band";

export const metadata: Metadata = {
  title: "من نحن | Secure Home Solutions",
  description:
    "تعرّف على شركة Secure Home Solutions، رؤيتنا، قيمنا، مسيرة نجاحنا وفريقنا المتميز في حلول الأمان المنزلية المتكاملة.",
};

export default function AboutPage() {
  return (
    <PublicShell>
      <PageHeader
        eyebrow="من نحن"
        title="شريكك الموثوق في حلول الأمان"
        highlight="حلول الأمان"
        subtitle="شركة رائدة متخصصة في تصميم وتنفيذ أنظمة الأمان والحماية بأعلى المعايير العالمية، مع فريق من المهندسين والفنيين المعتمدين."
        breadcrumb={[{ label: "من نحن" }]}
      />
      <AboutSection />
      <WhyUsSection />
      <ValuesSection />
      <TimelineSection />
      <TeamSection />
      <PartnersSection />
      <CtaBand />
    </PublicShell>
  );
}
