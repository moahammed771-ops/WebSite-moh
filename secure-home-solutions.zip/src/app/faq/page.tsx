import type { Metadata } from "next";
import { PublicShell } from "@/components/site/public-shell";
import { PageHeader } from "@/components/site/page-header";
import { FaqSection } from "@/components/site/faq-section";
import { CtaBand } from "@/components/site/cta-band";

export const metadata: Metadata = {
  title: "الأسئلة الشائعة | Secure Home Solutions",
  description:
    "إجابات على أكثر الأسئلة شيوعاً حول خدماتنا في كاميرات المراقبة، الإنتركم، إنذار الحريق والطاقة الشمسية.",
};

export default function FaqPage() {
  return (
    <PublicShell>
      <PageHeader
        eyebrow="الأسئلة الشائعة"
        title="إجابات على أكثر الأسئلة شيوعاً"
        highlight="الأسئلة"
        subtitle="جمعنا لك إجابات على أكثر الأسئلة التي يطرحها عملاؤنا. لم تجد إجابتك؟ تواصل معنا مباشرة."
        breadcrumb={[{ label: "الأسئلة الشائعة" }]}
      />
      <FaqSection />
      <CtaBand
        title="لم تجد إجابة لسؤالك؟"
        highlight="سؤالك"
        desc="فريقنا جاهز للإجابة على جميع استفساراتك على مدار الساعة. لا تتردد في التواصل معنا بأي وقت."
      />
    </PublicShell>
  );
}
