"use client";

import { useEffect } from "react";
import { PublicShell } from "@/components/site/public-shell";
import { HeroSection } from "@/components/site/hero-section";
import {
  ExplorePagesSection,
  ServicesPreview,
  WhyUsPreview,
  TestimonialsPreview,
} from "@/components/site/home-highlights";
import { QuoteSection } from "@/components/site/quote-section";

export default function Home() {
  // Redirect any #dashboard hash to the real /dashboard route
  useEffect(() => {
    if (typeof window !== "undefined" && window.location.hash === "#dashboard") {
      window.location.replace("/dashboard");
    }
  }, []);

  return (
    <PublicShell>
      <HeroSection />
      <ExplorePagesSection />
      <ServicesPreview />
      <WhyUsPreview />
      <TestimonialsPreview />
      <QuoteSection />
    </PublicShell>
  );
}
