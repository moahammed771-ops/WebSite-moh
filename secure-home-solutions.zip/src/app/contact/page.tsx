import type { Metadata } from "next";
import { PublicShell } from "@/components/site/public-shell";
import { PageHeader } from "@/components/site/page-header";
import { ContactSection } from "@/components/site/contact-section";
import { QuoteSection } from "@/components/site/quote-section";

export const metadata: Metadata = {
  title: "تواصل معنا | Secure Home Solutions",
  description:
    "نحن هنا لمساعدتك على مدار الساعة. تواصل معنا عبر الهاتف، البريد الإلكتروني، أو نموذج التواصل المباشر.",
};

export default function ContactPage() {
  return (
    <PublicShell>
      <PageHeader
        eyebrow="تواصل معنا"
        title="نحن هنا لمساعدتك"
        highlight="لمساعدتك"
        subtitle="هل لديك سؤال أو استفسار؟ فريقنا جاهز للرد عليك على مدار الساعة. تواصل معنا بالطريقة التي تناسبك."
        breadcrumb={[{ label: "تواصل معنا" }]}
      />
      <ContactSection />
      <QuoteSection />
    </PublicShell>
  );
}
