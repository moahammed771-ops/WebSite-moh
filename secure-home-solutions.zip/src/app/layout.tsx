import type { Metadata } from "next";
import { Cairo, Tajawal } from "next/font/google";
import "./globals.css";
import { Toaster } from "@/components/ui/toaster";

const cairo = Cairo({
  variable: "--font-cairo",
  subsets: ["arabic", "latin"],
  weight: ["300", "400", "500", "600", "700", "800", "900"],
  display: "swap",
});

const tajawal = Tajawal({
  variable: "--font-tajawal",
  subsets: ["arabic", "latin"],
  weight: ["300", "400", "500", "700", "800"],
  display: "swap",
});

export const metadata: Metadata = {
  title: "Secure Home Solutions | حلول أمان منزلية متكاملة",
  description:
    "شركة متخصصة في تصميم وتنفيذ أنظمة كاميرات المراقبة، أنظمة الإنتركم، أنظمة إنذار الحريق، وأنظمة الطاقة الشمسية",
  keywords: [
    "كاميرات مراقبة",
    "أنظمة إنتركم",
    "إنذار حريق",
    "طاقة شمسية",
    "أمان",
    "Secure Home Solutions",
    "اليمن",
    "صنعاء",
  ],
  authors: [{ name: "Secure Home Solutions" }],
  icons: {
    icon: "/logo.svg",
  },
  openGraph: {
    title: "Secure Home Solutions | حلول أمان منزلية متكاملة",
    description:
      "حلول أمان متكاملة بأعلى جودة وأسعار منافسة مع خدمة على مدار الساعة وفريق فني محترف",
    type: "website",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="ar" dir="rtl" suppressHydrationWarning>
      <body
        className={`${cairo.variable} ${tajawal.variable} font-cairo antialiased bg-background text-foreground`}
      >
        {children}
        <Toaster />
      </body>
    </html>
  );
}
