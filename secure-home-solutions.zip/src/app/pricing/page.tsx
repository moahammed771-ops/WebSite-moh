import type { Metadata } from "next";
import { PublicShell } from "@/components/site/public-shell";
import { PageHeader } from "@/components/site/page-header";
import { PricingSection } from "@/components/site/pricing-section";
import { ComparisonSection } from "@/components/site/comparison-section";
import { FaqSection } from "@/components/site/faq-section";
import { CtaBand } from "@/components/site/cta-band";

export const metadata: Metadata = {
  title: "الأسعار | Secure Home Solutions",
  description:
    "باقات أسعار تناسب جميع الميزانيات مع ضمان رسمي وتركيب احترافي. قارن بين خدماتنا واختر الباقة المناسبة لك.",
};

export default function PricingPage() {
  return (
    <PublicShell>
      <PageHeader
        eyebrow="الأسعار"
        title="باقات تناسب احتياجاتك"
        highlight="احتياجاتك"
        subtitle="اختر الباقة المناسبة لك أو تواصل معنا لعرض سعر مخصص. جميع الباقات تشمل تركيباً احترافياً وضماناً رسمياً."
        breadcrumb={[{ label: "الأسعار" }]}
      />
      <PricingSection />
      <ComparisonSection />
      <FaqSection />
      <CtaBand
        title="هل تحتاج عرض سعر مخصص لمشروعك؟"
        highlight="مخصص"
        desc="للمشاريع الكبيرة والمنشآت التجارية، نقدم عروض أسعار مخصصة بناءً على تقييم دقيق لاحتياجاتك. تواصل معنا اليوم."
      />
    </PublicShell>
  );
}
