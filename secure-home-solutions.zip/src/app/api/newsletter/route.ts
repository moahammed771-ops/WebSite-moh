import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

export async function POST(req: NextRequest) {
  try {
    const body = await req.json().catch(() => ({}));
    const email = String(body.email || "").trim().toLowerCase();

    if (!email || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
      return NextResponse.json(
        { ok: false, error: "البريد الإلكتروني غير صالح" },
        { status: 400 }
      );
    }

    // Upsert — if email exists, reactivate
    const existing = await db.newsletterSubscriber.findUnique({
      where: { email },
    });
    if (existing) {
      await db.newsletterSubscriber.update({
        where: { email },
        data: { active: true },
      });
      return NextResponse.json({ ok: true, reactivated: true });
    }

    await db.newsletterSubscriber.create({ data: { email } });
    return NextResponse.json({ ok: true });
  } catch (err) {
    console.error("[/api/newsletter] error:", err);
    return NextResponse.json(
      { ok: false, error: "تعذّر الاشتراك" },
      { status: 500 }
    );
  }
}
