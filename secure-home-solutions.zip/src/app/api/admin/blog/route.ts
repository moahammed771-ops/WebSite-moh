import { NextRequest, NextResponse } from "next/server";
import { requireAdmin } from "@/lib/auth";
import { db } from "@/lib/db";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

export async function GET() {
  const items = await db.blogPost.findMany({
    orderBy: { createdAt: "desc" },
  });
  return NextResponse.json({ ok: true, items });
}

export async function POST(req: NextRequest) {
  try {
    await requireAdmin();
  } catch {
    return NextResponse.json({ error: "غير مصرح" }, { status: 401 });
  }
  const body = await req.json().catch(() => ({}));
  const { slug, title, excerpt, content, category, date, readTime, image, published } = body;
  if (!slug || !title) return NextResponse.json({ ok: false, error: "البيانات ناقصة" }, { status: 400 });
  const item = await db.blogPost.create({
    data: {
      slug,
      title,
      excerpt: excerpt || "",
      content: content || "",
      category: category || "عام",
      date: date || new Date().toLocaleDateString("ar"),
      readTime: readTime || "5 دقائق",
      image: image || "",
      published: published !== false,
    },
  });
  return NextResponse.json({ ok: true, item });
}

export async function PUT(req: NextRequest) {
  try {
    await requireAdmin();
  } catch {
    return NextResponse.json({ error: "غير مصرح" }, { status: 401 });
  }
  const body = await req.json().catch(() => ({}));
  const { id, ...data } = body;
  if (!id) return NextResponse.json({ ok: false, error: "ID مطلوب" }, { status: 400 });
  const item = await db.blogPost.update({ where: { id }, data });
  return NextResponse.json({ ok: true, item });
}

export async function DELETE(req: NextRequest) {
  try {
    await requireAdmin();
  } catch {
    return NextResponse.json({ error: "غير مصرح" }, { status: 401 });
  }
  const { searchParams } = new URL(req.url);
  const id = searchParams.get("id");
  if (!id) return NextResponse.json({ ok: false, error: "ID مطلوب" }, { status: 400 });
  await db.blogPost.delete({ where: { id } });
  return NextResponse.json({ ok: true });
}
