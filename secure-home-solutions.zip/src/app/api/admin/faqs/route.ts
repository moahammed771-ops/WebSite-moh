import { NextRequest, NextResponse } from "next/server";
import { requireAdmin } from "@/lib/auth";
import { db } from "@/lib/db";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

export async function GET() {
  const items = await db.fAQ.findMany({ orderBy: { order: "asc" } });
  return NextResponse.json({ ok: true, items });
}

export async function POST(req: NextRequest) {
  try { await requireAdmin(); } catch { return NextResponse.json({ error: "غير مصرح" }, { status: 401 }); }
  const b = await req.json().catch(() => ({}));
  if (!b.question || !b.answer) return NextResponse.json({ ok: false, error: "السؤال والإجابة مطلوبان" }, { status: 400 });
  const item = await db.fAQ.create({
    data: {
      question: b.question, answer: b.answer,
      category: b.category || "عام", published: b.published !== false, order: Number(b.order) || 0,
    },
  });
  return NextResponse.json({ ok: true, item });
}

export async function PUT(req: NextRequest) {
  try { await requireAdmin(); } catch { return NextResponse.json({ error: "غير مصرح" }, { status: 401 }); }
  const b = await req.json().catch(() => ({}));
  const { id, ...data } = b;
  if (!id) return NextResponse.json({ ok: false, error: "ID مطلوب" }, { status: 400 });
  if (data.order) data.order = Number(data.order);
  const item = await db.fAQ.update({ where: { id }, data });
  return NextResponse.json({ ok: true, item });
}

export async function DELETE(req: NextRequest) {
  try { await requireAdmin(); } catch { return NextResponse.json({ error: "غير مصرح" }, { status: 401 }); }
  const { searchParams } = new URL(req.url);
  const id = searchParams.get("id");
  if (!id) return NextResponse.json({ ok: false, error: "ID مطلوب" }, { status: 400 });
  await db.fAQ.delete({ where: { id } });
  return NextResponse.json({ ok: true });
}
