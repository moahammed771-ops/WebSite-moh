import { NextRequest, NextResponse } from "next/server";
import { requireAdmin } from "@/lib/auth";
import { getAllSettings, setManySettings } from "@/lib/settings";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

export async function GET() {
  try {
    await requireAdmin();
  } catch {
    return NextResponse.json({ error: "غير مصرح" }, { status: 401 });
  }
  const settings = await getAllSettings();
  return NextResponse.json({ ok: true, settings });
}

export async function PUT(req: NextRequest) {
  try {
    await requireAdmin();
  } catch {
    return NextResponse.json({ error: "غير مصرح" }, { status: 401 });
  }
  const body = await req.json().catch(() => ({}));
  const settings = body.settings;
  if (!settings || typeof settings !== "object") {
    return NextResponse.json(
      { ok: false, error: "بيانات الإعدادات مطلوبة" },
      { status: 400 }
    );
  }
  await setManySettings(settings);
  return NextResponse.json({ ok: true });
}
