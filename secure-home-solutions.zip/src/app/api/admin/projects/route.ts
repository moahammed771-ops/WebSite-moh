import { NextRequest, NextResponse } from "next/server";
import { requireAdmin } from "@/lib/auth";
import { db } from "@/lib/db";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

export async function GET() {
  const items = await db.project.findMany({
    orderBy: { createdAt: "desc" },
  });
  return NextResponse.json({ ok: true, items });
}

export async function POST(req: NextRequest) {
  try {
    await requireAdmin();
  } catch {
    return NextResponse.json({ error: "غير مصرح" }, { status: 401 });
  }
  const body = await req.json().catch(() => ({}));
  const { title, category, location, image, icon, desc, tags, featured } = body;
  if (!title) return NextResponse.json({ ok: false, error: "العنوان مطلوب" }, { status: 400 });
  const item = await db.project.create({
    data: {
      title,
      category: category || "عام",
      location: location || "",
      image: image || "",
      icon: icon || "Building2",
      desc: desc || "",
      tags: JSON.stringify(tags || []),
      featured: !!featured,
    },
  });
  return NextResponse.json({ ok: true, item });
}

export async function PUT(req: NextRequest) {
  try {
    await requireAdmin();
  } catch {
    return NextResponse.json({ error: "غير مصرح" }, { status: 401 });
  }
  const body = await req.json().catch(() => ({}));
  const { id, ...data } = body;
  if (!id) return NextResponse.json({ ok: false, error: "ID مطلوب" }, { status: 400 });
  if (data.tags && Array.isArray(data.tags)) data.tags = JSON.stringify(data.tags);
  const item = await db.project.update({ where: { id }, data });
  return NextResponse.json({ ok: true, item });
}

export async function DELETE(req: NextRequest) {
  try {
    await requireAdmin();
  } catch {
    return NextResponse.json({ error: "غير مصرح" }, { status: 401 });
  }
  const { searchParams } = new URL(req.url);
  const id = searchParams.get("id");
  if (!id) return NextResponse.json({ ok: false, error: "ID مطلوب" }, { status: 400 });
  await db.project.delete({ where: { id } });
  return NextResponse.json({ ok: true });
}
