import { NextRequest, NextResponse } from "next/server";
import { requireAdmin } from "@/lib/auth";
import fs from "fs";
import path from "path";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

const ENV_PATH = path.join(process.cwd(), ".env");

function maskUrl(url: string): string {
  if (!url) return "";
  try {
    return url.replace(/(:\/\/[^:]+:)[^@]+(@)/, "$1••••••••$2");
  } catch {
    return url;
  }
}

function readEnvFile(): Record<string, string> {
  const env: Record<string, string> = {};
  try {
    if (fs.existsSync(ENV_PATH)) {
      const content = fs.readFileSync(ENV_PATH, "utf-8");
      for (const line of content.split("\n")) {
        const trimmed = line.trim();
        if (!trimmed || trimmed.startsWith("#")) continue;
        const eqIdx = trimmed.indexOf("=");
        if (eqIdx === -1) continue;
        const key = trimmed.slice(0, eqIdx).trim();
        let value = trimmed.slice(eqIdx + 1).trim();
        if ((value.startsWith('"') && value.endsWith('"')) || (value.startsWith("'") && value.endsWith("'"))) {
          value = value.slice(1, -1);
        }
        env[key] = value;
      }
    }
  } catch {
    // ignore
  }
  return env;
}

function writeEnvFile(env: Record<string, string>) {
  const lines: string[] = [];
  for (const [key, value] of Object.entries(env)) {
    lines.push(`${key}=${value}`);
  }
  fs.writeFileSync(ENV_PATH, lines.join("\n") + "\n", "utf-8");
}

export async function GET() {
  try {
    await requireAdmin();
  } catch {
    return NextResponse.json({ error: "غير مصرح" }, { status: 401 });
  }
  const env = readEnvFile();
  const currentUrl = env.DATABASE_URL || process.env.DATABASE_URL || "";
  const provider =
    currentUrl.startsWith("postgresql://") || currentUrl.startsWith("postgres://")
      ? "postgresql"
      : currentUrl.startsWith("file:")
      ? "sqlite"
      : "unknown";
  return NextResponse.json({
    ok: true,
    config: {
      databaseUrl: maskUrl(currentUrl),
      provider,
      hasUrl: !!currentUrl,
    },
  });
}

export async function POST(req: NextRequest) {
  try {
    await requireAdmin();
  } catch {
    return NextResponse.json({ error: "غير مصرح" }, { status: 401 });
  }
  const body = await req.json().catch(() => ({}));
  const action = body.action;

  if (action === "test") {
    const testUrl = String(body.databaseUrl || "").trim();
    if (!testUrl)
      return NextResponse.json({ ok: false, error: "رابط الاتصال مطلوب" }, { status: 400 });
    if (
      !testUrl.startsWith("postgresql://") &&
      !testUrl.startsWith("postgres://") &&
      !testUrl.startsWith("file:")
    ) {
      return NextResponse.json(
        { ok: false, error: "الرابط يجب أن يبدأ بـ postgresql:// أو file:" },
        { status: 400 }
      );
    }
    if (testUrl.startsWith("file:")) {
      return NextResponse.json({ ok: true, provider: "sqlite", message: "اتصال SQLite صالح" });
    }
    try {
      const { PrismaClient } = await import("@prisma/client");
      const testClient = new PrismaClient({
        datasources: { db: { url: testUrl } },
        log: ["error"],
      });
      await testClient.$connect();
      await testClient.$queryRaw`SELECT 1`;
      await testClient.$disconnect();
      return NextResponse.json({ ok: true, provider: "postgresql", message: "تم الاتصال بنجاح ✓" });
    } catch (err) {
      const msg = err instanceof Error ? err.message : String(err);
      return NextResponse.json(
        { ok: false, error: `فشل الاتصال: ${msg.slice(0, 200)}` },
        { status: 200 }
      );
    }
  }

  if (action === "apply") {
    const newUrl = String(body.databaseUrl || "").trim();
    if (!newUrl)
      return NextResponse.json({ ok: false, error: "رابط الاتصال مطلوب" }, { status: 400 });
    if (
      !newUrl.startsWith("postgresql://") &&
      !newUrl.startsWith("postgres://") &&
      !newUrl.startsWith("file:")
    ) {
      return NextResponse.json({ ok: false, error: "الرابط غير صالح" }, { status: 400 });
    }
    try {
      const env = readEnvFile();
      env.DATABASE_URL = newUrl;
      if (newUrl.startsWith("postgresql://") || newUrl.startsWith("postgres://")) {
        env.DIRECT_URL = newUrl;
      } else {
        delete env.DIRECT_URL;
      }
      writeEnvFile(env);
      process.env.DATABASE_URL = newUrl;
      if (newUrl.startsWith("postgresql://") || newUrl.startsWith("postgres://")) {
        process.env.DIRECT_URL = newUrl;
      }
      return NextResponse.json({
        ok: true,
        message: "تم حفظ رابط قاعدة البيانات. أعد تشغيل الخادم لتطبيق التغييرات.",
        note: "restart_required",
      });
    } catch (err) {
      const msg = err instanceof Error ? err.message : String(err);
      return NextResponse.json({ ok: false, error: `تعذّر الحفظ: ${msg}` }, { status: 500 });
    }
  }

  if (action === "push-schema") {
    try {
      const { execSync } = await import("child_process");
      const env = readEnvFile();
      const dbUrl = env.DATABASE_URL || process.env.DATABASE_URL || "";
      const output = execSync("npx prisma db push --accept-data-loss --skip-generate", {
        cwd: process.cwd(),
        env: { ...process.env, DATABASE_URL: dbUrl },
        timeout: 90000,
      }).toString();
      return NextResponse.json({
        ok: true,
        message: "تم إنشاء الجداول بنجاح",
        output: output.slice(-500),
      });
    } catch (err: any) {
      const msg = err.stdout?.toString() || err.message || String(err);
      return NextResponse.json(
        { ok: false, error: `فشل: ${msg.slice(-500)}` },
        { status: 200 }
      );
    }
  }

  if (action === "seed") {
    try {
      const { execSync } = await import("child_process");
      const env = readEnvFile();
      const dbUrl = env.DATABASE_URL || process.env.DATABASE_URL || "";
      const output = execSync("bun run scripts/seed.ts", {
        cwd: process.cwd(),
        env: { ...process.env, DATABASE_URL: dbUrl },
        timeout: 90000,
      }).toString();
      return NextResponse.json({
        ok: true,
        message: "تم زرع البيانات بنجاح",
        output: output.slice(-500),
      });
    } catch (err: any) {
      const msg = err.stdout?.toString() || err.message || String(err);
      return NextResponse.json(
        { ok: false, error: `فشل: ${msg.slice(-500)}` },
        { status: 200 }
      );
    }
  }

  return NextResponse.json({ ok: false, error: "إجراء غير معروف" }, { status: 400 });
}
