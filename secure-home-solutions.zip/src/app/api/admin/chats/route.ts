import { NextResponse } from "next/server";
import { requireAdmin } from "@/lib/auth";
import { db } from "@/lib/db";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

export async function GET() {
  try { await requireAdmin(); } catch { return NextResponse.json({ error: "غير مصرح" }, { status: 401 }); }
  const items = await db.chatLog.findMany({
    orderBy: { createdAt: "desc" },
    take: 500,
    select: { id: true, sessionId: true, role: true, content: true, createdAt: true },
  });
  // Group by sessionId
  type ChatMsg = { id: string; sessionId: string; role: string; content: string; createdAt: Date };
  const sessions = new Map<string, { id: string; messages: ChatMsg[]; lastAt: Date }>();
  for (const m of items) {
    const s = sessions.get(m.sessionId) || { id: m.sessionId, messages: [], lastAt: m.createdAt };
    s.messages.push(m);
    if (m.createdAt > s.lastAt) s.lastAt = m.createdAt;
    sessions.set(m.sessionId, s);
  }
  const result = Array.from(sessions.values())
    .sort((a, b) => b.lastAt.getTime() - a.lastAt.getTime())
    .map((s) => ({
      sessionId: s.id,
      messageCount: s.messages.length,
      lastAt: s.lastAt,
      messages: s.messages.sort((a, b) => a.createdAt.getTime() - b.createdAt.getTime()),
      preview: s.messages[0]?.content.slice(0, 80) || "",
    }));
  return NextResponse.json({ ok: true, sessions: result, total: result.length });
}
