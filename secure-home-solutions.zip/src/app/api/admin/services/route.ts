import { NextRequest, NextResponse } from "next/server";
import { requireAdmin } from "@/lib/auth";
import { db } from "@/lib/db";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

export async function GET() {
  const items = await db.service.findMany({
    orderBy: { order: "asc" },
  });
  return NextResponse.json({ ok: true, items });
}

export async function POST(req: NextRequest) {
  try {
    await requireAdmin();
  } catch {
    return NextResponse.json({ error: "غير مصرح" }, { status: 401 });
  }
  const body = await req.json().catch(() => ({}));
  const { slug, num, title, shortDesc, longDesc, features, image, accent, icon, startPrice, warranty, order } = body;
  if (!slug || !title) {
    return NextResponse.json({ ok: false, error: "البيانات ناقصة" }, { status: 400 });
  }
  const item = await db.service.create({
    data: {
      slug,
      num: num || "00",
      title,
      shortDesc: shortDesc || "",
      longDesc: longDesc || "",
      features: JSON.stringify(features || []),
      image: image || "",
      accent: accent || "#f05100",
      icon: icon || "Cctv",
      startPrice: startPrice || null,
      warranty: warranty || null,
      order: order || 0,
    },
  });
  return NextResponse.json({ ok: true, item });
}

export async function PUT(req: NextRequest) {
  try {
    await requireAdmin();
  } catch {
    return NextResponse.json({ error: "غير مصرح" }, { status: 401 });
  }
  const body = await req.json().catch(() => ({}));
  const { id, ...data } = body;
  if (!id) return NextResponse.json({ ok: false, error: "ID مطلوب" }, { status: 400 });
  if (data.features && Array.isArray(data.features)) {
    data.features = JSON.stringify(data.features);
  }
  const item = await db.service.update({ where: { id }, data });
  return NextResponse.json({ ok: true, item });
}

export async function DELETE(req: NextRequest) {
  try {
    await requireAdmin();
  } catch {
    return NextResponse.json({ error: "غير مصرح" }, { status: 401 });
  }
  const { searchParams } = new URL(req.url);
  const id = searchParams.get("id");
  if (!id) return NextResponse.json({ ok: false, error: "ID مطلوب" }, { status: 400 });
  await db.service.delete({ where: { id } });
  return NextResponse.json({ ok: true });
}
