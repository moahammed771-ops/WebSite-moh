import { NextRequest, NextResponse } from "next/server";
import {
  verifyCredentials,
  createSession,
  SESSION_COOKIE_NAME,
  ensureAdminUser,
} from "@/lib/auth";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

export async function POST(req: NextRequest) {
  await ensureAdminUser();
  const body = await req.json().catch(() => ({}));
  const username = String(body.username || "").trim();
  const password = String(body.password || "").trim();

  if (!username || !password) {
    return NextResponse.json(
      { ok: false, error: "اسم المستخدم وكلمة المرور مطلوبان" },
      { status: 400 }
    );
  }

  if (!verifyCredentials(username, password)) {
    return NextResponse.json(
      { ok: false, error: "بيانات الدخول غير صحيحة" },
      { status: 401 }
    );
  }

  const token = await createSession(username);
  const res = NextResponse.json({ ok: true, username });
  res.cookies.set(SESSION_COOKIE_NAME, token, {
    httpOnly: true,
    sameSite: "lax",
    path: "/",
    maxAge: 60 * 60 * 24,
  });
  return res;
}
