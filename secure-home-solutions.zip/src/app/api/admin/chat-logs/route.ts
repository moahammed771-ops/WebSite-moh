import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { isAuthenticated } from "@/lib/auth";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

export async function GET(req: NextRequest) {
  const authed = await isAuthenticated();
  if (!authed) {
    return NextResponse.json({ error: "غير مصرح" }, { status: 401 });
  }
  const url = new URL(req.url);

  // Return grouped by sessionId
  const logs = await db.chatLog.findMany({
    orderBy: { createdAt: "desc" },
    take: 500,
  });

  // Group by session
  const sessionsMap = new Map<string, { sessionId: string; messages: typeof logs; createdAt: Date }>();
  for (const log of logs) {
    const existing = sessionsMap.get(log.sessionId);
    if (!existing) {
      sessionsMap.set(log.sessionId, {
        sessionId: log.sessionId,
        messages: [log],
        createdAt: log.createdAt,
      });
    } else {
      existing.messages.push(log);
    }
  }

  const sessions = Array.from(sessionsMap.values())
    .map((s) => ({
      sessionId: s.sessionId,
      messageCount: s.messages.length,
      createdAt: s.createdAt,
      preview:
        s.messages.find((m) => m.role === "user")?.content?.slice(0, 100) || "",
      messages: s.messages
        .sort((a, b) => a.createdAt.getTime() - b.createdAt.getTime())
        .map((m) => ({ role: m.role, content: m.content, createdAt: m.createdAt })),
    }))
    .sort((a, b) => b.createdAt.getTime() - a.createdAt.getTime());

  return NextResponse.json({ sessions });
}
