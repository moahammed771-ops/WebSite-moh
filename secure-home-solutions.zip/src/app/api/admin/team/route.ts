import { NextRequest, NextResponse } from "next/server";
import { requireAdmin } from "@/lib/auth";
import { db } from "@/lib/db";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

export async function GET() {
  const items = await db.teamMember.findMany({ orderBy: { order: "asc" } });
  return NextResponse.json({ ok: true, items });
}

export async function POST(req: NextRequest) {
  try { await requireAdmin(); } catch { return NextResponse.json({ error: "غير مصرح" }, { status: 401 }); }
  const b = await req.json().catch(() => ({}));
  if (!b.name) return NextResponse.json({ ok: false, error: "الاسم مطلوب" }, { status: 400 });
  const item = await db.teamMember.create({
    data: {
      name: b.name, role: b.role || "", desc: b.desc || "",
      initials: b.initials || b.name.slice(0, 1),
      color: b.color || "#f05100", order: Number(b.order) || 0,
    },
  });
  return NextResponse.json({ ok: true, item });
}

export async function PUT(req: NextRequest) {
  try { await requireAdmin(); } catch { return NextResponse.json({ error: "غير مصرح" }, { status: 401 }); }
  const b = await req.json().catch(() => ({}));
  const { id, ...data } = b;
  if (!id) return NextResponse.json({ ok: false, error: "ID مطلوب" }, { status: 400 });
  if (data.order) data.order = Number(data.order);
  const item = await db.teamMember.update({ where: { id }, data });
  return NextResponse.json({ ok: true, item });
}

export async function DELETE(req: NextRequest) {
  try { await requireAdmin(); } catch { return NextResponse.json({ error: "غير مصرح" }, { status: 401 }); }
  const { searchParams } = new URL(req.url);
  const id = searchParams.get("id");
  if (!id) return NextResponse.json({ ok: false, error: "ID مطلوب" }, { status: 400 });
  await db.teamMember.delete({ where: { id } });
  return NextResponse.json({ ok: true });
}
