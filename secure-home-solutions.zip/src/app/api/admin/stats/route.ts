import { NextResponse } from "next/server";
import { requireAdmin } from "@/lib/auth";
import {
  getStats,
  getRecentActivity,
  getQuotesByService,
  getQuotesTrend,
  getQuotesByStatus,
} from "@/lib/settings";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

export async function GET() {
  try {
    await requireAdmin();
  } catch {
    return NextResponse.json({ error: "غير مصرح" }, { status: 401 });
  }
  const [stats, activity, byService, trend, byStatus] = await Promise.all([
    getStats(),
    getRecentActivity(),
    getQuotesByService(),
    getQuotesTrend(),
    getQuotesByStatus(),
  ]);
  return NextResponse.json({
    ok: true,
    stats,
    activity,
    charts: { byService, trend, byStatus },
  });
}
