import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

export async function POST(req: NextRequest) {
  try {
    const body = await req.json().catch(() => ({}));
    const name = String(body.name || "").trim();
    const phone = String(body.phone || "").trim();
    const email = body.email ? String(body.email).trim() : null;
    const subject = body.subject ? String(body.subject).trim() : null;
    const messageBody = String(body.message || body.body || "").trim();

    if (!name || !phone || !messageBody) {
      return NextResponse.json(
        { ok: false, error: "الحقول المطلوبة ناقصة" },
        { status: 400 }
      );
    }

    const record = await db.message.create({
      data: { name, phone, email, subject, body: messageBody },
    });

    return NextResponse.json({ ok: true, id: record.id });
  } catch (err) {
    console.error("[/api/contact] error:", err);
    return NextResponse.json(
      { ok: false, error: "تعذّر حفظ الرسالة" },
      { status: 500 }
    );
  }
}
