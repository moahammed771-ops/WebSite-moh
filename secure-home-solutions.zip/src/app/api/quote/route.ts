import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

const VALID_SERVICES = new Set([
  "كاميرات المراقبة",
  "أنظمة الإنتركم",
  "إنذار الحريق",
  "الطاقة الشمسية",
  "استشارة عامة",
  "صيانة ودعم",
]);

export async function POST(req: NextRequest) {
  try {
    const body = await req.json().catch(() => ({}));
    const name = String(body.name || "").trim();
    const phone = String(body.phone || "").trim();
    const email = body.email ? String(body.email).trim() : null;
    const service = String(body.service || "").trim();
    const message = body.message ? String(body.message).trim() : null;
    const subject = body.subject ? String(body.subject).trim() : null;

    if (!name || !phone || !service) {
      return NextResponse.json(
        { ok: false, error: "الحقول المطلوبة ناقصة" },
        { status: 400 }
      );
    }
    if (phone.length < 6) {
      return NextResponse.json(
        { ok: false, error: "رقم الجوال غير صالح" },
        { status: 400 }
      );
    }
    if (email && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
      return NextResponse.json(
        { ok: false, error: "البريد الإلكتروني غير صالح" },
        { status: 400 }
      );
    }

    const record = await db.quoteRequest.create({
      data: { name, phone, email, service, message },
    });

    // If this came from the contact form (service === "رسالة تواصل"), also save as message
    if (service === "رسالة تواصل" && message) {
      await db.message.create({
        data: {
          name,
          phone,
          email,
          subject: subject || "رسالة من نموذج التواصل",
          body: message,
        },
      });
    }

    return NextResponse.json({ ok: true, id: record.id });
  } catch (err) {
    console.error("[/api/quote] error:", err);
    return NextResponse.json(
      { ok: false, error: "تعذّر حفظ الطلب" },
      { status: 500 }
    );
  }
}

export async function GET() {
  try {
    const count = await db.quoteRequest.count();
    return NextResponse.json({ ok: true, count });
  } catch {
    return NextResponse.json({ ok: true, count: 0 });
  }
}
