import { NextRequest, NextResponse } from "next/server";
import ZAI from "z-ai-web-dev-sdk";
import { db } from "@/lib/db";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

const SYSTEM_PROMPT = `أنت "المساعد الذكي" لشركة Secure Home Solutions (حلول أمان منزلية متكاملة)، وهي شركة يمنية رائدة متخصصة في تصميم وتنفيذ أنظمة الأمان والحماية، مقرها صنعاء، شارع الزبيري، اليمن.

معلومات الشركة:
- الهاتف: +967 734 066 962
- البريد: info@securehome.com
- ساعات العمل: السبت - الخميس: 8 ص - 6 م
- تأسست عام 2019، +320 مشروع منجز، +6 سنوات خبرة، فريق من +48 فني محترف

الخدمات التي نقدمها:
1. كاميرات المراقبة: كاميرات IP وHD و4K فائقة الدقة، رؤية ليلية متقدمة، تنبيهات ذكية عبر الهاتف، تخزين سحابي آمن، تقنيات الذكاء الاصطناعي.
2. أنظمة الإنتركم: إنتركم صوتي ومرئي عالي الدقة، فتح الأبواب عن بعد، تكامل مع الهاتف الذكي، تحكم بصمة الوجه.
3. إنذار الحريق: كواشف دخان وحرارة ذكية فورية، إطفاء تلقائي بالرغوة، ربط مع غرفة التحكم، صيانة دورية معتمدة.
4. الطاقة الشمسية: ألواح شمسية عالية الكفاءة، بطاريات ليثيوم طويلة العمر، أنفرتر ذكي متطور، ضمان حتى 25 سنة، توفير حتى 70% من فاتورة الكهرباء.

الاعتمادات: معتمدون من Hikvision، وكلاء Dahua المعتمدون، شهادات سلامة الحريق، تركيب احترافي معتمد، شهادة ISO 9001.

قيم الشركة: الجودة، الأمان، الابتكار، الثقة. خدمة 24/7، فنيين مدربين، أسعار منافسة.

تعليمات الرد:
- أجب دائماً باللغة العربية الفصحى المبسطة بأسلوب ودود ومهني ومختصر.
- كن مفيداً ودقيقاً. إذا كان السؤال عن خدمة، اشرحها بإيجاز وأبرز ميزاتها.
- إذا طلب العميل سعراً، وضّح أن الأسعار تعتمد على حجم المشروع والمعدات المختارة، وادعه لطلب عرض سعر مجاني عبر نموذج "طلب عرض سعر" أو الاتصال على +967 734 066 962.
- إذا كان السؤال خارج نطاق خدماتنا، وجّه العميل بلطف إلى خدماتنا أو رقم التواصل.
- لا تختلق أسعاراً محددة أو مواعيد وهمية.
- استخدم رموز تعبيرية باعتدال (مثل ✅ 🔒 ☀️) لتوضيح النقاط.
- اجعل الردود مختصرة (3-6 أسطر عادة) ما لم يطلب العميل تفصيلاً أكثر.
- في النهاية، إذا كان الاستفسار يحتاج متابعة، اقترح الاتصال على +967 734 066 962 أو تعبئة نموذج طلب عرض سعر.`;

export async function POST(req: NextRequest) {
  try {
    const body = await req.json().catch(() => ({}));
    const history: Array<{ role: string; content: string }> = Array.isArray(
      body.messages
    )
      ? body.messages
      : [];

    if (history.length === 0) {
      return NextResponse.json(
        { error: "الرسالة مطلوبة" },
        { status: 400 }
      );
    }

    // Keep only the last 10 messages to control context size
    const recent = history.slice(-10);

    const messages: Array<{ role: "user" | "system" | "assistant"; content: string }> = [
      { role: "assistant", content: SYSTEM_PROMPT },
      ...recent.map((m) => ({
        role: (m.role === "assistant" ? "assistant" : "user") as "user" | "assistant",
        content: m.content,
      })),
    ];

    const zai = await ZAI.create();
    const completion = await zai.chat.completions.create({
      messages,
      thinking: { type: "disabled" },
    });

    const reply =
      completion.choices[0]?.message?.content?.trim() ||
      "عذراً، لم أتمكن من توليد رد. حاول مرة أخرى.";

    // Log conversation to DB (non-blocking, ignore errors)
    const sessionId =
      (body.sessionId as string) || `s-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`;
    try {
      const lastUser = recent[recent.length - 1];
      if (lastUser && lastUser.role === "user") {
        await db.chatLog.createMany({
          data: [
            { sessionId, role: "user", content: lastUser.content },
            { sessionId, role: "assistant", content: reply },
          ],
        });
      }
    } catch {
      // ignore logging errors
    }

    return NextResponse.json({ reply, sessionId });
  } catch (err) {
    console.error("[/api/chat] error:", err);
    return NextResponse.json(
      {
        reply:
          "عذراً، حدث خطأ مؤقت. يمكنك الاتصال بنا مباشرة على +967 734 066 962.",
        error: true,
      },
      { status: 200 }
    );
  }
}
