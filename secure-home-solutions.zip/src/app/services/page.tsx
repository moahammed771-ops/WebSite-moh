import type { Metadata } from "next";
import { PublicShell } from "@/components/site/public-shell";
import { PageHeader } from "@/components/site/page-header";
import { ServicesSection } from "@/components/site/services-section";
import { ComparisonSection } from "@/components/site/comparison-section";
import { ProductsSection } from "@/components/site/products-section";
import { ProcessSection } from "@/components/site/process-section";
import { CtaBand } from "@/components/site/cta-band";

export const metadata: Metadata = {
  title: "خدماتنا | Secure Home Solutions",
  description:
    "كاميرات المراقبة، أنظمة الإنتركم، إنذار الحريق، وأنظمة الطاقة الشمسية — حلول أمان متكاملة بأحدث التقنيات وضمان رسمي.",
};

export default function ServicesPage() {
  return (
    <PublicShell>
      <PageHeader
        eyebrow="خدماتنا"
        title="خدمات أمان وطاقة متكاملة"
        highlight="متكاملة"
        subtitle="نقدم مجموعة شاملة من خدمات الأمان والطاقة المصممة بأحدث التقنيات العالمية من أفضل الشركات المصنعة المعتمدة."
        breadcrumb={[{ label: "خدماتنا" }]}
      />
      <ServicesSection />
      <ComparisonSection />
      <ProductsSection />
      <ProcessSection />
      <CtaBand
        title="هل تحتاج استشارة في اختيار الخدمة المناسبة؟"
        highlight="استشارة"
        desc="فريقنا من المهندسين المعتمدين جاهز لمساعدتك في تصميم الحل الأمثل لاحتياجاتك. احصل على استشارة مجانية اليوم."
      />
    </PublicShell>
  );
}
