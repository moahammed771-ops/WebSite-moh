import type { Metadata } from "next";
import Image from "next/image";
import Link from "next/link";
import { notFound } from "next/navigation";
import {
  Cctv,
  DoorClosed,
  Flame,
  SunMedium,
  Check,
  ChevronLeft,
  ArrowLeft,
  ShieldCheck,
  Clock,
  Award,
  Wrench,
  type LucideIcon,
} from "lucide-react";
import { db } from "@/lib/db";
import {
  SERVICES,
  COMPARISON_SERVICES,
  PROJECTS,
  type Service,
} from "@/lib/site-data";
import { PublicShell } from "@/components/site/public-shell";
import { PageHeader, type BreadcrumbItem } from "@/components/site/page-header";
import { CtaBand } from "@/components/site/cta-band";
import { Button } from "@/components/ui/button";

export const dynamic = "force-dynamic";

const ICON_MAP: Record<string, LucideIcon> = {
  Cctv,
  DoorClosed,
  Flame,
  SunMedium,
};

type ServiceDetail = {
  slug: string;
  num: string;
  title: string;
  shortDesc: string;
  longDesc: string;
  features: string[];
  image: string;
  accent: string;
  icon: LucideIcon;
  startPrice?: string;
  warranty?: string;
};

const CATEGORY_BY_SERVICE: Record<string, string> = {
  cctv: "كاميرات مراقبة",
  intercom: "أنظمة إنتركم",
  fire: "إنذار حريق",
  solar: "طاقة شمسية",
};

async function getService(slug: string): Promise<ServiceDetail | null> {
  // 1) Try the database.
  try {
    const row = await db.service.findUnique({ where: { slug } });
    if (row) {
      let features: string[] = [];
      try {
        const parsed = JSON.parse(row.features);
        if (Array.isArray(parsed)) features = parsed.filter((f) => typeof f === "string");
      } catch {
        features = [];
      }
      return {
        slug: row.slug,
        num: row.num,
        title: row.title,
        shortDesc: row.shortDesc,
        longDesc: row.longDesc || row.shortDesc,
        features: features.length ? features : [],
        image: row.image,
        accent: row.accent,
        icon: ICON_MAP[row.icon] || ShieldCheck,
        startPrice: row.startPrice || undefined,
        warranty: row.warranty || undefined,
      };
    }
  } catch {
    // DB may be unavailable — fall through to static data.
  }

  // 2) Fall back to static SERVICES by id.
  const staticService: Service | undefined = SERVICES.find((s) => s.id === slug);
  if (!staticService) return null;
  const comparison = COMPARISON_SERVICES.find((c) => c.id === slug);
  return {
    slug: staticService.id,
    num: staticService.num,
    title: staticService.title,
    shortDesc: staticService.desc,
    longDesc:
      staticService.desc +
      " نلتزم بأعلى معايير الجودة في التركيب والصيانة، مع ضمان رسمي ودعم فني متواصل على مدار الساعة. فريقنا من المهندسين المعتمدين يضمن لك حلاً موثوقاً وفعّالاً يلبي احتياجاتك بأفضل الأسعار.",
    features: [...staticService.features],
    image: staticService.image,
    accent: staticService.accent,
    icon: staticService.icon,
    startPrice: comparison?.startPrice,
    warranty: comparison?.warranty,
  };
}

export async function generateMetadata({
  params,
}: {
  params: Promise<{ slug: string }>;
}): Promise<Metadata> {
  const { slug } = await params;
  const service = await getService(slug);
  if (!service) return { title: "الخدمة غير موجودة" };
  return {
    title: `${service.title} | Secure Home Solutions`,
    description: service.shortDesc,
  };
}

export default async function ServiceDetailPage({
  params,
}: {
  params: Promise<{ slug: string }>;
}) {
  const { slug } = await params;
  const service = await getService(slug);
  if (!service) notFound();

  const breadcrumb: BreadcrumbItem[] = [
    { label: "خدماتنا", href: "/services" },
    { label: service.title },
  ];

  const related = SERVICES.filter((s) => s.id !== service.slug).slice(0, 3);
  const galleryCategory = CATEGORY_BY_SERVICE[service.slug];
  const gallery = galleryCategory
    ? PROJECTS.filter((p) => p.category === galleryCategory).slice(0, 3)
    : [];

  const Icon = service.icon;

  return (
    <PublicShell>
      <PageHeader
        eyebrow={`خدمة ${service.num}`}
        title={service.title}
        subtitle={service.shortDesc}
        breadcrumb={breadcrumb}
      />

      {/* Hero / overview */}
      <section className="relative bg-white py-16 md:py-24">
        <div className="container mx-auto max-w-7xl px-4">
          <div className="grid items-start gap-10 lg:grid-cols-2">
            {/* Image */}
            <div className="relative">
              <div className="relative overflow-hidden rounded-3xl bg-ink shadow-2xl">
                <div className="relative h-72 sm:h-96">
                  <Image
                    src={service.image}
                    alt={service.title}
                    fill
                    sizes="(max-width: 1024px) 100vw, 50vw"
                    className="object-cover"
                    priority
                  />
                  <div
                    className="absolute inset-0 opacity-50 mix-blend-multiply"
                    style={{
                      background: `linear-gradient(135deg, ${service.accent}cc, transparent 60%)`,
                    }}
                  />
                </div>
                <span
                  className="absolute top-5 right-5 grid h-16 w-16 place-items-center rounded-2xl text-white shadow-xl"
                  style={{ backgroundColor: `${service.accent}e6` }}
                >
                  <Icon className="h-8 w-8" />
                </span>
                <span className="absolute bottom-5 left-5 text-7xl font-black text-white/25">
                  {service.num}
                </span>
              </div>

              {/* Price / warranty badges */}
              <div className="mt-5 grid grid-cols-2 gap-4">
                <div className="rounded-2xl border border-border bg-white p-5 shadow-sm">
                  <div className="text-xs text-muted-foreground">سعر البداية</div>
                  <div
                    className="mt-1 text-2xl font-extrabold"
                    style={{ color: service.accent }}
                  >
                    {service.startPrice || "حسب الطلب"}
                  </div>
                </div>
                <div className="rounded-2xl border border-border bg-white p-5 shadow-sm">
                  <div className="text-xs text-muted-foreground">الضمان</div>
                  <div className="mt-1 text-2xl font-extrabold text-ink">
                    {service.warranty || "حتى 5 سنوات"}
                  </div>
                </div>
              </div>
            </div>

            {/* Content */}
            <div>
              <div
                className="inline-flex items-center gap-2 rounded-full px-4 py-1.5 text-sm font-medium"
                style={{
                  backgroundColor: `${service.accent}1a`,
                  color: service.accent,
                }}
              >
                <span
                  className="h-1.5 w-1.5 rounded-full"
                  style={{ backgroundColor: service.accent }}
                />
                تفاصيل الخدمة
              </div>
              <h2 className="mt-4 text-3xl font-extrabold leading-tight text-ink sm:text-4xl">
                {service.title}
              </h2>
              <p className="mt-5 text-base leading-relaxed text-muted-foreground sm:text-lg">
                {service.longDesc}
              </p>

              {/* Features grid */}
              <div className="mt-8">
                <h3 className="text-lg font-bold text-ink">أبرز المميزات</h3>
                <ul className="mt-4 grid gap-3 sm:grid-cols-2">
                  {service.features.map((f) => (
                    <li
                      key={f}
                      className="flex items-center gap-2.5 rounded-xl border border-border bg-white p-3 text-sm font-medium text-ink shadow-sm"
                    >
                      <span
                        className="grid h-6 w-6 shrink-0 place-items-center rounded-full text-white"
                        style={{ backgroundColor: service.accent }}
                      >
                        <Check className="h-3.5 w-3.5" />
                      </span>
                      {f}
                    </li>
                  ))}
                </ul>
              </div>

              <div className="mt-8 flex flex-wrap gap-3">
                <Button
                  asChild
                  size="lg"
                  className="text-white shadow-lg"
                  style={{
                    backgroundColor: service.accent,
                    boxShadow: `0 10px 28px -8px ${service.accent}66`,
                  }}
                >
                  <Link href="/contact">
                    اطلب هذه الخدمة
                    <ChevronLeft className="mr-1 h-4 w-4" />
                  </Link>
                </Button>
                <Button asChild size="lg" variant="outline">
                  <Link href="/services">جميع الخدمات</Link>
                </Button>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Trust strip */}
      <section className="bg-gradient-to-b from-white to-[#fff7f1] py-12">
        <div className="container mx-auto max-w-7xl px-4">
          <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
            {[
              { icon: Award, label: "خبرة 6+ سنوات" },
              { icon: ShieldCheck, label: "ضمان رسمي معتمد" },
              { icon: Clock, label: "دعم فني 24/7" },
              { icon: Wrench, label: "تركيب احترافي" },
            ].map((b) => (
              <div
                key={b.label}
                className="flex items-center gap-3 rounded-2xl border border-border bg-white p-4 shadow-sm"
              >
                <span className="grid h-11 w-11 place-items-center rounded-xl bg-brand/10 text-brand">
                  <b.icon className="h-5 w-5" />
                </span>
                <span className="text-sm font-bold text-ink">{b.label}</span>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Gallery */}
      {gallery.length > 0 && (
        <section className="bg-white py-16 md:py-24">
          <div className="container mx-auto max-w-7xl px-4">
            <div className="mx-auto max-w-2xl text-center">
              <div className="inline-flex items-center gap-2 rounded-full bg-brand/10 px-4 py-1.5 text-sm font-medium text-brand">
                <span className="h-1.5 w-1.5 rounded-full bg-brand" />
                معرض الأعمال
              </div>
              <h2 className="mt-4 text-3xl font-extrabold leading-tight text-ink sm:text-4xl">
                مشاريعنا في <span className="text-gradient-brand">{service.title}</span>
              </h2>
              <p className="mt-4 text-base text-muted-foreground sm:text-lg">
                نماذج من مشاريعنا المنجزة في هذا المجال.
              </p>
            </div>
            <div className="mt-12 grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
              {gallery.map((p) => (
                <div
                  key={p.id}
                  className="group relative overflow-hidden rounded-3xl border border-border bg-white shadow-sm transition-all hover:-translate-y-1.5 hover:shadow-2xl"
                >
                  <div className="relative h-52 overflow-hidden bg-ink">
                    <Image
                      src={p.image}
                      alt={p.title}
                      fill
                      sizes="(max-width: 640px) 100vw, 33vw"
                      className="object-cover transition-transform duration-700 group-hover:scale-110"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-ink/90 via-ink/20 to-transparent" />
                    <div className="absolute bottom-4 right-4 left-4">
                      <h3 className="text-lg font-bold text-white drop-shadow-md">
                        {p.title}
                      </h3>
                      <div className="mt-1 text-xs text-white/80">{p.location}</div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
            <div className="mt-10 text-center">
              <Button asChild size="lg" variant="outline">
                <Link href="/projects">
                  تصفّح كل المشاريع
                  <ArrowLeft className="mr-1 h-4 w-4" />
                </Link>
              </Button>
            </div>
          </div>
        </section>
      )}

      {/* Related services */}
      <section className="bg-gradient-to-b from-[#fff7f1] to-white py-16 md:py-24">
        <div className="container mx-auto max-w-7xl px-4">
          <div className="mx-auto max-w-2xl text-center">
            <div className="inline-flex items-center gap-2 rounded-full bg-brand/10 px-4 py-1.5 text-sm font-medium text-brand">
              <span className="h-1.5 w-1.5 rounded-full bg-brand" />
              خدمات ذات صلة
            </div>
            <h2 className="mt-4 text-3xl font-extrabold leading-tight text-ink sm:text-4xl">
              استكشف <span className="text-gradient-brand">خدماتنا الأخرى</span>
            </h2>
          </div>
          <div className="mt-12 grid gap-6 md:grid-cols-3">
            {related.map((s) => (
              <Link
                key={s.id}
                href={`/services/${s.id}`}
                className="group relative flex flex-col overflow-hidden rounded-3xl border border-border bg-white shadow-sm transition-all hover:-translate-y-2 hover:shadow-2xl"
              >
                <div className="relative h-40 overflow-hidden bg-ink">
                  <Image
                    src={s.image}
                    alt={s.title}
                    fill
                    sizes="(max-width: 768px) 100vw, 33vw"
                    className="object-cover transition-transform duration-700 group-hover:scale-110"
                  />
                  <div
                    className="absolute inset-0 opacity-60 mix-blend-multiply"
                    style={{
                      background: `linear-gradient(135deg, ${s.accent}99, transparent 60%)`,
                    }}
                  />
                  <span
                    className="absolute top-4 right-4 grid h-11 w-11 place-items-center rounded-xl text-white shadow-lg"
                    style={{ backgroundColor: `${s.accent}e6` }}
                  >
                    <s.icon className="h-5 w-5" />
                  </span>
                </div>
                <div className="p-5">
                  <h3 className="text-lg font-extrabold text-ink">{s.title}</h3>
                  <p className="mt-2 line-clamp-2 text-sm text-muted-foreground">
                    {s.desc}
                  </p>
                  <span
                    className="mt-3 inline-flex items-center gap-1 text-sm font-bold"
                    style={{ color: s.accent }}
                  >
                    عرض التفاصيل
                    <ChevronLeft className="h-4 w-4 transition-transform group-hover:-translate-x-1" />
                  </span>
                </div>
              </Link>
            ))}
          </div>
        </div>
      </section>

      <CtaBand />
    </PublicShell>
  );
}
