"use client";

import { useState } from "react";
import { ShieldCheck, Loader2, Lock, User, ArrowLeft, Eye, EyeOff } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useToast } from "@/hooks/use-toast";
import Link from "next/link";

export default function LoginPage() {
  const [username, setUsername] = useState("admin");
  const [password, setPassword] = useState("admin123");
  const [showPw, setShowPw] = useState(false);
  const [loading, setLoading] = useState(false);
  const { toast } = useToast();

  async function onSubmit(e: React.FormEvent) {
    e.preventDefault();
    setLoading(true);
    try {
      const res = await fetch("/api/admin/auth/login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ username, password }),
      });
      const data = await res.json();
      if (!res.ok || !data.ok) {
        throw new Error(data.error || "فشل الدخول");
      }
      toast({ title: "تم تسجيل الدخول", description: "مرحباً بك في لوحة التحكم" });
      // Use full page reload (not client-side router) to ensure the
      // server-side auth check reads the freshly-set cookie reliably.
      window.location.href = "/dashboard";
    } catch (err) {
      toast({
        variant: "destructive",
        title: "تعذّر الدخول",
        description: err instanceof Error ? err.message : "خطأ غير معروف",
      });
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="relative flex min-h-screen items-center justify-center overflow-hidden bg-ink p-4">
      <div className="absolute inset-0 grid-pattern-dark opacity-40" />
      <div className="absolute -top-32 -left-32 h-96 w-96 rounded-full bg-brand/20 blur-[120px]" />
      <div className="absolute -bottom-32 -right-32 h-96 w-96 rounded-full bg-teal/15 blur-[120px]" />

      <div className="relative w-full max-w-md">
        <Link
          href="/"
          className="mb-6 inline-flex items-center gap-2 text-sm text-white/60 transition-colors hover:text-white"
        >
          <ArrowLeft className="h-4 w-4" />
          العودة للموقع
        </Link>

        <div className="overflow-hidden rounded-3xl border border-white/10 bg-white/5 p-8 shadow-2xl backdrop-blur-md">
          <div className="flex flex-col items-center text-center">
            <span className="relative grid h-16 w-16 place-items-center rounded-2xl bg-gradient-to-br from-brand to-brand-dark shadow-lg shadow-brand/30">
              <ShieldCheck className="h-8 w-8 text-white" />
            </span>
            <h1 className="mt-4 text-2xl font-extrabold text-white">لوحة التحكم</h1>
            <p className="mt-1 text-sm text-white/60">
              سجّل دخولك لإدارة موقع Secure Home Solutions
            </p>
          </div>

          <form onSubmit={onSubmit} className="mt-7 space-y-4">
            <div className="space-y-1.5">
              <Label htmlFor="username" className="text-white/80">
                اسم المستخدم
              </Label>
              <div className="relative">
                <User className="absolute right-3 top-1/2 h-4 w-4 -translate-y-1/2 text-white/40" />
                <Input
                  id="username"
                  value={username}
                  onChange={(e) => setUsername(e.target.value)}
                  required
                  dir="ltr"
                  className="border-white/15 bg-white/5 pr-10 text-white placeholder:text-white/30 focus-visible:border-brand"
                />
              </div>
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="password" className="text-white/80">
                كلمة المرور
              </Label>
              <div className="relative">
                <Lock className="absolute right-3 top-1/2 h-4 w-4 -translate-y-1/2 text-white/40" />
                <Input
                  id="password"
                  type={showPw ? "text" : "password"}
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  required
                  dir="ltr"
                  className="border-white/15 bg-white/5 px-10 text-white placeholder:text-white/30 focus-visible:border-brand"
                />
                <button
                  type="button"
                  onClick={() => setShowPw((v) => !v)}
                  className="absolute left-3 top-1/2 -translate-y-1/2 text-white/40 hover:text-white"
                  aria-label="إظهار كلمة المرور"
                >
                  {showPw ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                </button>
              </div>
            </div>

            <Button
              type="submit"
              disabled={loading}
              className="w-full bg-brand text-white shadow-lg shadow-brand/30 hover:bg-brand-dark"
              size="lg"
            >
              {loading ? (
                <Loader2 className="h-5 w-5 animate-spin" />
              ) : (
                <>
                  <Lock className="ml-1.5 h-4 w-4" />
                  تسجيل الدخول
                </>
              )}
            </Button>
          </form>

          <div className="mt-6 rounded-xl border border-white/10 bg-white/5 p-3 text-center text-xs text-white/50">
            بيانات الدخول التجريبية: <span className="font-bold text-white/70" dir="ltr">admin / admin123</span>
          </div>
        </div>
      </div>
    </div>
  );
}
