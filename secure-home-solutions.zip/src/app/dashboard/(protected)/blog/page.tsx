"use client";

import { useEffect, useState, useCallback } from "react";
import { Newspaper, Plus, Trash2, Edit, X, Save, Loader2, Calendar } from "lucide-react";
import Image from "next/image";
import { DashboardPageHeader, EmptyState } from "@/components/dashboard/ui";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { useToast } from "@/hooks/use-toast";
import { cn } from "@/lib/utils";

type Post = {
  id: string;
  slug: string;
  title: string;
  excerpt: string;
  content: string;
  category: string;
  date: string;
  readTime: string;
  image: string;
  published: boolean;
};

const EMPTY = {
  slug: "",
  title: "",
  excerpt: "",
  content: "",
  category: "نصائح",
  date: new Date().toLocaleDateString("ar"),
  readTime: "5 دقائق",
  image: "",
  published: true,
};

const CATEGORIES = ["نصائح", "أخبار", "طاقة", "كاميرات", "تقنية"];

export default function BlogAdminPage() {
  const [items, setItems] = useState<Post[]>([]);
  const [loading, setLoading] = useState(true);
  const [editing, setEditing] = useState<Post | null>(null);
  const [showForm, setShowForm] = useState(false);
  const [form, setForm] = useState<typeof EMPTY>(EMPTY);
  const [saving, setSaving] = useState(false);
  const { toast } = useToast();

  const load = useCallback(() => {
    setLoading(true);
    fetch("/api/admin/blog")
      .then((r) => r.json())
      .then((d) => setItems(d.items || []))
      .finally(() => setLoading(false));
  }, []);

  useEffect(() => {
    load();
  }, [load]);

  function openNew() {
    setForm(EMPTY);
    setEditing(null);
    setShowForm(true);
  }
  function openEdit(p: Post) {
    setForm({
      slug: p.slug,
      title: p.title,
      excerpt: p.excerpt,
      content: p.content,
      category: p.category,
      date: p.date,
      readTime: p.readTime,
      image: p.image,
      published: p.published,
    });
    setEditing(p);
    setShowForm(true);
  }

  async function save() {
    setSaving(true);
    try {
      const res = await fetch("/api/admin/blog", {
        method: editing ? "PUT" : "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(editing ? { id: editing.id, ...form } : form),
      });
      const d = await res.json();
      if (d.ok) {
        toast({ title: editing ? "تم التحديث" : "تمت الإضافة" });
        setShowForm(false);
        load();
      } else throw new Error(d.error);
    } catch {
      toast({ variant: "destructive", title: "تعذّر الحفظ" });
    } finally {
      setSaving(false);
    }
  }

  async function remove(id: string) {
    if (!confirm("حذف هذا المقال؟")) return;
    await fetch(`/api/admin/blog?id=${id}`, { method: "DELETE" });
    toast({ title: "تم الحذف" });
    load();
  }

  async function togglePublish(p: Post) {
    await fetch("/api/admin/blog", {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ id: p.id, published: !p.published }),
    });
    load();
  }

  return (
    <div>
      <DashboardPageHeader
        title="إدارة المدونة"
        subtitle={`${items.length} مقال · ${items.filter((i) => i.published).length} منشور`}
        action={
          <Button onClick={openNew} className="bg-brand text-white hover:bg-brand-dark">
            <Plus className="ml-1.5 h-4 w-4" />
            مقال جديد
          </Button>
        }
      />

      {loading ? (
        <div className="flex h-40 items-center justify-center">
          <Loader2 className="h-8 w-8 animate-spin text-brand" />
        </div>
      ) : items.length === 0 ? (
        <EmptyState icon={Newspaper} title="لا توجد مقالات" />
      ) : (
        <div className="space-y-3">
          {items.map((p) => (
            <div
              key={p.id}
              className="flex gap-4 overflow-hidden rounded-2xl border border-border bg-white p-3 shadow-sm"
            >
              <div className="relative h-20 w-28 shrink-0 overflow-hidden rounded-xl bg-ink">
                {p.image ? (
                  <Image src={p.image} alt={p.title} fill sizes="120px" className="object-cover" />
                ) : (
                  <div className="grid h-full place-items-center text-white/30">
                    <Newspaper className="h-8 w-8" />
                  </div>
                )}
              </div>
              <div className="flex min-w-0 flex-1 flex-col">
                <div className="flex items-center gap-2">
                  <span className="rounded-full bg-brand/10 px-2 py-0.5 text-[10px] font-bold text-brand">
                    {p.category}
                  </span>
                  <button
                    onClick={() => togglePublish(p)}
                    className={cn(
                      "rounded-full px-2 py-0.5 text-[10px] font-medium",
                      p.published ? "bg-teal/15 text-teal" : "bg-muted text-muted-foreground"
                    )}
                  >
                    {p.published ? "منشور" : "مسودة"}
                  </button>
                </div>
                <h3 className="mt-1 truncate font-bold text-ink">{p.title}</h3>
                <p className="mt-0.5 line-clamp-1 text-xs text-muted-foreground">{p.excerpt}</p>
                <div className="mt-auto flex items-center gap-3 pt-1 text-[10px] text-muted-foreground">
                  <span className="flex items-center gap-1">
                    <Calendar className="h-3 w-3" />
                    {p.date}
                  </span>
                  <span>{p.readTime}</span>
                </div>
              </div>
              <div className="flex shrink-0 flex-col gap-1">
                <Button variant="ghost" size="icon" onClick={() => openEdit(p)}>
                  <Edit className="h-4 w-4" />
                </Button>
                <Button
                  variant="ghost"
                  size="icon"
                  onClick={() => remove(p.id)}
                  className="text-red-600 hover:bg-red-50"
                >
                  <Trash2 className="h-4 w-4" />
                </Button>
              </div>
            </div>
          ))}
        </div>
      )}

      {showForm && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-ink/60 p-4 backdrop-blur-sm">
          <div className="max-h-[90vh] w-full max-w-2xl overflow-y-auto rounded-3xl bg-white p-6 shadow-2xl">
            <div className="mb-4 flex items-center justify-between">
              <h2 className="text-xl font-bold text-ink">
                {editing ? "تعديل المقال" : "مقال جديد"}
              </h2>
              <button onClick={() => setShowForm(false)} className="grid h-9 w-9 place-items-center rounded-lg hover:bg-secondary">
                <X className="h-5 w-5" />
              </button>
            </div>
            <div className="grid gap-4 sm:grid-cols-2">
              <div className="space-y-1.5 sm:col-span-2">
                <Label>عنوان المقال *</Label>
                <Input value={form.title} onChange={(e) => setForm({ ...form, title: e.target.value })} />
              </div>
              <div className="space-y-1.5">
                <Label>المعرّف (slug)</Label>
                <Input value={form.slug} onChange={(e) => setForm({ ...form, slug: e.target.value })} dir="ltr" placeholder="b1" disabled={!!editing} />
              </div>
              <div className="space-y-1.5">
                <Label>الفئة</Label>
                <select
                  value={form.category}
                  onChange={(e) => setForm({ ...form, category: e.target.value })}
                  className="flex h-10 w-full rounded-md border border-input bg-background px-3 text-sm"
                >
                  {CATEGORIES.map((c) => (
                    <option key={c} value={c}>{c}</option>
                  ))}
                </select>
              </div>
              <div className="space-y-1.5 sm:col-span-2">
                <Label>الملخّص</Label>
                <Textarea value={form.excerpt} onChange={(e) => setForm({ ...form, excerpt: e.target.value })} rows={2} />
              </div>
              <div className="space-y-1.5 sm:col-span-2">
                <Label>المحتوى</Label>
                <Textarea value={form.content} onChange={(e) => setForm({ ...form, content: e.target.value })} rows={8} />
              </div>
              <div className="space-y-1.5">
                <Label>رابط الصورة</Label>
                <Input value={form.image} onChange={(e) => setForm({ ...form, image: e.target.value })} dir="ltr" />
              </div>
              <div className="space-y-1.5">
                <Label>مدة القراءة</Label>
                <Input value={form.readTime} onChange={(e) => setForm({ ...form, readTime: e.target.value })} placeholder="5 دقائق" />
              </div>
              <label className="flex items-center gap-2 sm:col-span-2">
                <input
                  type="checkbox"
                  checked={form.published}
                  onChange={(e) => setForm({ ...form, published: e.target.checked })}
                  className="h-4 w-4 rounded"
                />
                <span className="text-sm">منشور</span>
              </label>
            </div>
            <div className="mt-6 flex justify-end gap-2">
              <Button variant="outline" onClick={() => setShowForm(false)}>إلغاء</Button>
              <Button onClick={save} disabled={saving} className="bg-brand text-white hover:bg-brand-dark">
                {saving ? <Loader2 className="h-4 w-4 animate-spin" /> : <Save className="ml-1 h-4 w-4" />}
                حفظ
              </Button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
