"use client";

import { useEffect, useState, useCallback } from "react";
import { Users, Plus, Trash2, Edit, X, Save, Loader2 } from "lucide-react";
import { DashboardPageHeader, EmptyState } from "@/components/dashboard/ui";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { useToast } from "@/hooks/use-toast";
import { cn } from "@/lib/utils";

type Item = { id: string; name: string; role: string; desc: string; initials: string; color: string; order: number; };
const EMPTY = { name: "", role: "", desc: "", initials: "", color: "#f05100", order: 0 };
const COLORS = ["#f05100", "#009588", "#104e64", "#fcbb00", "#e40014", "#7c3aed"];

export default function TeamPage() {
  const [items, setItems] = useState<Item[]>([]);
  const [loading, setLoading] = useState(true);
  const [showForm, setShowForm] = useState(false);
  const [editing, setEditing] = useState<Item | null>(null);
  const [form, setForm] = useState<typeof EMPTY>(EMPTY);
  const [saving, setSaving] = useState(false);
  const { toast } = useToast();

  const load = useCallback(() => {
    setLoading(true);
    fetch("/api/admin/team").then(r => r.json()).then(d => setItems(d.items || [])).finally(() => setLoading(false));
  }, []);
  useEffect(() => { load(); }, [load]);

  function openNew() { setForm(EMPTY); setEditing(null); setShowForm(true); }
  function openEdit(i: Item) { setForm({ name: i.name, role: i.role, desc: i.desc, initials: i.initials, color: i.color, order: i.order }); setEditing(i); setShowForm(true); }
  async function save() {
    setSaving(true);
    try {
      const res = await fetch("/api/admin/team", { method: editing ? "PUT" : "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(editing ? { id: editing.id, ...form } : form) });
      const d = await res.json();
      if (d.ok) { toast({ title: editing ? "تم التحديث" : "تمت الإضافة" }); setShowForm(false); load(); } else throw new Error(d.error);
    } catch { toast({ variant: "destructive", title: "تعذّر الحفظ" }); } finally { setSaving(false); }
  }
  async function remove(id: string) { if (!confirm("حذف هذا العضو؟")) return; await fetch(`/api/admin/team?id=${id}`, { method: "DELETE" }); toast({ title: "تم الحذف" }); load(); }

  return (
    <div>
      <DashboardPageHeader title="إدارة الفريق" subtitle={`${items.length} عضو`}
        action={<Button onClick={openNew} className="bg-brand text-white hover:bg-brand-dark"><Plus className="ml-1.5 h-4 w-4" />عضو جديد</Button>} />
      {loading ? <div className="flex h-40 items-center justify-center"><Loader2 className="h-8 w-8 animate-spin text-brand" /></div>
      : items.length === 0 ? <EmptyState icon={Users} title="لا يوجد أعضاء" />
      : (
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {items.map((m) => (
            <div key={m.id} className="rounded-2xl border border-border bg-white p-5 text-center shadow-sm">
              <span className="mx-auto grid h-20 w-20 place-items-center rounded-full text-3xl font-extrabold text-white shadow-lg" style={{ background: `linear-gradient(135deg, ${m.color}, ${m.color}aa)` }}>{m.initials}</span>
              <h3 className="mt-4 font-bold text-ink">{m.name}</h3>
              <div className="text-sm font-medium" style={{ color: m.color }}>{m.role}</div>
              <p className="mt-2 line-clamp-2 text-xs text-muted-foreground">{m.desc}</p>
              <div className="mt-4 flex items-center justify-center gap-1 border-t border-border pt-3">
                <Button variant="ghost" size="sm" onClick={() => openEdit(m)}><Edit className="ml-1 h-4 w-4" />تعديل</Button>
                <Button variant="ghost" size="icon" onClick={() => remove(m.id)} className="text-red-600 hover:bg-red-50"><Trash2 className="h-4 w-4" /></Button>
              </div>
            </div>
          ))}
        </div>
      )}
      {showForm && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-ink/60 p-4 backdrop-blur-sm">
          <div className="max-h-[90vh] w-full max-w-lg overflow-y-auto rounded-3xl bg-white p-6 shadow-2xl">
            <div className="mb-4 flex items-center justify-between">
              <h2 className="text-xl font-bold text-ink">{editing ? "تعديل العضو" : "عضو جديد"}</h2>
              <button onClick={() => setShowForm(false)} className="grid h-9 w-9 place-items-center rounded-lg hover:bg-secondary"><X className="h-5 w-5" /></button>
            </div>
            <div className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-1.5"><Label>الاسم *</Label><Input value={form.name} onChange={e => setForm({ ...form, name: e.target.value })} /></div>
                <div className="space-y-1.5"><Label>المسمى الوظيفي</Label><Input value={form.role} onChange={e => setForm({ ...form, role: e.target.value })} placeholder="المدير التنفيذي" /></div>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-1.5"><Label>الأحرف الأولى</Label><Input value={form.initials} onChange={e => setForm({ ...form, initials: e.target.value })} placeholder="أ" /></div>
                <div className="space-y-1.5"><Label>الترتيب</Label><Input type="number" value={form.order} onChange={e => setForm({ ...form, order: Number(e.target.value) })} /></div>
              </div>
              <div className="space-y-1.5"><Label>الوصف</Label><Textarea value={form.desc} onChange={e => setForm({ ...form, desc: e.target.value })} rows={3} /></div>
              <div className="space-y-1.5"><Label>اللون</Label>
                <div className="flex gap-2">{COLORS.map(c => <button key={c} type="button" onClick={() => setForm({ ...form, color: c })} className={cn("h-9 w-9 rounded-lg ring-2 ring-offset-2", form.color === c ? "ring-ink" : "ring-transparent")} style={{ background: c }} />)}</div>
              </div>
            </div>
            <div className="mt-6 flex justify-end gap-2">
              <Button variant="outline" onClick={() => setShowForm(false)}>إلغاء</Button>
              <Button onClick={save} disabled={saving} className="bg-brand text-white hover:bg-brand-dark">{saving ? <Loader2 className="h-4 w-4 animate-spin" /> : <Save className="ml-1 h-4 w-4" />}حفظ</Button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
