import { redirect } from "next/navigation";
import { isAuthenticated } from "@/lib/auth";
import { DashboardShell } from "@/components/dashboard/sidebar";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

export default async function DashboardLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  const authed = await isAuthenticated();
  if (!authed) {
    redirect("/dashboard/login");
  }
  return <DashboardShell>{children}</DashboardShell>;
}
