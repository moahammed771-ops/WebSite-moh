"use client";

import { useEffect, useState, useCallback } from "react";
import { MessageCircleQuestion, Plus, Trash2, Edit, X, Save, Loader2, ChevronDown } from "lucide-react";
import { DashboardPageHeader, EmptyState } from "@/components/dashboard/ui";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { useToast } from "@/hooks/use-toast";
import { cn } from "@/lib/utils";

type Item = { id: string; question: string; answer: string; category: string; order: number; published: boolean; };
const EMPTY = { question: "", answer: "", category: "عام", order: 0, published: true };
const CATEGORIES = ["عام", "كاميرات", "صيانة", "ضمان", "تقنية", "أسعار", "طاقة"];

export default function FaqsPage() {
  const [items, setItems] = useState<Item[]>([]);
  const [loading, setLoading] = useState(true);
  const [showForm, setShowForm] = useState(false);
  const [editing, setEditing] = useState<Item | null>(null);
  const [form, setForm] = useState<typeof EMPTY>(EMPTY);
  const [saving, setSaving] = useState(false);
  const [openId, setOpenId] = useState<string | null>(null);
  const { toast } = useToast();

  const load = useCallback(() => {
    setLoading(true);
    fetch("/api/admin/faqs").then(r => r.json()).then(d => setItems(d.items || [])).finally(() => setLoading(false));
  }, []);
  useEffect(() => { load(); }, [load]);

  function openNew() { setForm(EMPTY); setEditing(null); setShowForm(true); }
  function openEdit(i: Item) { setForm({ question: i.question, answer: i.answer, category: i.category, order: i.order, published: i.published }); setEditing(i); setShowForm(true); }
  async function save() {
    setSaving(true);
    try {
      const res = await fetch("/api/admin/faqs", { method: editing ? "PUT" : "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(editing ? { id: editing.id, ...form } : form) });
      const d = await res.json();
      if (d.ok) { toast({ title: editing ? "تم التحديث" : "تمت الإضافة" }); setShowForm(false); load(); } else throw new Error(d.error);
    } catch { toast({ variant: "destructive", title: "تعذّر الحفظ" }); } finally { setSaving(false); }
  }
  async function remove(id: string) { if (!confirm("حذف هذا السؤال؟")) return; await fetch(`/api/admin/faqs?id=${id}`, { method: "DELETE" }); toast({ title: "تم الحذف" }); load(); }

  return (
    <div>
      <DashboardPageHeader title="إدارة الأسئلة الشائعة" subtitle={`${items.length} سؤال`}
        action={<Button onClick={openNew} className="bg-brand text-white hover:bg-brand-dark"><Plus className="ml-1.5 h-4 w-4" />سؤال جديد</Button>} />
      {loading ? <div className="flex h-40 items-center justify-center"><Loader2 className="h-8 w-8 animate-spin text-brand" /></div>
      : items.length === 0 ? <EmptyState icon={MessageCircleQuestion} title="لا توجد أسئلة" />
      : (
        <div className="space-y-3">
          {items.map((f) => (
            <div key={f.id} className={cn("overflow-hidden rounded-2xl border bg-white shadow-sm", openId === f.id ? "border-brand/40" : "border-border")}>
              <button onClick={() => setOpenId(openId === f.id ? null : f.id)} className="flex w-full items-center gap-3 p-4 text-right">
                <span className={cn("grid h-8 w-8 shrink-0 place-items-center rounded-lg text-sm font-bold", openId === f.id ? "bg-brand text-white" : "bg-brand/10 text-brand")}>؟</span>
                <span className="flex-1 text-sm font-bold text-ink">{f.question}</span>
                <span className="rounded-full bg-secondary px-2 py-0.5 text-[10px] text-muted-foreground">{f.category}</span>
                <span className={cn("rounded-full px-2 py-0.5 text-[10px]", f.published ? "bg-teal/15 text-teal" : "bg-muted text-muted-foreground")}>{f.published ? "منشور" : "مسودة"}</span>
                <ChevronDown className={cn("h-5 w-5 text-muted-foreground transition-transform", openId === f.id && "rotate-180")} />
              </button>
              {openId === f.id && (
                <div className="border-t border-border bg-secondary/30 p-4">
                  <p className="pr-11 text-sm leading-relaxed text-muted-foreground">{f.answer}</p>
                  <div className="mt-3 flex items-center gap-2 pr-11">
                    <Button variant="outline" size="sm" onClick={() => openEdit(f)}><Edit className="ml-1 h-4 w-4" />تعديل</Button>
                    <Button variant="outline" size="sm" onClick={() => remove(f.id)} className="text-red-600 hover:bg-red-50"><Trash2 className="ml-1 h-4 w-4" />حذف</Button>
                  </div>
                </div>
              )}
            </div>
          ))}
        </div>
      )}
      {showForm && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-ink/60 p-4 backdrop-blur-sm">
          <div className="max-h-[90vh] w-full max-w-lg overflow-y-auto rounded-3xl bg-white p-6 shadow-2xl">
            <div className="mb-4 flex items-center justify-between">
              <h2 className="text-xl font-bold text-ink">{editing ? "تعديل السؤال" : "سؤال جديد"}</h2>
              <button onClick={() => setShowForm(false)} className="grid h-9 w-9 place-items-center rounded-lg hover:bg-secondary"><X className="h-5 w-5" /></button>
            </div>
            <div className="space-y-4">
              <div className="space-y-1.5"><Label>السؤال *</Label><Input value={form.question} onChange={e => setForm({ ...form, question: e.target.value })} /></div>
              <div className="space-y-1.5"><Label>الإجابة *</Label><Textarea value={form.answer} onChange={e => setForm({ ...form, answer: e.target.value })} rows={5} /></div>
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-1.5"><Label>الفئة</Label>
                  <select value={form.category} onChange={e => setForm({ ...form, category: e.target.value })} className="flex h-10 w-full rounded-md border border-input bg-background px-3 text-sm">
                    {CATEGORIES.map(c => <option key={c} value={c}>{c}</option>)}
                  </select>
                </div>
                <div className="space-y-1.5"><Label>الترتيب</Label><Input type="number" value={form.order} onChange={e => setForm({ ...form, order: Number(e.target.value) })} /></div>
              </div>
              <label className="flex items-center gap-2"><input type="checkbox" checked={form.published} onChange={e => setForm({ ...form, published: e.target.checked })} className="h-4 w-4 rounded" /><span className="text-sm">منشور</span></label>
            </div>
            <div className="mt-6 flex justify-end gap-2">
              <Button variant="outline" onClick={() => setShowForm(false)}>إلغاء</Button>
              <Button onClick={save} disabled={saving} className="bg-brand text-white hover:bg-brand-dark">{saving ? <Loader2 className="h-4 w-4 animate-spin" /> : <Save className="ml-1 h-4 w-4" />}حفظ</Button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
