"use client";

import { useEffect, useState, useCallback } from "react";
import { Users, Trash2, Mail, RefreshCw, Download, Power } from "lucide-react";
import {
  DashboardPageHeader,
  EmptyState,
  formatDate,
} from "@/components/dashboard/ui";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";
import { cn } from "@/lib/utils";

type Item = {
  id: string;
  email: string;
  active: boolean;
  createdAt: string;
};

export default function SubscribersPage() {
  const [items, setItems] = useState<Item[]>([]);
  const [loading, setLoading] = useState(true);
  const { toast } = useToast();

  const load = useCallback(() => {
    setLoading(true);
    fetch("/api/admin/subscribers")
      .then((r) => r.json())
      .then((d) => setItems(d.items || []))
      .finally(() => setLoading(false));
  }, []);

  useEffect(() => {
    load();
  }, [load]);

  async function toggle(id: string, active: boolean) {
    await fetch("/api/admin/subscribers", {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ id, active: !active }),
    });
    load();
  }

  async function remove(id: string) {
    if (!confirm("حذف هذا المشترك نهائياً؟")) return;
    await fetch(`/api/admin/subscribers?id=${id}`, { method: "DELETE" });
    toast({ title: "تم الحذف" });
    load();
  }

  function exportCsv() {
    const rows = ["email,active,createdAt"];
    items.forEach((i) =>
      rows.push(`${i.email},${i.active},${i.createdAt}`)
    );
    const blob = new Blob([rows.join("\n")], { type: "text/csv" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = "subscribers.csv";
    a.click();
    URL.revokeObjectURL(url);
  }

  const activeCount = items.filter((i) => i.active).length;

  return (
    <div>
      <DashboardPageHeader
        title="مشتركي النشرة البريدية"
        subtitle={`${activeCount} نشط من أصل ${items.length}`}
        action={
          <div className="flex gap-2">
            <Button variant="outline" onClick={exportCsv} disabled={items.length === 0}>
              <Download className="ml-1.5 h-4 w-4" />
              تصدير CSV
            </Button>
            <Button variant="outline" onClick={load} disabled={loading}>
              <RefreshCw className={`ml-1.5 h-4 w-4 ${loading ? "animate-spin" : ""}`} />
              تحديث
            </Button>
          </div>
        }
      />

      {items.length === 0 ? (
        <EmptyState
          icon={Users}
          title="لا يوجد مشتركون"
          desc="سيظهر المشتركون في النشرة البريدية هنا."
        />
      ) : (
        <div className="overflow-hidden rounded-2xl border border-border bg-white shadow-sm">
          <table className="w-full">
            <thead className="border-b border-border bg-secondary/40">
              <tr className="text-right text-xs font-medium text-muted-foreground">
                <th className="p-4">البريد الإلكتروني</th>
                <th className="p-4">الحالة</th>
                <th className="p-4">تاريخ الاشتراك</th>
                <th className="p-4 text-left">إجراءات</th>
              </tr>
            </thead>
            <tbody>
              {items.map((item) => (
                <tr
                  key={item.id}
                  className="border-t border-border text-sm hover:bg-secondary/30"
                >
                  <td className="p-4">
                    <div className="flex items-center gap-2">
                      <span className="grid h-9 w-9 place-items-center rounded-full bg-teal/15 text-xs font-bold text-teal">
                        {item.email.slice(0, 2).toUpperCase()}
                      </span>
                      <a
                        href={`mailto:${item.email}`}
                        className="font-medium text-ink hover:text-brand"
                        dir="ltr"
                      >
                        {item.email}
                      </a>
                    </div>
                  </td>
                  <td className="p-4">
                    <span
                      className={cn(
                        "inline-flex items-center gap-1.5 rounded-full px-2.5 py-0.5 text-xs font-medium",
                        item.active
                          ? "bg-teal/15 text-teal"
                          : "bg-muted text-muted-foreground"
                      )}
                    >
                      <span
                        className={cn(
                          "h-1.5 w-1.5 rounded-full",
                          item.active ? "bg-teal" : "bg-muted-foreground"
                        )}
                      />
                      {item.active ? "نشط" : "متوقف"}
                    </span>
                  </td>
                  <td className="p-4 text-muted-foreground">
                    {formatDate(item.createdAt)}
                  </td>
                  <td className="p-4">
                    <div className="flex items-center justify-end gap-1">
                      <Button
                        variant="ghost"
                        size="icon"
                        onClick={() => toggle(item.id, item.active)}
                        title={item.active ? "إيقاف" : "تفعيل"}
                      >
                        <Power className="h-4 w-4 text-muted-foreground" />
                      </Button>
                      <a
                        href={`mailto:${item.email}`}
                        className="grid h-9 w-9 place-items-center rounded-lg hover:bg-secondary"
                      >
                        <Mail className="h-4 w-4 text-muted-foreground" />
                      </a>
                      <Button
                        variant="ghost"
                        size="icon"
                        onClick={() => remove(item.id)}
                        className="text-red-600 hover:bg-red-50"
                      >
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}
