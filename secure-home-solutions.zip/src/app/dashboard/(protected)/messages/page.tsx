"use client";

import { useEffect, useState, useCallback } from "react";
import { Mail, Trash2, Phone, RefreshCw, Search, ChevronDown, Reply } from "lucide-react";
import {
  DashboardPageHeader,
  Badge,
  EmptyState,
  formatDate,
} from "@/components/dashboard/ui";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useToast } from "@/hooks/use-toast";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";

type Item = {
  id: string;
  name: string;
  phone: string;
  email: string | null;
  subject: string | null;
  body: string;
  status: string;
  createdAt: string;
};

export default function MessagesPage() {
  const [items, setItems] = useState<Item[]>([]);
  const [loading, setLoading] = useState(true);
  const [filter, setFilter] = useState("all");
  const [query, setQuery] = useState("");
  const [expanded, setExpanded] = useState<string | null>(null);
  const { toast } = useToast();

  const load = useCallback(() => {
    setLoading(true);
    fetch("/api/admin/messages")
      .then((r) => r.json())
      .then((d) => setItems(d.items || []))
      .finally(() => setLoading(false));
  }, []);

  useEffect(() => {
    load();
  }, [load]);

  async function updateStatus(id: string, status: string) {
    await fetch("/api/admin/messages", {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ id, status }),
    });
    load();
  }

  async function remove(id: string) {
    if (!confirm("هل أنت متأكد من حذف هذه الرسالة؟")) return;
    await fetch(`/api/admin/messages?id=${id}`, { method: "DELETE" });
    toast({ title: "تم الحذف" });
    load();
  }

  const filtered = items.filter(
    (i) =>
      (!filter || filter === "all" || i.status === filter) &&
      (!query || i.name.includes(query) || (i.subject || "").includes(query))
  );

  return (
    <div>
      <DashboardPageHeader
        title="الرسائل"
        subtitle={`${items.filter((i) => i.status === "new").length} رسالة جديدة`}
        action={
          <Button variant="outline" onClick={load} disabled={loading}>
            <RefreshCw className={`ml-1.5 h-4 w-4 ${loading ? "animate-spin" : ""}`} />
            تحديث
          </Button>
        }
      />

      <div className="mb-4 flex flex-wrap items-center gap-3">
        <div className="relative flex-1 min-w-[220px]">
          <Search className="absolute right-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
          <Input
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="ابحث بالاسم أو الموضوع..."
            className="pr-10"
          />
        </div>
        <Select value={filter} onValueChange={setFilter}>
          <SelectTrigger className="w-[160px]">
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">الكل</SelectItem>
            <SelectItem value="new">جديد</SelectItem>
            <SelectItem value="read">مقروء</SelectItem>
          </SelectContent>
        </Select>
      </div>

      {filtered.length === 0 ? (
        <EmptyState icon={Mail} title="لا توجد رسائل" desc="ستظهر رسائل التواصل هنا." />
      ) : (
        <div className="space-y-3">
          {filtered.map((item) => (
            <div
              key={item.id}
              className={`overflow-hidden rounded-2xl border bg-white shadow-sm ${
                item.status === "new" ? "border-brand/40" : "border-border"
              }`}
            >
              <button
                onClick={() => {
                  setExpanded(expanded === item.id ? null : item.id);
                  if (item.status === "new") updateStatus(item.id, "read");
                }}
                className="flex w-full items-center gap-3 p-4 text-right"
              >
                <span className="grid h-11 w-11 shrink-0 place-items-center rounded-xl bg-teal/10 text-teal">
                  <Mail className="h-5 w-5" />
                </span>
                <div className="min-w-0 flex-1">
                  <div className="flex items-center gap-2">
                    <span className="truncate font-bold text-ink">{item.name}</span>
                    {item.status === "new" && (
                      <span className="h-2 w-2 rounded-full bg-brand" />
                    )}
                    <Badge status={item.status} />
                  </div>
                  <div className="mt-0.5 truncate text-sm text-muted-foreground">
                    {item.subject || "بدون موضوع"}
                  </div>
                  <div className="mt-0.5 text-xs text-muted-foreground">
                    {formatDate(item.createdAt)}
                  </div>
                </div>
                <ChevronDown
                  className={`h-5 w-5 shrink-0 text-muted-foreground transition-transform ${
                    expanded === item.id ? "rotate-180" : ""
                  }`}
                />
              </button>
              {expanded === item.id && (
                <div className="border-t border-border bg-secondary/30 p-4">
                  <div className="mb-3 flex flex-wrap gap-2">
                    {item.phone && (
                      <a
                        href={`tel:${item.phone}`}
                        className="flex items-center gap-2 rounded-lg border border-border bg-white p-2.5 text-sm"
                      >
                        <Phone className="h-4 w-4 text-brand" />
                        <span dir="ltr">{item.phone}</span>
                      </a>
                    )}
                    {item.email && (
                      <a
                        href={`mailto:${item.email}?subject=Re: ${encodeURIComponent(item.subject || "")}`}
                        className="flex items-center gap-2 rounded-lg border border-border bg-white p-2.5 text-sm"
                      >
                        <Reply className="h-4 w-4 text-teal" />
                        <span dir="ltr" className="truncate">رد بريدي</span>
                      </a>
                    )}
                  </div>
                  <div className="rounded-lg border border-border bg-white p-4 text-sm leading-relaxed text-foreground/85">
                    {item.body}
                  </div>
                  <div className="mt-3 flex items-center gap-2">
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => remove(item.id)}
                      className="text-red-600 hover:bg-red-50"
                    >
                      <Trash2 className="ml-1 h-4 w-4" />
                      حذف
                    </Button>
                  </div>
                </div>
              )}
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
