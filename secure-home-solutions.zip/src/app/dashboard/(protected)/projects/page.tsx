"use client";

import { useEffect, useState, useCallback } from "react";
import { FolderKanban, Plus, Trash2, Edit, X, Save, Loader2, MapPin } from "lucide-react";
import Image from "next/image";
import { DashboardPageHeader, EmptyState } from "@/components/dashboard/ui";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { useToast } from "@/hooks/use-toast";

type Project = {
  id: string;
  title: string;
  category: string;
  location: string;
  image: string;
  icon: string;
  desc: string;
  tags: string;
  featured: boolean;
};

const EMPTY = {
  title: "",
  category: "كاميرات مراقبة",
  location: "",
  image: "",
  icon: "Building2",
  desc: "",
  tags: "",
  featured: true,
};

const CATEGORIES = ["كاميرات مراقبة", "أنظمة إنتركم", "إنذار حريق", "طاقة شمسية", "حلول متكاملة"];

export default function ProjectsAdminPage() {
  const [items, setItems] = useState<Project[]>([]);
  const [loading, setLoading] = useState(true);
  const [editing, setEditing] = useState<Project | null>(null);
  const [showForm, setShowForm] = useState(false);
  const [form, setForm] = useState<typeof EMPTY>(EMPTY);
  const [saving, setSaving] = useState(false);
  const { toast } = useToast();

  const load = useCallback(() => {
    setLoading(true);
    fetch("/api/admin/projects")
      .then((r) => r.json())
      .then((d) => setItems(d.items || []))
      .finally(() => setLoading(false));
  }, []);

  useEffect(() => {
    load();
  }, [load]);

  function openNew() {
    setForm(EMPTY);
    setEditing(null);
    setShowForm(true);
  }
  function openEdit(p: Project) {
    setForm({
      title: p.title,
      category: p.category,
      location: p.location,
      image: p.image,
      icon: p.icon,
      desc: p.desc,
      tags: p.tags,
      featured: p.featured,
    });
    setEditing(p);
    setShowForm(true);
  }

  async function save() {
    setSaving(true);
    try {
      const payload = {
        ...form,
        tags: form.tags ? form.tags.split(",").map((s) => s.trim()).filter(Boolean) : [],
      };
      const res = await fetch("/api/admin/projects", {
        method: editing ? "PUT" : "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(editing ? { id: editing.id, ...payload } : payload),
      });
      const d = await res.json();
      if (d.ok) {
        toast({ title: editing ? "تم التحديث" : "تمت الإضافة" });
        setShowForm(false);
        load();
      } else throw new Error(d.error);
    } catch {
      toast({ variant: "destructive", title: "تعذّر الحفظ" });
    } finally {
      setSaving(false);
    }
  }

  async function remove(id: string) {
    if (!confirm("حذف هذا المشروع؟")) return;
    await fetch(`/api/admin/projects?id=${id}`, { method: "DELETE" });
    toast({ title: "تم الحذف" });
    load();
  }

  return (
    <div>
      <DashboardPageHeader
        title="إدارة المشاريع"
        subtitle={`${items.length} مشروع`}
        action={
          <Button onClick={openNew} className="bg-brand text-white hover:bg-brand-dark">
            <Plus className="ml-1.5 h-4 w-4" />
            مشروع جديد
          </Button>
        }
      />

      {loading ? (
        <div className="flex h-40 items-center justify-center">
          <Loader2 className="h-8 w-8 animate-spin text-brand" />
        </div>
      ) : items.length === 0 ? (
        <EmptyState icon={FolderKanban} title="لا توجد مشاريع" />
      ) : (
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {items.map((p) => (
            <div
              key={p.id}
              className="group overflow-hidden rounded-2xl border border-border bg-white shadow-sm transition-all hover:shadow-md"
            >
              <div className="relative h-40 overflow-hidden bg-ink">
                {p.image ? (
                  <Image src={p.image} alt={p.title} fill sizes="300px" className="object-cover" />
                ) : (
                  <div className="grid h-full place-items-center text-white/30">
                    <FolderKanban className="h-10 w-10" />
                  </div>
                )}
                <span className="absolute top-2 right-2 rounded-full bg-brand px-2.5 py-0.5 text-[10px] font-bold text-white">
                  {p.category}
                </span>
                {p.featured && (
                  <span className="absolute top-2 left-2 rounded-full bg-teal px-2 py-0.5 text-[10px] font-bold text-white">
                    مميّز
                  </span>
                )}
              </div>
              <div className="p-4">
                <h3 className="font-bold text-ink">{p.title}</h3>
                <div className="mt-1 flex items-center gap-1 text-xs text-muted-foreground">
                  <MapPin className="h-3 w-3" />
                  {p.location || "غير محدد"}
                </div>
                <p className="mt-2 line-clamp-2 text-xs text-muted-foreground">{p.desc}</p>
                <div className="mt-3 flex items-center gap-1 border-t border-border pt-3">
                  <Button variant="ghost" size="sm" onClick={() => openEdit(p)}>
                    <Edit className="ml-1 h-4 w-4" />
                    تعديل
                  </Button>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => remove(p.id)}
                    className="mr-auto text-red-600 hover:bg-red-50"
                  >
                    <Trash2 className="h-4 w-4" />
                  </Button>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}

      {showForm && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-ink/60 p-4 backdrop-blur-sm">
          <div className="max-h-[90vh] w-full max-w-2xl overflow-y-auto rounded-3xl bg-white p-6 shadow-2xl">
            <div className="mb-4 flex items-center justify-between">
              <h2 className="text-xl font-bold text-ink">
                {editing ? "تعديل المشروع" : "مشروع جديد"}
              </h2>
              <button onClick={() => setShowForm(false)} className="grid h-9 w-9 place-items-center rounded-lg hover:bg-secondary">
                <X className="h-5 w-5" />
              </button>
            </div>
            <div className="grid gap-4 sm:grid-cols-2">
              <div className="space-y-1.5 sm:col-span-2">
                <Label>عنوان المشروع *</Label>
                <Input value={form.title} onChange={(e) => setForm({ ...form, title: e.target.value })} />
              </div>
              <div className="space-y-1.5">
                <Label>الفئة</Label>
                <select
                  value={form.category}
                  onChange={(e) => setForm({ ...form, category: e.target.value })}
                  className="flex h-10 w-full rounded-md border border-input bg-background px-3 text-sm"
                >
                  {CATEGORIES.map((c) => (
                    <option key={c} value={c}>{c}</option>
                  ))}
                </select>
              </div>
              <div className="space-y-1.5">
                <Label>الموقع</Label>
                <Input value={form.location} onChange={(e) => setForm({ ...form, location: e.target.value })} placeholder="صنعاء - حدة" />
              </div>
              <div className="space-y-1.5 sm:col-span-2">
                <Label>رابط الصورة</Label>
                <Input value={form.image} onChange={(e) => setForm({ ...form, image: e.target.value })} dir="ltr" placeholder="/images/project-1.png" />
              </div>
              <div className="space-y-1.5 sm:col-span-2">
                <Label>الوصف</Label>
                <Textarea value={form.desc} onChange={(e) => setForm({ ...form, desc: e.target.value })} rows={3} />
              </div>
              <div className="space-y-1.5 sm:col-span-2">
                <Label>الوسوم (مفصولة بفاصلة)</Label>
                <Input value={form.tags} onChange={(e) => setForm({ ...form, tags: e.target.value })} placeholder="كاميرات 4K, تخزين سحابي" />
              </div>
              <label className="flex items-center gap-2 sm:col-span-2">
                <input
                  type="checkbox"
                  checked={form.featured}
                  onChange={(e) => setForm({ ...form, featured: e.target.checked })}
                  className="h-4 w-4 rounded"
                />
                <span className="text-sm">مشروع مميّز</span>
              </label>
            </div>
            <div className="mt-6 flex justify-end gap-2">
              <Button variant="outline" onClick={() => setShowForm(false)}>إلغاء</Button>
              <Button onClick={save} disabled={saving} className="bg-brand text-white hover:bg-brand-dark">
                {saving ? <Loader2 className="h-4 w-4 animate-spin" /> : <Save className="ml-1 h-4 w-4" />}
                حفظ
              </Button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
