"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import {
  FileText, Mail, Users, Wrench, FolderKanban, Newspaper, Star,
  MessageCircleQuestion, MessagesSquare, TrendingUp, Clock, ArrowLeft,
  Activity, ShieldCheck, BarChart3, PieChart, Sparkles,
} from "lucide-react";
import {
  DashboardPageHeader, StatCard, Badge, formatDate,
} from "@/components/dashboard/ui";
import { cn } from "@/lib/utils";

type Stats = {
  quotes: number; newQuotes: number; subscribers: number; messages: number;
  projects: number; blogPosts: number; services: number;
  testimonials: number; team: number; faqs: number; chats: number; chatSessions: number;
};
type Activity = {
  quotes: any[]; messages: any[]; subs: any[]; chats: any[];
};
type Charts = {
  byService: { service: string; count: number }[];
  trend: { date: string; label: string; count: number }[];
  byStatus: { status: string; count: number }[];
};

const SERVICE_COLORS: Record<string, string> = {
  "كاميرات المراقبة": "#f05100",
  "أنظمة الإنتركم": "#009588",
  "إنذار الحريق": "#e40014",
  "الطاقة الشمسية": "#fcbb00",
  "استشارة عامة": "#7c3aed",
  "صيانة ودعم": "#104e64",
  "رسالة تواصل": "#6b7280",
};
const STATUS_LABELS: Record<string, string> = {
  new: "جديد", contacted: "تم التواصل", won: "تم الإغلاق", lost: "ملغي",
};
const STATUS_COLORS: Record<string, string> = {
  new: "#3b82f6", contacted: "#f59e0b", won: "#10b981", lost: "#ef4444",
};

export default function DashboardHome() {
  const [stats, setStats] = useState<Stats | null>(null);
  const [activity, setActivity] = useState<Activity | null>(null);
  const [charts, setCharts] = useState<Charts | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetch("/api/admin/stats")
      .then((r) => r.json())
      .then((d) => {
        if (d.ok) {
          setStats(d.stats);
          setActivity(d.activity);
          setCharts(d.charts);
        }
      })
      .finally(() => setLoading(false));
  }, []);

  const maxTrend = charts ? Math.max(...charts.trend.map((t) => t.count), 1) : 1;
  const totalQuotes = charts?.byStatus.reduce((a, b) => a + b.count, 0) || 1;

  return (
    <div>
      <DashboardPageHeader
        title="نظرة عامة"
        subtitle="ملخّص أداء الموقع وآخر النشاطات"
      />

      {/* Main stats grid */}
      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        <StatCard icon={FileText} label="طلبات عروض الأسعار" value={stats?.quotes ?? "—"} sub={`${stats?.newQuotes ?? 0} طلب جديد`} color="#f05100" trend="نشط" />
        <StatCard icon={Mail} label="رسائل جديدة" value={stats?.messages ?? "—"} sub="بانتظار الرد" color="#009588" />
        <StatCard icon={Users} label="المشترون بالنشرة" value={stats?.subscribers ?? "—"} sub="مشترك نشط" color="#104e64" />
        <StatCard icon={MessagesSquare} label="محادثات المساعد" value={stats?.chatSessions ?? "—"} sub={`${stats?.chats ?? 0} رسالة`} color="#7c3aed" />
      </div>

      {/* Secondary stats */}
      <div className="mt-4 grid gap-4 sm:grid-cols-2 lg:grid-cols-4 xl:grid-cols-6">
        <StatCard icon={Wrench} label="الخدمات" value={stats?.services ?? "—"} color="#f05100" />
        <StatCard icon={FolderKanban} label="المشاريع" value={stats?.projects ?? "—"} color="#009588" />
        <StatCard icon={Newspaper} label="مقالات المدونة" value={stats?.blogPosts ?? "—"} color="#fcbb00" />
        <StatCard icon={Star} label="آراء العملاء" value={stats?.testimonials ?? "—"} color="#e40014" />
        <StatCard icon={Users} label="أعضاء الفريق" value={stats?.team ?? "—"} color="#7c3aed" />
        <StatCard icon={MessageCircleQuestion} label="الأسئلة الشائعة" value={stats?.faqs ?? "—"} color="#104e64" />
      </div>

      {/* Charts row */}
      <div className="mt-6 grid gap-6 lg:grid-cols-3">
        {/* Trend chart */}
        <div className="rounded-2xl border border-border bg-white p-5 shadow-sm lg:col-span-2">
          <div className="mb-5 flex items-center justify-between">
            <h2 className="flex items-center gap-2 font-bold text-ink">
              <BarChart3 className="h-4 w-4 text-brand" />
              اتجاه الطلبات (آخر 7 أيام)
            </h2>
            <span className="text-xs text-muted-foreground">إجمالي: {charts?.trend.reduce((a, b) => a + b.count, 0) || 0} طلب</span>
          </div>
          {loading ? (
            <div className="flex h-48 items-center justify-center">
              <div className="h-8 w-8 animate-spin rounded-full border-2 border-brand border-t-transparent" />
            </div>
          ) : (
            <div className="flex h-48 items-end justify-between gap-2">
              {charts?.trend.map((t, i) => (
                <div key={i} className="group flex flex-1 flex-col items-center gap-2">
                  <div className="relative flex w-full flex-1 items-end">
                    <div
                      className="w-full rounded-t-lg bg-gradient-to-t from-brand to-brand-dark transition-all duration-500 group-hover:opacity-80"
                      style={{
                        height: `${(t.count / maxTrend) * 100}%`,
                        minHeight: t.count > 0 ? "8px" : "2px",
                        opacity: t.count > 0 ? 1 : 0.15,
                      }}
                      title={`${t.count} طلب`}
                    />
                    <span className="absolute -top-6 left-1/2 -translate-x-1/2 rounded bg-ink px-1.5 py-0.5 text-[10px] font-bold text-white opacity-0 transition-opacity group-hover:opacity-100">
                      {t.count}
                    </span>
                  </div>
                  <span className="text-[10px] text-muted-foreground">{t.label}</span>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Status donut */}
        <div className="rounded-2xl border border-border bg-white p-5 shadow-sm">
          <div className="mb-5 flex items-center justify-between">
            <h2 className="flex items-center gap-2 font-bold text-ink">
              <PieChart className="h-4 w-4 text-teal" />
              حالات الطلبات
            </h2>
          </div>
          {loading ? (
            <div className="flex h-48 items-center justify-center">
              <div className="h-8 w-8 animate-spin rounded-full border-2 border-teal border-t-transparent" />
            </div>
          ) : (
            <div className="space-y-3">
              {charts?.byStatus.map((s) => {
                const pct = Math.round((s.count / totalQuotes) * 100);
                return (
                  <div key={s.status}>
                    <div className="mb-1 flex items-center justify-between text-xs">
                      <span className="font-medium text-ink">{STATUS_LABELS[s.status] || s.status}</span>
                      <span className="text-muted-foreground">{s.count} ({pct}%)</span>
                    </div>
                    <div className="h-2 overflow-hidden rounded-full bg-secondary">
                      <div
                        className="h-full rounded-full transition-all duration-700"
                        style={{ width: `${pct}%`, backgroundColor: STATUS_COLORS[s.status] }}
                      />
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      </div>

      {/* Top services */}
      <div className="mt-6 rounded-2xl border border-border bg-white p-5 shadow-sm">
        <h2 className="mb-4 flex items-center gap-2 font-bold text-ink">
          <Sparkles className="h-4 w-4 text-gold" />
          الخدمات الأكثر طلباً
        </h2>
        {loading ? (
          <div className="flex h-32 items-center justify-center">
            <div className="h-8 w-8 animate-spin rounded-full border-2 border-brand border-t-transparent" />
          </div>
        ) : charts?.byService.length ? (
          <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
            {charts.byService.slice(0, 6).map((s) => (
              <div key={s.service} className="flex items-center gap-3 rounded-xl border border-border p-3">
                <span className="grid h-10 w-10 shrink-0 place-items-center rounded-lg text-white" style={{ backgroundColor: SERVICE_COLORS[s.service] || "#6b7280" }}>
                  <FileText className="h-5 w-5" />
                </span>
                <div className="min-w-0 flex-1">
                  <div className="truncate text-sm font-bold text-ink">{s.service}</div>
                  <div className="text-xs text-muted-foreground">{s.count} طلب</div>
                </div>
              </div>
            ))}
          </div>
        ) : (
          <div className="py-8 text-center text-sm text-muted-foreground">لا توجد طلبات بعد</div>
        )}
      </div>

      {/* Recent activity - 4 columns */}
      <div className="mt-6 grid gap-4 lg:grid-cols-4">
        {/* Recent quotes */}
        <ActivityCard title="آخر طلبات الأسعار" icon={FileText} color="#f05100" href="/dashboard/quotes"
          loading={loading} items={activity?.quotes?.map((q) => ({
            id: q.id, title: q.name, sub: q.service, status: q.status, date: q.createdAt,
          })) || []} />

        {/* Recent messages */}
        <ActivityCard title="آخر الرسائل" icon={Mail} color="#009588" href="/dashboard/messages"
          loading={loading} items={activity?.messages?.map((m) => ({
            id: m.id, title: m.name, sub: m.subject || "بدون موضوع", status: m.status, date: m.createdAt,
          })) || []} />

        {/* Recent subscribers */}
        <ActivityCard title="آخر المشتركين" icon={Users} color="#fcbb00" href="/dashboard/subscribers"
          loading={loading} items={activity?.subs?.map((s) => ({
            id: s.id, title: s.email, sub: "", date: s.createdAt,
          })) || []} dir="ltr" />

        {/* Recent chats */}
        <ActivityCard title="آخر محادثات المساعد" icon={MessagesSquare} color="#7c3aed" href="/dashboard/chats"
          loading={loading} items={activity?.chats?.filter((c) => c.role === "user").map((c) => ({
            id: c.id, title: c.content.slice(0, 40) + (c.content.length > 40 ? "..." : ""), sub: c.sessionId.slice(0, 12), date: c.createdAt,
          })) || []} />
      </div>

      {/* Quick links */}
      <div className="mt-8">
        <h2 className="mb-4 text-lg font-bold text-ink">روابط سريعة</h2>
        <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
          {[
            { href: "/dashboard/services", label: "إدارة الخدمات", icon: Wrench, color: "#f05100" },
            { href: "/dashboard/projects", label: "إدارة المشاريع", icon: FolderKanban, color: "#009588" },
            { href: "/dashboard/blog", label: "إدارة المدونة", icon: Newspaper, color: "#7c3aed" },
            { href: "/dashboard/settings", label: "إعدادات الموقع", icon: TrendingUp, color: "#fcbb00" },
          ].map((q) => (
            <Link key={q.href} href={q.href} className="group flex items-center gap-3 rounded-2xl border border-border bg-white p-4 shadow-sm transition-all hover:-translate-y-0.5 hover:shadow-md">
              <span className="grid h-11 w-11 place-items-center rounded-xl text-white shadow-lg" style={{ backgroundColor: q.color }}>
                <q.icon className="h-5 w-5" />
              </span>
              <span className="flex-1 text-sm font-bold text-ink">{q.label}</span>
              <ArrowLeft className="h-4 w-4 text-muted-foreground transition-transform group-hover:-translate-x-1" />
            </Link>
          ))}
        </div>
      </div>
    </div>
  );
}

function ActivityCard({
  title, icon: Icon, color, href, loading, items, dir,
}: {
  title: string; icon: any; color: string; href: string; loading: boolean;
  items: { id: string; title: string; sub?: string; status?: string; date: string }[];
  dir?: "rtl" | "ltr";
}) {
  return (
    <div className="rounded-2xl border border-border bg-white p-5 shadow-sm">
      <div className="mb-4 flex items-center justify-between">
        <h2 className="flex items-center gap-2 font-bold text-ink">
          <Icon className="h-4 w-4" style={{ color }} />
          {title}
        </h2>
        <Link href={href} className="text-xs font-medium text-brand hover:underline">عرض الكل</Link>
      </div>
      {loading ? (
        <div className="space-y-2">
          {[...Array(3)].map((_, i) => <div key={i} className="h-12 animate-pulse rounded-xl bg-secondary" />)}
        </div>
      ) : items.length ? (
        <div className="space-y-2">
          {items.slice(0, 4).map((it) => (
            <Link key={it.id} href={href} className="block rounded-xl border border-border p-2.5 transition-colors hover:bg-secondary/40">
              <div className="flex items-center justify-between gap-2">
                <span className="truncate text-xs font-bold text-ink" dir={dir}>{it.title}</span>
                {it.status && <Badge status={it.status} />}
              </div>
              {it.sub && <div className="mt-0.5 truncate text-[10px] text-muted-foreground">{it.sub}</div>}
              <div className="mt-0.5 flex items-center gap-1 text-[9px] text-muted-foreground">
                <Clock className="h-2.5 w-2.5" />
                {formatDate(it.date)}
              </div>
            </Link>
          ))}
        </div>
      ) : (
        <div className="py-6 text-center text-xs text-muted-foreground">لا يوجد نشاط بعد</div>
      )}
    </div>
  );
}
