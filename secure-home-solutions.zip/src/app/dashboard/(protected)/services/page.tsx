"use client";

import { useEffect, useState, useCallback } from "react";
import { Wrench, Plus, Trash2, Edit, X, Save, Loader2, GripVertical } from "lucide-react";
import { DashboardPageHeader, EmptyState } from "@/components/dashboard/ui";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { useToast } from "@/hooks/use-toast";
import { cn } from "@/lib/utils";

type Service = {
  id: string;
  slug: string;
  num: string;
  title: string;
  shortDesc: string;
  longDesc: string;
  features: string;
  image: string;
  accent: string;
  icon: string;
  startPrice: string | null;
  warranty: string | null;
  featured: boolean;
  order: number;
};

const EMPTY = {
  slug: "",
  num: "",
  title: "",
  shortDesc: "",
  longDesc: "",
  features: "",
  image: "",
  accent: "#f05100",
  icon: "Cctv",
  startPrice: "",
  warranty: "",
  featured: true,
  order: 0,
};

export default function ServicesAdminPage() {
  const [items, setItems] = useState<Service[]>([]);
  const [loading, setLoading] = useState(true);
  const [editing, setEditing] = useState<Service | null>(null);
  const [showForm, setShowForm] = useState(false);
  const [form, setForm] = useState<typeof EMPTY>(EMPTY);
  const [saving, setSaving] = useState(false);
  const { toast } = useToast();

  const load = useCallback(() => {
    setLoading(true);
    fetch("/api/admin/services")
      .then((r) => r.json())
      .then((d) => setItems(d.items || []))
      .finally(() => setLoading(false));
  }, []);

  useEffect(() => {
    load();
  }, [load]);

  function openNew() {
    setForm(EMPTY);
    setEditing(null);
    setShowForm(true);
  }
  function openEdit(s: Service) {
    setForm({
      slug: s.slug,
      num: s.num,
      title: s.title,
      shortDesc: s.shortDesc,
      longDesc: s.longDesc,
      features: s.features,
      image: s.image,
      accent: s.accent,
      icon: s.icon,
      startPrice: s.startPrice || "",
      warranty: s.warranty || "",
      featured: s.featured,
      order: s.order,
    });
    setEditing(s);
    setShowForm(true);
  }

  async function save() {
    setSaving(true);
    try {
      const payload = {
        ...form,
        features: form.features
          ? form.features.split("\n").map((s) => s.trim()).filter(Boolean)
          : [],
        order: Number(form.order) || 0,
      };
      const res = await fetch("/api/admin/services", {
        method: editing ? "PUT" : "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(editing ? { id: editing.id, ...payload } : payload),
      });
      const d = await res.json();
      if (d.ok) {
        toast({ title: editing ? "تم التحديث" : "تمت الإضافة" });
        setShowForm(false);
        load();
      } else throw new Error(d.error);
    } catch {
      toast({ variant: "destructive", title: "تعذّر الحفظ" });
    } finally {
      setSaving(false);
    }
  }

  async function remove(id: string) {
    if (!confirm("حذف هذه الخدمة؟")) return;
    await fetch(`/api/admin/services?id=${id}`, { method: "DELETE" });
    toast({ title: "تم الحذف" });
    load();
  }

  return (
    <div>
      <DashboardPageHeader
        title="إدارة الخدمات"
        subtitle={`${items.length} خدمة منشورة`}
        action={
          <Button onClick={openNew} className="bg-brand text-white hover:bg-brand-dark">
            <Plus className="ml-1.5 h-4 w-4" />
            خدمة جديدة
          </Button>
        }
      />

      {loading ? (
        <div className="flex h-40 items-center justify-center">
          <Loader2 className="h-8 w-8 animate-spin text-brand" />
        </div>
      ) : items.length === 0 ? (
        <EmptyState icon={Wrench} title="لا توجد خدمات" desc="أضف خدماتك هنا." />
      ) : (
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {items.map((s) => (
            <div
              key={s.id}
              className="group relative overflow-hidden rounded-2xl border border-border bg-white p-5 shadow-sm transition-all hover:shadow-md"
            >
              <div
                className="absolute -right-8 -top-8 h-20 w-20 rounded-full opacity-10 blur-2xl"
                style={{ background: s.accent }}
              />
              <div className="relative flex items-start justify-between">
                <span
                  className="grid h-12 w-12 place-items-center rounded-xl text-white shadow-lg"
                  style={{ backgroundColor: s.accent }}
                >
                  <Wrench className="h-6 w-6" />
                </span>
                <span className="text-2xl font-black text-muted-foreground/20">
                  {s.num}
                </span>
              </div>
              <h3 className="relative mt-3 font-bold text-ink">{s.title}</h3>
              <p className="relative mt-1 line-clamp-2 text-xs text-muted-foreground">
                {s.shortDesc}
              </p>
              <div className="relative mt-3 flex items-center gap-3 text-xs">
                {s.startPrice && (
                  <span className="font-bold text-brand">{s.startPrice}</span>
                )}
                {s.warranty && (
                  <span className="text-muted-foreground">ضمان {s.warranty}</span>
                )}
              </div>
              <div className="relative mt-4 flex items-center gap-1 border-t border-border pt-3">
                <Button variant="ghost" size="sm" onClick={() => openEdit(s)}>
                  <Edit className="ml-1 h-4 w-4" />
                  تعديل
                </Button>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => remove(s.id)}
                  className="mr-auto text-red-600 hover:bg-red-50"
                >
                  <Trash2 className="h-4 w-4" />
                </Button>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Form modal */}
      {showForm && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-ink/60 p-4 backdrop-blur-sm">
          <div className="max-h-[90vh] w-full max-w-2xl overflow-y-auto rounded-3xl bg-white p-6 shadow-2xl">
            <div className="mb-4 flex items-center justify-between">
              <h2 className="text-xl font-bold text-ink">
                {editing ? "تعديل الخدمة" : "خدمة جديدة"}
              </h2>
              <button
                onClick={() => setShowForm(false)}
                className="grid h-9 w-9 place-items-center rounded-lg hover:bg-secondary"
              >
                <X className="h-5 w-5" />
              </button>
            </div>
            <div className="grid gap-4 sm:grid-cols-2">
              <div className="space-y-1.5">
                <Label>المعرّف (slug) *</Label>
                <Input
                  value={form.slug}
                  onChange={(e) => setForm({ ...form, slug: e.target.value })}
                  dir="ltr"
                  placeholder="cctv"
                  disabled={!!editing}
                />
              </div>
              <div className="space-y-1.5">
                <Label>الرقم</Label>
                <Input
                  value={form.num}
                  onChange={(e) => setForm({ ...form, num: e.target.value })}
                  placeholder="01"
                />
              </div>
              <div className="space-y-1.5 sm:col-span-2">
                <Label>عنوان الخدمة *</Label>
                <Input
                  value={form.title}
                  onChange={(e) => setForm({ ...form, title: e.target.value })}
                />
              </div>
              <div className="space-y-1.5 sm:col-span-2">
                <Label>وصف مختصر</Label>
                <Textarea
                  value={form.shortDesc}
                  onChange={(e) => setForm({ ...form, shortDesc: e.target.value })}
                  rows={2}
                />
              </div>
              <div className="space-y-1.5 sm:col-span-2">
                <Label>الوصف التفصيلي</Label>
                <Textarea
                  value={form.longDesc}
                  onChange={(e) => setForm({ ...form, longDesc: e.target.value })}
                  rows={4}
                />
              </div>
              <div className="space-y-1.5 sm:col-span-2">
                <Label>المميزات (كل ميزة في سطر)</Label>
                <Textarea
                  value={form.features}
                  onChange={(e) => setForm({ ...form, features: e.target.value })}
                  rows={4}
                  placeholder={"كاميرات 4K\nرؤية ليلية\nتنبيهات ذكية"}
                />
              </div>
              <div className="space-y-1.5">
                <Label>رابط الصورة</Label>
                <Input
                  value={form.image}
                  onChange={(e) => setForm({ ...form, image: e.target.value })}
                  dir="ltr"
                />
              </div>
              <div className="space-y-1.5">
                <Label>اللون المميّز</Label>
                <div className="flex gap-2">
                  <Input
                    type="color"
                    value={form.accent}
                    onChange={(e) => setForm({ ...form, accent: e.target.value })}
                    className="h-10 w-16 p-1"
                  />
                  <Input
                    value={form.accent}
                    onChange={(e) => setForm({ ...form, accent: e.target.value })}
                    dir="ltr"
                  />
                </div>
              </div>
              <div className="space-y-1.5">
                <Label>سعر البداية</Label>
                <Input
                  value={form.startPrice}
                  onChange={(e) => setForm({ ...form, startPrice: e.target.value })}
                  dir="ltr"
                  placeholder="120$"
                />
              </div>
              <div className="space-y-1.5">
                <Label>الضمان</Label>
                <Input
                  value={form.warranty}
                  onChange={(e) => setForm({ ...form, warranty: e.target.value })}
                  placeholder="سنتان"
                />
              </div>
            </div>
            <div className="mt-6 flex justify-end gap-2">
              <Button variant="outline" onClick={() => setShowForm(false)}>
                إلغاء
              </Button>
              <Button onClick={save} disabled={saving} className="bg-brand text-white hover:bg-brand-dark">
                {saving ? <Loader2 className="h-4 w-4 animate-spin" /> : <Save className="ml-1 h-4 w-4" />}
                حفظ
              </Button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
