"use client";

import { useEffect, useState, useCallback } from "react";
import { Star, Plus, Trash2, Edit, X, Save, Loader2, Quote } from "lucide-react";
import { DashboardPageHeader, EmptyState } from "@/components/dashboard/ui";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { useToast } from "@/hooks/use-toast";
import { cn } from "@/lib/utils";

type Item = {
  id: string; name: string; role: string; rating: number;
  text: string; initials: string; color: string; published: boolean; order: number;
};

const EMPTY = { name: "", role: "", rating: 5, text: "", initials: "", color: "#f05100", published: true, order: 0 };
const COLORS = ["#f05100", "#009588", "#104e64", "#fcbb00", "#e40014", "#7c3aed"];

export default function TestimonialsPage() {
  const [items, setItems] = useState<Item[]>([]);
  const [loading, setLoading] = useState(true);
  const [showForm, setShowForm] = useState(false);
  const [editing, setEditing] = useState<Item | null>(null);
  const [form, setForm] = useState<typeof EMPTY>(EMPTY);
  const [saving, setSaving] = useState(false);
  const { toast } = useToast();

  const load = useCallback(() => {
    setLoading(true);
    fetch("/api/admin/testimonials").then(r => r.json()).then(d => setItems(d.items || [])).finally(() => setLoading(false));
  }, []);
  useEffect(() => { load(); }, [load]);

  function openNew() { setForm(EMPTY); setEditing(null); setShowForm(true); }
  function openEdit(i: Item) {
    setForm({ name: i.name, role: i.role, rating: i.rating, text: i.text, initials: i.initials, color: i.color, published: i.published, order: i.order });
    setEditing(i); setShowForm(true);
  }
  async function save() {
    setSaving(true);
    try {
      const res = await fetch("/api/admin/testimonials", {
        method: editing ? "PUT" : "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(editing ? { id: editing.id, ...form } : form),
      });
      const d = await res.json();
      if (d.ok) { toast({ title: editing ? "تم التحديث" : "تمت الإضافة" }); setShowForm(false); load(); }
      else throw new Error(d.error);
    } catch { toast({ variant: "destructive", title: "تعذّر الحفظ" }); }
    finally { setSaving(false); }
  }
  async function remove(id: string) {
    if (!confirm("حذف هذا التقييم؟")) return;
    await fetch(`/api/admin/testimonials?id=${id}`, { method: "DELETE" });
    toast({ title: "تم الحذف" }); load();
  }

  return (
    <div>
      <DashboardPageHeader title="آراء العملاء" subtitle={`${items.length} تقييم`}
        action={<Button onClick={openNew} className="bg-brand text-white hover:bg-brand-dark"><Plus className="ml-1.5 h-4 w-4" />تقييم جديد</Button>} />
      {loading ? <div className="flex h-40 items-center justify-center"><Loader2 className="h-8 w-8 animate-spin text-brand" /></div>
      : items.length === 0 ? <EmptyState icon={Star} title="لا توجد تقييمات" />
      : (
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {items.map((t) => (
            <div key={t.id} className="relative overflow-hidden rounded-2xl border border-border bg-white p-5 shadow-sm">
              <Quote className="absolute -top-2 left-4 h-10 w-10 rotate-180 text-brand/10" />
              <div className="relative flex items-center justify-between">
                <div className="flex items-center gap-1">
                  {[...Array(t.rating)].map((_, j) => <Star key={j} className="h-4 w-4 fill-gold text-gold" />)}
                </div>
                <span className={cn("rounded-full px-2 py-0.5 text-[10px]", t.published ? "bg-teal/15 text-teal" : "bg-muted text-muted-foreground")}>{t.published ? "منشور" : "مسودة"}</span>
              </div>
              <p className="relative mt-3 line-clamp-3 text-sm text-foreground/80">&ldquo;{t.text}&rdquo;</p>
              <div className="mt-4 flex items-center gap-3 border-t border-border pt-3">
                <span className="grid h-10 w-10 place-items-center rounded-full text-sm font-bold text-white" style={{ background: t.color }}>{t.initials}</span>
                <div className="min-w-0 flex-1">
                  <div className="truncate font-bold text-ink text-sm">{t.name}</div>
                  <div className="truncate text-xs text-muted-foreground">{t.role}</div>
                </div>
                <Button variant="ghost" size="icon" onClick={() => openEdit(t)}><Edit className="h-4 w-4" /></Button>
                <Button variant="ghost" size="icon" onClick={() => remove(t.id)} className="text-red-600 hover:bg-red-50"><Trash2 className="h-4 w-4" /></Button>
              </div>
            </div>
          ))}
        </div>
      )}
      {showForm && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-ink/60 p-4 backdrop-blur-sm">
          <div className="max-h-[90vh] w-full max-w-lg overflow-y-auto rounded-3xl bg-white p-6 shadow-2xl">
            <div className="mb-4 flex items-center justify-between">
              <h2 className="text-xl font-bold text-ink">{editing ? "تعديل التقييم" : "تقييم جديد"}</h2>
              <button onClick={() => setShowForm(false)} className="grid h-9 w-9 place-items-center rounded-lg hover:bg-secondary"><X className="h-5 w-5" /></button>
            </div>
            <div className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-1.5"><Label>الاسم *</Label><Input value={form.name} onChange={e => setForm({ ...form, name: e.target.value })} /></div>
                <div className="space-y-1.5"><Label>المسمى/الجهة</Label><Input value={form.role} onChange={e => setForm({ ...form, role: e.target.value })} placeholder="صاحب فيلا - صنعاء" /></div>
              </div>
              <div className="space-y-1.5"><Label>نص التقييم *</Label><Textarea value={form.text} onChange={e => setForm({ ...form, text: e.target.value })} rows={4} /></div>
              <div className="grid grid-cols-3 gap-4">
                <div className="space-y-1.5"><Label>التقييم</Label>
                  <select value={form.rating} onChange={e => setForm({ ...form, rating: Number(e.target.value) })} className="flex h-10 w-full rounded-md border border-input bg-background px-3 text-sm">
                    {[5,4,3,2,1].map(r => <option key={r} value={r}>{r} نجوم</option>)}
                  </select>
                </div>
                <div className="space-y-1.5"><Label>الأحرف الأولى</Label><Input value={form.initials} onChange={e => setForm({ ...form, initials: e.target.value })} placeholder="أ.ش" /></div>
                <div className="space-y-1.5"><Label>الترتيب</Label><Input type="number" value={form.order} onChange={e => setForm({ ...form, order: Number(e.target.value) })} /></div>
              </div>
              <div className="space-y-1.5"><Label>اللون</Label>
                <div className="flex gap-2">
                  {COLORS.map(c => <button key={c} type="button" onClick={() => setForm({ ...form, color: c })} className={cn("h-9 w-9 rounded-lg ring-2 ring-offset-2", form.color === c ? "ring-ink" : "ring-transparent")} style={{ background: c }} />)}
                </div>
              </div>
              <label className="flex items-center gap-2"><input type="checkbox" checked={form.published} onChange={e => setForm({ ...form, published: e.target.checked })} className="h-4 w-4 rounded" /><span className="text-sm">منشور</span></label>
            </div>
            <div className="mt-6 flex justify-end gap-2">
              <Button variant="outline" onClick={() => setShowForm(false)}>إلغاء</Button>
              <Button onClick={save} disabled={saving} className="bg-brand text-white hover:bg-brand-dark">{saving ? <Loader2 className="h-4 w-4 animate-spin" /> : <Save className="ml-1 h-4 w-4" />}حفظ</Button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
