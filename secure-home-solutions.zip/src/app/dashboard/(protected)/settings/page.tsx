"use client";

import { useEffect, useState } from "react";
import {
  Settings,
  Save,
  Loader2,
  Building2,
  Phone,
  Globe,
  BarChart3,
  Share2,
  Search,
  CheckCircle2,
} from "lucide-react";
import { DashboardPageHeader } from "@/components/dashboard/ui";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { useToast } from "@/hooks/use-toast";
import { cn } from "@/lib/utils";

const SECTIONS = [
  {
    id: "company",
    label: "بيانات الشركة",
    icon: Building2,
    color: "#f05100",
    fields: [
      { key: "company.name", label: "الاسم الإنجليزي", type: "text" },
      { key: "company.nameAr", label: "الاسم العربي", type: "text" },
      { key: "company.phone", label: "الهاتف", type: "text" },
      { key: "company.phoneRaw", label: "الهاتف (للروابط)", type: "text" },
      { key: "company.whatsapp", label: "واتساب", type: "text" },
      { key: "company.email", label: "البريد الإلكتروني", type: "text" },
      { key: "company.address", label: "العنوان", type: "text" },
      { key: "company.hours", label: "ساعات العمل", type: "text" },
      { key: "company.founded", label: "سنة التأسيس", type: "text" },
    ],
  },
  {
    id: "hero",
    label: "القسم الرئيسي (Hero)",
    icon: Globe,
    color: "#009588",
    fields: [
      { key: "hero.badge", label: "الشارة العلوية", type: "text" },
      { key: "hero.title", label: "العنوان الرئيسي", type: "text" },
      { key: "hero.desc", label: "الوصف", type: "textarea" },
    ],
  },
  {
    id: "stats",
    label: "الإحصائيات",
    icon: BarChart3,
    color: "#104e64",
    fields: [
      { key: "stats.projects", label: "عدد المشاريع", type: "number" },
      { key: "stats.clients", label: "عدد العملاء", type: "number" },
      { key: "stats.experience", label: "سنوات الخبرة", type: "number" },
      { key: "stats.team", label: "حجم الفريق", type: "number" },
    ],
  },
  {
    id: "social",
    label: "روابط التواصل الاجتماعي",
    icon: Share2,
    color: "#fcbb00",
    fields: [
      { key: "social.facebook", label: "فيسبوك", type: "text" },
      { key: "social.twitter", label: "تويتر", type: "text" },
      { key: "social.instagram", label: "انستغرام", type: "text" },
      { key: "social.linkedin", label: "لينكدإن", type: "text" },
    ],
  },
  {
    id: "seo",
    label: "إعدادات SEO",
    icon: Search,
    color: "#7c3aed",
    fields: [
      { key: "seo.title", label: "عنوان الصفحة (Title)", type: "text" },
      { key: "seo.description", label: "الوصف (Meta Description)", type: "textarea" },
    ],
  },
];

export default function SettingsPage() {
  const [values, setValues] = useState<Record<string, string>>({});
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [activeSection, setActiveSection] = useState("company");
  const { toast } = useToast();

  useEffect(() => {
    fetch("/api/admin/settings")
      .then((r) => r.json())
      .then((d) => {
        if (d.ok) setValues(d.settings || {});
      })
      .finally(() => setLoading(false));
  }, []);

  async function save() {
    setSaving(true);
    try {
      const res = await fetch("/api/admin/settings", {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ settings: values }),
      });
      const d = await res.json();
      if (d.ok) {
        toast({
          title: "تم حفظ الإعدادات",
          description: "تم تحديث إعدادات الموقع بنجاح.",
        });
      } else {
        throw new Error(d.error);
      }
    } catch {
      toast({ variant: "destructive", title: "تعذّر الحفظ" });
    } finally {
      setSaving(false);
    }
  }

  if (loading) {
    return (
      <div className="flex h-64 items-center justify-center">
        <Loader2 className="h-8 w-8 animate-spin text-brand" />
      </div>
    );
  }

  const activeSectionData = SECTIONS.find((s) => s.id === activeSection)!;

  return (
    <div>
      <DashboardPageHeader
        title="إعدادات الموقع"
        subtitle="تحكّم في بيانات الشركة، القسم الرئيسي، الإحصائيات، التواصل، و SEO"
        action={
          <Button onClick={save} disabled={saving} className="bg-brand text-white hover:bg-brand-dark">
            {saving ? (
              <Loader2 className="ml-1.5 h-4 w-4 animate-spin" />
            ) : (
              <Save className="ml-1.5 h-4 w-4" />
            )}
            حفظ التغييرات
          </Button>
        }
      />

      <div className="grid gap-6 lg:grid-cols-12">
        {/* Section tabs */}
        <div className="lg:col-span-3">
          <div className="sticky top-4 space-y-1">
            {SECTIONS.map((s) => (
              <button
                key={s.id}
                onClick={() => setActiveSection(s.id)}
                className={cn(
                  "flex w-full items-center gap-3 rounded-xl px-3 py-2.5 text-right text-sm font-medium transition-colors",
                  activeSection === s.id
                    ? "bg-white text-ink shadow-sm ring-1 ring-border"
                    : "text-muted-foreground hover:bg-white/60 hover:text-ink"
                )}
              >
                <span
                  className="grid h-8 w-8 shrink-0 place-items-center rounded-lg text-white"
                  style={{ backgroundColor: s.color }}
                >
                  <s.icon className="h-4 w-4" />
                </span>
                <span className="flex-1">{s.label}</span>
              </button>
            ))}
          </div>
        </div>

        {/* Fields */}
        <div className="lg:col-span-9">
          <div className="rounded-2xl border border-border bg-white p-6 shadow-sm">
            <div className="mb-5 flex items-center gap-3 border-b border-border pb-4">
              <span
                className="grid h-10 w-10 place-items-center rounded-xl text-white"
                style={{ backgroundColor: activeSectionData.color }}
              >
                <activeSectionData.icon className="h-5 w-5" />
              </span>
              <div>
                <h2 className="font-bold text-ink">{activeSectionData.label}</h2>
                <p className="text-xs text-muted-foreground">
                  عدّل القيم واضغط حفظ التغييرات أعلى الصفحة
                </p>
              </div>
            </div>

            <div className="grid gap-4 sm:grid-cols-2">
              {activeSectionData.fields.map((f) => (
                <div
                  key={f.key}
                  className={cn("space-y-1.5", f.type === "textarea" && "sm:col-span-2")}
                >
                  <Label htmlFor={f.key} className="text-xs font-medium">
                    {f.label}
                  </Label>
                  {f.type === "textarea" ? (
                    <Textarea
                      id={f.key}
                      value={values[f.key] ?? ""}
                      onChange={(e) =>
                        setValues((v) => ({ ...v, [f.key]: e.target.value }))
                      }
                      rows={3}
                      dir={f.key.includes("email") || f.key.includes("phone") ? "ltr" : "rtl"}
                    />
                  ) : (
                    <Input
                      id={f.key}
                      type={f.type === "number" ? "number" : "text"}
                      value={values[f.key] ?? ""}
                      onChange={(e) =>
                        setValues((v) => ({ ...v, [f.key]: e.target.value }))
                      }
                      dir={f.key.includes("email") || f.key.includes("phone") || f.key.includes("whatsapp") ? "ltr" : "rtl"}
                    />
                  )}
                </div>
              ))}
            </div>

            <div className="mt-6 flex items-center gap-2 rounded-xl border border-teal/20 bg-teal/5 p-3 text-xs text-teal">
              <CheckCircle2 className="h-4 w-4 shrink-0" />
              التغييرات تنعكس مباشرة على الموقع بعد الحفظ.
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
