"use client";

import { useEffect, useState, useCallback } from "react";
import { FileText, Trash2, Phone, Mail, MessageSquare, RefreshCw, Search, ChevronDown } from "lucide-react";
import {
  DashboardPageHeader,
  Badge,
  EmptyState,
  formatDate,
} from "@/components/dashboard/ui";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useToast } from "@/hooks/use-toast";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";

type Item = {
  id: string;
  name: string;
  phone: string;
  email: string | null;
  service: string;
  message: string | null;
  status: string;
  createdAt: string;
};

export default function QuotesPage() {
  const [items, setItems] = useState<Item[]>([]);
  const [loading, setLoading] = useState(true);
  const [filter, setFilter] = useState("all");
  const [query, setQuery] = useState("");
  const [expanded, setExpanded] = useState<string | null>(null);
  const { toast } = useToast();

  const load = useCallback(() => {
    setLoading(true);
    fetch(`/api/admin/quotes?status=${filter}`)
      .then((r) => r.json())
      .then((d) => setItems(d.items || []))
      .finally(() => setLoading(false));
  }, [filter]);

  useEffect(() => {
    load();
  }, [load]);

  async function updateStatus(id: string, status: string) {
    await fetch("/api/admin/quotes", {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ id, status }),
    });
    toast({ title: "تم تحديث الحالة" });
    load();
  }

  async function remove(id: string) {
    if (!confirm("هل أنت متأكد من حذف هذا الطلب؟")) return;
    await fetch(`/api/admin/quotes?id=${id}`, { method: "DELETE" });
    toast({ title: "تم الحذف" });
    load();
  }

  const filtered = items.filter(
    (i) =>
      !query ||
      i.name.includes(query) ||
      i.phone.includes(query) ||
      i.service.includes(query)
  );

  return (
    <div>
      <DashboardPageHeader
        title="طلبات عروض الأسعار"
        subtitle={`${items.length} طلب إجمالي`}
        action={
          <Button variant="outline" onClick={load} disabled={loading}>
            <RefreshCw className={`ml-1.5 h-4 w-4 ${loading ? "animate-spin" : ""}`} />
            تحديث
          </Button>
        }
      />

      {/* Filters */}
      <div className="mb-4 flex flex-wrap items-center gap-3">
        <div className="relative flex-1 min-w-[220px]">
          <Search className="absolute right-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
          <Input
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="ابحث بالاسم أو الهاتف..."
            className="pr-10"
          />
        </div>
        <Select value={filter} onValueChange={setFilter}>
          <SelectTrigger className="w-[180px]">
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">كل الحالات</SelectItem>
            <SelectItem value="new">جديد</SelectItem>
            <SelectItem value="contacted">تم التواصل</SelectItem>
            <SelectItem value="won">تم الإغلاق</SelectItem>
            <SelectItem value="lost">ملغي</SelectItem>
          </SelectContent>
        </Select>
      </div>

      {filtered.length === 0 ? (
        <EmptyState
          icon={FileText}
          title="لا توجد طلبات"
          desc="ستظهر طلبات عروض الأسعار هنا عند إرسالها من الموقع."
        />
      ) : (
        <div className="space-y-3">
          {filtered.map((item) => (
            <div
              key={item.id}
              className="overflow-hidden rounded-2xl border border-border bg-white shadow-sm"
            >
              <button
                onClick={() => setExpanded(expanded === item.id ? null : item.id)}
                className="flex w-full items-center gap-3 p-4 text-right"
              >
                <span className="grid h-11 w-11 shrink-0 place-items-center rounded-xl bg-brand/10 text-brand">
                  <FileText className="h-5 w-5" />
                </span>
                <div className="min-w-0 flex-1">
                  <div className="flex items-center gap-2">
                    <span className="truncate font-bold text-ink">{item.name}</span>
                    <Badge status={item.status} />
                  </div>
                  <div className="mt-0.5 flex flex-wrap items-center gap-x-3 gap-y-0.5 text-xs text-muted-foreground">
                    <span className="font-medium text-brand">{item.service}</span>
                    <span dir="ltr">{item.phone}</span>
                    <span>{formatDate(item.createdAt)}</span>
                  </div>
                </div>
                <ChevronDown
                  className={`h-5 w-5 shrink-0 text-muted-foreground transition-transform ${
                    expanded === item.id ? "rotate-180" : ""
                  }`}
                />
              </button>
              {expanded === item.id && (
                <div className="border-t border-border bg-secondary/30 p-4">
                  <div className="grid gap-3 sm:grid-cols-3">
                    {item.phone && (
                      <a
                        href={`tel:${item.phone}`}
                        className="flex items-center gap-2 rounded-lg border border-border bg-white p-2.5 text-sm"
                      >
                        <Phone className="h-4 w-4 text-brand" />
                        <span dir="ltr">{item.phone}</span>
                      </a>
                    )}
                    {item.email && (
                      <a
                        href={`mailto:${item.email}`}
                        className="flex items-center gap-2 rounded-lg border border-border bg-white p-2.5 text-sm"
                      >
                        <Mail className="h-4 w-4 text-teal" />
                        <span dir="ltr" className="truncate">{item.email}</span>
                      </a>
                    )}
                    <div className="flex items-center gap-2 rounded-lg border border-border bg-white p-2.5 text-sm text-muted-foreground">
                      <MessageSquare className="h-4 w-4 text-gold" />
                      {item.service}
                    </div>
                  </div>
                  {item.message && (
                    <div className="mt-3 rounded-lg border border-border bg-white p-3 text-sm text-foreground/80">
                      {item.message}
                    </div>
                  )}
                  <div className="mt-4 flex flex-wrap items-center gap-2">
                    <Select
                      value={item.status}
                      onValueChange={(v) => updateStatus(item.id, v)}
                    >
                      <SelectTrigger className="w-[160px]">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="new">جديد</SelectItem>
                        <SelectItem value="contacted">تم التواصل</SelectItem>
                        <SelectItem value="won">تم الإغلاق</SelectItem>
                        <SelectItem value="lost">ملغي</SelectItem>
                      </SelectContent>
                    </Select>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => remove(item.id)}
                      className="text-red-600 hover:bg-red-50"
                    >
                      <Trash2 className="ml-1 h-4 w-4" />
                      حذف
                    </Button>
                  </div>
                </div>
              )}
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
