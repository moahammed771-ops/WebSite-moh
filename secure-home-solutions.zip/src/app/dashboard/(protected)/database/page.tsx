"use client";

import { useEffect, useState } from "react";
import {
  Database,
  Save,
  Loader2,
  CheckCircle2,
  XCircle,
  Plug,
  Upload,
  Sprout,
  AlertTriangle,
  Eye,
  EyeOff,
  Server,
  RefreshCw,
} from "lucide-react";
import { DashboardPageHeader } from "@/components/dashboard/ui";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useToast } from "@/hooks/use-toast";
import { cn } from "@/lib/utils";

export default function DatabasePage() {
  const [currentUrl, setCurrentUrl] = useState("");
  const [provider, setProvider] = useState("unknown");
  const [newUrl, setNewUrl] = useState("");
  const [showUrl, setShowUrl] = useState(false);
  const [loading, setLoading] = useState(true);
  const [testing, setTesting] = useState(false);
  const [saving, setSaving] = useState(false);
  const [pushing, setPushing] = useState(false);
  const [seeding, setSeeding] = useState(false);
  const [testResult, setTestResult] = useState<{ ok: boolean; message: string } | null>(null);
  const [actionResult, setActionResult] = useState<{ ok: boolean; message: string } | null>(null);
  const { toast } = useToast();

  useEffect(() => {
    fetch("/api/admin/database")
      .then((r) => r.json())
      .then((d) => {
        if (d.ok) {
          setCurrentUrl(d.config.databaseUrl);
          setProvider(d.config.provider);
        }
      })
      .finally(() => setLoading(false));
  }, []);

  async function testConnection() {
    const urlToTest = newUrl || currentUrl;
    if (!urlToTest) {
      toast({ variant: "destructive", title: "أدخل رابط الاتصال أولاً" });
      return;
    }
    setTesting(true);
    setTestResult(null);
    try {
      const res = await fetch("/api/admin/database", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ action: "test", databaseUrl: urlToTest }),
      });
      const d = await res.json();
      setTestResult({ ok: d.ok, message: d.ok ? d.message : d.error });
      toast({
        title: d.ok ? "نجح الاتصال" : "فشل الاتصال",
        description: d.ok ? d.message : d.error,
        variant: d.ok ? "default" : "destructive",
      });
    } catch {
      setTestResult({ ok: false, message: "خطأ في الشبكة" });
    } finally {
      setTesting(false);
    }
  }

  async function applyConfig() {
    if (!newUrl) {
      toast({ variant: "destructive", title: "أدخل رابط الاتصال الجديد" });
      return;
    }
    if (!confirm("هل أنت متأكد من تغيير قاعدة البيانات؟ سيتم تحديث ملف .env.")) return;
    setSaving(true);
    setActionResult(null);
    try {
      const res = await fetch("/api/admin/database", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ action: "apply", databaseUrl: newUrl }),
      });
      const d = await res.json();
      setActionResult({ ok: d.ok, message: d.ok ? d.message : d.error });
      if (d.ok) {
        setCurrentUrl(newUrl.replace(/(:\/\/[^:]+:)[^@]+(@)/, "$1••••••••$2"));
        setProvider(
          newUrl.startsWith("postgresql://") || newUrl.startsWith("postgres://")
            ? "postgresql"
            : "sqlite"
        );
        setNewUrl("");
      }
      toast({
        title: d.ok ? "تم الحفظ" : "فشل الحفظ",
        description: d.ok ? d.message : d.error,
        variant: d.ok ? "default" : "destructive",
      });
    } catch {
      setActionResult({ ok: false, message: "خطأ في الشبكة" });
    } finally {
      setSaving(false);
    }
  }

  async function pushSchema() {
    if (!confirm("سيتم إنشاء جميع الجداول في قاعدة البيانات الجديدة. متابعة؟")) return;
    setPushing(true);
    setActionResult(null);
    try {
      const res = await fetch("/api/admin/database", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ action: "push-schema" }),
      });
      const d = await res.json();
      setActionResult({ ok: d.ok, message: d.ok ? d.message : d.error });
      toast({
        title: d.ok ? "تم إنشاء الجداول" : "فشل",
        description: d.ok ? d.message : d.error,
        variant: d.ok ? "default" : "destructive",
      });
    } catch {
      setActionResult({ ok: false, message: "خطأ في الشبكة" });
    } finally {
      setPushing(false);
    }
  }

  async function seedData() {
    if (!confirm("سيتم زرع البيانات الافتراضية (الخدمات، المشاريع، المقالات، إلخ). متابعة؟")) return;
    setSeeding(true);
    setActionResult(null);
    try {
      const res = await fetch("/api/admin/database", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ action: "seed" }),
      });
      const d = await res.json();
      setActionResult({ ok: d.ok, message: d.ok ? d.message : d.error });
      toast({
        title: d.ok ? "تم الزرع" : "فشل",
        description: d.ok ? d.message : d.error,
        variant: d.ok ? "default" : "destructive",
      });
    } catch {
      setActionResult({ ok: false, message: "خطأ في الشبكة" });
    } finally {
      setSeeding(false);
    }
  }

  if (loading) {
    return (
      <div className="flex h-64 items-center justify-center">
        <Loader2 className="h-8 w-8 animate-spin text-brand" />
      </div>
    );
  }

  return (
    <div>
      <DashboardPageHeader
        title="قاعدة البيانات"
        subtitle="إدارة اتصال قاعدة البيانات (Supabase PostgreSQL أو SQLite)"
      />

      {/* Current status */}
      <div className="mb-6 rounded-2xl border border-border bg-white p-5 shadow-sm">
        <div className="flex items-center gap-3 border-b border-border pb-4">
          <span
            className={cn(
              "grid h-12 w-12 place-items-center rounded-xl text-white shadow-lg",
              provider === "postgresql" ? "bg-teal" : provider === "sqlite" ? "bg-gold" : "bg-muted-foreground"
            )}
          >
            <Database className="h-6 w-6" />
          </span>
          <div className="flex-1">
            <h2 className="font-bold text-ink">الاتصال الحالي</h2>
            <div className="flex items-center gap-2 text-xs text-muted-foreground">
              <span
                className={cn(
                  "rounded-full px-2 py-0.5 font-medium",
                  provider === "postgresql"
                    ? "bg-teal/15 text-teal"
                    : provider === "sqlite"
                    ? "bg-gold/15 text-gold"
                    : "bg-muted text-muted-foreground"
                )}
              >
                {provider === "postgresql" ? "PostgreSQL" : provider === "sqlite" ? "SQLite" : "غير معروف"}
              </span>
              <span className="flex items-center gap-1">
                <span className="h-2 w-2 rounded-full bg-teal animate-pulse" />
                متصل
              </span>
            </div>
          </div>
        </div>
        <div className="mt-4">
          <Label className="text-xs">رابط الاتصال الحالي</Label>
          <div className="mt-1.5 flex items-center gap-2 rounded-xl border border-border bg-secondary/40 p-3">
            <Server className="h-4 w-4 shrink-0 text-muted-foreground" />
            <code className="flex-1 truncate text-xs text-foreground/80" dir="ltr">
              {currentUrl || "غير مضبوط"}
            </code>
            <button
              onClick={() => setShowUrl((v) => !v)}
              className="shrink-0 text-muted-foreground hover:text-ink"
              aria-label="إظهار/إخفاء"
            >
              {showUrl ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
            </button>
          </div>
        </div>
      </div>

      {/* Change connection */}
      <div className="mb-6 rounded-2xl border border-border bg-white p-5 shadow-sm">
        <h2 className="flex items-center gap-2 font-bold text-ink">
          <Plug className="h-5 w-5 text-brand" />
          تغيير اتصال قاعدة البيانات
        </h2>
        <p className="mt-1 text-sm text-muted-foreground">
          أدخل رابط الاتصال الجديد (Supabase، PostgreSQL، أو SQLite). اختبر الاتصال أولاً ثم احفظه.
        </p>

        <div className="mt-4 space-y-3">
          <div className="space-y-1.5">
            <Label>رابط الاتصال الجديد (DATABASE_URL)</Label>
            <Input
              value={newUrl}
              onChange={(e) => setNewUrl(e.target.value)}
              dir="ltr"
              placeholder="postgresql://user:password@host:5432/dbname"
              className="font-mono text-sm"
            />
          </div>

          {/* Examples */}
          <div className="rounded-xl border border-border bg-secondary/30 p-3">
            <div className="mb-2 text-xs font-bold text-muted-foreground">أمثلة:</div>
            <div className="space-y-1.5 text-xs">
              <button
                onClick={() => setNewUrl("postgresql://postgres:PASSWORD@db.xxx.supabase.co:5432/postgres")}
                className="block w-full truncate rounded-lg border border-border bg-white p-2 text-left font-mono text-foreground/70 hover:border-brand/40 hover:text-brand"
                dir="ltr"
              >
                postgresql://postgres:PASSWORD@db.xxx.supabase.co:5432/postgres
              </button>
              <button
                onClick={() => setNewUrl("postgresql://user:pass@aws-0-region.pooler.supabase.com:5432/postgres")}
                className="block w-full truncate rounded-lg border border-border bg-white p-2 text-left font-mono text-foreground/70 hover:border-brand/40 hover:text-brand"
                dir="ltr"
              >
                postgresql://user:pass@pooler.supabase.com:5432/postgres (مع pooler)
              </button>
              <button
                onClick={() => setNewUrl("file:./db/custom.db")}
                className="block w-full truncate rounded-lg border border-border bg-white p-2 text-left font-mono text-foreground/70 hover:border-brand/40 hover:text-brand"
                dir="ltr"
              >
                file:./db/custom.db (SQLite محلي)
              </button>
            </div>
          </div>

          {/* Test result */}
          {testResult && (
            <div
              className={cn(
                "flex items-center gap-2 rounded-xl border p-3 text-sm",
                testResult.ok
                  ? "border-teal/30 bg-teal/5 text-teal"
                  : "border-red-200 bg-red-50 text-red-700"
              )}
            >
              {testResult.ok ? (
                <CheckCircle2 className="h-5 w-5 shrink-0" />
              ) : (
                <XCircle className="h-5 w-5 shrink-0" />
              )}
              <span className="flex-1">{testResult.message}</span>
            </div>
          )}

          {/* Action buttons */}
          <div className="flex flex-wrap gap-2">
            <Button
              onClick={testConnection}
              disabled={testing || (!newUrl && !currentUrl)}
              variant="outline"
            >
              {testing ? (
                <Loader2 className="ml-1.5 h-4 w-4 animate-spin" />
              ) : (
                <Plug className="ml-1.5 h-4 w-4" />
              )}
              اختبار الاتصال
            </Button>
            <Button
              onClick={applyConfig}
              disabled={saving || !newUrl}
              className="bg-brand text-white hover:bg-brand-dark"
            >
              {saving ? (
                <Loader2 className="ml-1.5 h-4 w-4 animate-spin" />
              ) : (
                <Save className="ml-1.5 h-4 w-4" />
              )}
              حفظ وتطبيق
            </Button>
          </div>
        </div>
      </div>

      {/* Schema & seed management */}
      <div className="mb-6 rounded-2xl border border-border bg-white p-5 shadow-sm">
        <h2 className="flex items-center gap-2 font-bold text-ink">
          <Upload className="h-5 w-5 text-teal" />
          إدارة الجداول والبيانات
        </h2>
        <p className="mt-1 text-sm text-muted-foreground">
          بعد تغيير قاعدة البيانات، أنشئ الجداول وازرع البيانات الافتراضية.
        </p>

        <div className="mt-4 grid gap-3 sm:grid-cols-2">
          <button
            onClick={pushSchema}
            disabled={pushing}
            className="group flex items-start gap-3 rounded-2xl border border-border p-4 text-right transition-all hover:border-teal/40 hover:shadow-md disabled:opacity-50"
          >
            <span className="grid h-11 w-11 shrink-0 place-items-center rounded-xl bg-teal/15 text-teal">
              {pushing ? <Loader2 className="h-5 w-5 animate-spin" /> : <Upload className="h-5 w-5" />}
            </span>
            <div className="flex-1">
              <div className="font-bold text-ink">إنشاء الجداول</div>
              <div className="mt-0.5 text-xs text-muted-foreground">
                ينشئ جميع الجداول (QuoteRequest, Service, Project, BlogPost, إلخ) في قاعدة البيانات الحالية
              </div>
            </div>
          </button>

          <button
            onClick={seedData}
            disabled={seeding}
            className="group flex items-start gap-3 rounded-2xl border border-border p-4 text-right transition-all hover:border-brand/40 hover:shadow-md disabled:opacity-50"
          >
            <span className="grid h-11 w-11 shrink-0 place-items-center rounded-xl bg-brand/15 text-brand">
              {seeding ? <Loader2 className="h-5 w-5 animate-spin" /> : <Sprout className="h-5 w-5" />}
            </span>
            <div className="flex-1">
              <div className="font-bold text-ink">زرع البيانات الافتراضية</div>
              <div className="mt-0.5 text-xs text-muted-foreground">
                يضيف الخدمات (4)، المشاريع (6)، المقالات (4)، آراء العملاء (6)، الفريق (6)، الأسئلة (8)
              </div>
            </div>
          </button>
        </div>

        {/* Action result */}
        {actionResult && (
          <div
            className={cn(
              "mt-4 flex items-start gap-2 rounded-xl border p-3 text-sm",
              actionResult.ok
                ? "border-teal/30 bg-teal/5 text-teal"
                : "border-red-200 bg-red-50 text-red-700"
            )}
          >
            {actionResult.ok ? (
              <CheckCircle2 className="h-5 w-5 shrink-0" />
            ) : (
              <XCircle className="h-5 w-5 shrink-0" />
            )}
            <span className="flex-1 whitespace-pre-wrap break-all">{actionResult.message}</span>
          </div>
        )}
      </div>

      {/* Warning notice */}
      <div className="rounded-2xl border border-gold/30 bg-gold/5 p-4">
        <div className="flex items-start gap-3">
          <AlertTriangle className="h-5 w-5 shrink-0 text-gold" />
          <div className="flex-1 text-sm">
            <div className="font-bold text-ink">تنبيهات مهمة</div>
            <ul className="mt-1.5 space-y-1 text-xs text-muted-foreground">
              <li>• تغيير قاعدة البيانات يُحدّث ملف <code className="rounded bg-secondary px-1">.env</code> مباشرة</li>
              <li>• بعد الحفظ، قد تحتاج لإعادة تشغيل الخادم لتطبيق التغييرات على الاتصال الحالي</li>
              <li>• تأكد من اختبار الاتصال قبل الحفظ لتجنب فقدان الوصول للبيانات</li>
              <li>• عند إنشاء الجداول في قاعدة بيانات جديدة، استخدم &quot;زرع البيانات&quot; لتعبئتها بالمحتوى الافتراضي</li>
              <li>• احتفظ بنسخة احتياطية من رابط الاتصال القديم قبل التغيير</li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  );
}
