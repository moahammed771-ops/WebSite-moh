"use client";

import { useEffect, useState, useCallback } from "react";
import { MessagesSquare, RefreshCw, Loader2, User, Bot, Trash2, X } from "lucide-react";
import { DashboardPageHeader, EmptyState, formatDate } from "@/components/dashboard/ui";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";
import { cn } from "@/lib/utils";

type Session = {
  sessionId: string; messageCount: number; lastAt: string; preview: string;
  messages: { id: string; role: string; content: string; createdAt: string }[];
};

export default function ChatsPage() {
  const [sessions, setSessions] = useState<Session[]>([]);
  const [loading, setLoading] = useState(true);
  const [active, setActive] = useState<Session | null>(null);
  const { toast } = useToast();

  const load = useCallback(() => {
    setLoading(true);
    fetch("/api/admin/chats").then(r => r.json()).then(d => setSessions(d.sessions || [])).finally(() => setLoading(false));
  }, []);
  useEffect(() => { load(); }, [load]);

  return (
    <div>
      <DashboardPageHeader title="سجلات المساعد الذكي" subtitle={`${sessions.length} جلسة محادثة`}
        action={<Button variant="outline" onClick={load} disabled={loading}><RefreshCw className={cn("ml-1.5 h-4 w-4", loading && "animate-spin")} />تحديث</Button>} />

      {loading ? <div className="flex h-40 items-center justify-center"><Loader2 className="h-8 w-8 animate-spin text-brand" /></div>
      : sessions.length === 0 ? <EmptyState icon={MessagesSquare} title="لا توجد محادثات بعد" desc="ستظهر محادثات المساعد الذكي مع الزوار هنا." />
      : (
        <div className="grid gap-4 lg:grid-cols-3">
          {/* Sessions list */}
          <div className="space-y-2 lg:col-span-1 max-h-[70vh] overflow-y-auto pl-1">
            {sessions.map((s) => (
              <button key={s.sessionId} onClick={() => setActive(s)}
                className={cn("w-full rounded-2xl border bg-white p-3 text-right shadow-sm transition-all hover:shadow-md", active?.sessionId === s.sessionId ? "border-brand ring-1 ring-brand/30" : "border-border")}>
                <div className="flex items-center justify-between">
                  <span className="grid h-9 w-9 place-items-center rounded-lg bg-brand/10 text-brand"><MessagesSquare className="h-4 w-4" /></span>
                  <span className="rounded-full bg-secondary px-2 py-0.5 text-[10px] text-muted-foreground">{s.messageCount} رسالة</span>
                </div>
                <div className="mt-2 truncate text-xs text-muted-foreground" dir="auto">{s.preview}</div>
                <div className="mt-1 text-[10px] text-muted-foreground">{formatDate(s.lastAt)}</div>
              </button>
            ))}
          </div>
          {/* Active conversation */}
          <div className="lg:col-span-2">
            {active ? (
              <div className="flex h-[70vh] flex-col overflow-hidden rounded-2xl border border-border bg-white shadow-sm">
                <div className="flex items-center justify-between border-b border-border bg-secondary/30 p-4">
                  <div>
                    <div className="font-bold text-ink">جلسة المحادثة</div>
                    <div className="text-xs text-muted-foreground" dir="ltr">{active.sessionId.slice(0, 24)}...</div>
                  </div>
                  <button onClick={() => setActive(null)} className="grid h-9 w-9 place-items-center rounded-lg hover:bg-secondary"><X className="h-5 w-5" /></button>
                </div>
                <div className="flex-1 space-y-4 overflow-y-auto bg-[#fafbfc] p-4">
                  {active.messages.map((m) => {
                    const isUser = m.role === "user";
                    return (
                      <div key={m.id} className={cn("flex items-start gap-2", isUser && "flex-row-reverse")}>
                        <span className={cn("grid h-8 w-8 shrink-0 place-items-center rounded-lg text-white", isUser ? "bg-ink" : "bg-gradient-to-br from-brand to-brand-dark")}>
                          {isUser ? <User className="h-4 w-4" /> : <Bot className="h-4 w-4" />}
                        </span>
                        <div className={cn("max-w-[80%] whitespace-pre-wrap rounded-2xl px-4 py-2.5 text-sm leading-relaxed shadow-sm", isUser ? "rounded-tl-sm bg-brand text-white" : "rounded-tr-sm bg-white text-foreground")}>
                          {m.content}
                        </div>
                      </div>
                    );
                  })}
                </div>
                <div className="border-t border-border bg-secondary/30 p-3 text-center text-xs text-muted-foreground">
                  {active.messageCount} رسالة · آخر تحديث {formatDate(active.lastAt)}
                </div>
              </div>
            ) : (
              <div className="flex h-[70vh] items-center justify-center rounded-2xl border border-dashed border-border bg-white text-center">
                <div>
                  <MessagesSquare className="mx-auto h-12 w-12 text-muted-foreground/40" />
                  <p className="mt-3 text-sm text-muted-foreground">اختر محادثة من القائمة لعرض تفاصيلها</p>
                </div>
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
}
