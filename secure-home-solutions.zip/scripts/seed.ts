import { db } from "@/lib/db";
import { PROJECTS, BLOG_POSTS, TESTIMONIALS, TEAM, FAQ_ITEMS } from "@/lib/site-data";

const SERVICE_SEED = [
  {
    slug: "cctv",
    num: "01",
    title: "كاميرات المراقبة",
    shortDesc: "أنظمة مراقبة احترافية بأحدث التقنيات تشمل كاميرات IP وHD مع ميزات الذكاء الاصطناعي.",
    longDesc:
      "نقدم أنظمة كاميرات مراقبة احترافية بأحدث التقنيات تشمل كاميرات IP وHD و4K مع ميزات الذكاء الاصطناعي. كاميراتنا تتميز بالرؤية الليلية المتقدمة، التنبيهات الذكية عبر الهاتف، والتخزين السحابي الآمن. نستخدم منتجات معتمدة من Hikvision وDahua مع ضمان رسمي حتى سنتين.",
    features: ["كاميرات 4K فائقة الدقة", "رؤية ليلية متقدمة", "تنبيهات ذكية عبر الهاتف", "تخزين سحابي آمن"],
    image: "/images/service-cctv.png",
    accent: "#f05100",
    icon: "Cctv",
    startPrice: "120$",
    warranty: "سنتان",
  },
  {
    slug: "intercom",
    num: "02",
    title: "أنظمة الإنتركم",
    shortDesc: "أنظمة اتصال داخلي متطورة تشمل الإنتركم الصوتي والمرئي مع تقنية الذكاء الاصطناعي.",
    longDesc:
      "نقدم أنظمة إنتركم متطورة تشمل الإنتركم الصوتي والمرئي عالي الدقة مع تقنية الذكاء الاصطناعي. أنظمتنا تدعم فتح الأبواب عن بعد، التكامل مع الهاتف الذكي، والتحكم بصمة الوجه. تركيب احترافي معتمد مع ضمان سنة كاملة ودعم فني مستمر.",
    features: ["إنتركم مرئي عالي الدقة", "فتح الأبواب عن بعد", "تكامل مع الهاتف الذكي", "تحكم بصمة الوجه"],
    image: "/images/service-intercom.png",
    accent: "#009588",
    icon: "DoorClosed",
    startPrice: "180$",
    warranty: "سنة",
  },
  {
    slug: "fire",
    num: "03",
    title: "إنذار الحريق",
    shortDesc: "أنظمة إنذار حريق متكاملة تشمل كواشف الدخان والحرارة مع أنظمة الإطفاء التلقائي.",
    longDesc:
      "نقدم أنظمة إنذار حريق متكاملة تشمل كواشف الدخان والحرارة الذكية مع أنظمة الإطفاء التلقائي بالرغوة. أنظمتنا مرتبطة بغرفة التحكم وتدعم الصيانة الدورية المعتمدة. نلتزم بأعلى معايير السلامة المعتمدة دولياً مع ضمان 3 سنوات.",
    features: ["كواشف ذكية فورية", "إطفاء تلقائي بالرغوة", "ربط مع غرفة التحكم", "صيانة دورية معتمدة"],
    image: "/images/service-fire.png",
    accent: "#e40014",
    icon: "Flame",
    startPrice: "250$",
    warranty: "3 سنوات",
  },
  {
    slug: "solar",
    num: "04",
    title: "الطاقة الشمسية",
    shortDesc: "حلول طاقة شمسية متكاملة تشمل الألواح الشمسية والبطاريات والأنفرترات بأسعار تنافسية.",
    longDesc:
      "نقدم حلول طاقة شمسية متكاملة تشمل الألواح الشمسية عالية الكفاءة، بطاريات الليثيوم طويلة العمر، والأنفرترات الذكية المتطورة. أنظمتنا توفر حتى 70% من فاتورة الكهرباء مع ضمان حتى 25 سنة على الألواح. استثمار ذكي يسترد قيمته خلال 3-5 سنوات.",
    features: ["ألواح شمسية عالية الكفاءة", "بطاريات ليثيوم طويلة العمر", "أنفرتر ذكي متطور", "ضمان حتى 25 سنة"],
    image: "/images/service-solar.png",
    accent: "#fcbb00",
    icon: "SunMedium",
    startPrice: "900$",
    warranty: "5 سنوات",
  },
];

async function main() {
  console.log("Seeding database...");

  for (const s of SERVICE_SEED) {
    await db.service.upsert({
      where: { slug: s.slug },
      create: {
        slug: s.slug,
        num: s.num,
        title: s.title,
        shortDesc: s.shortDesc,
        longDesc: s.longDesc,
        features: JSON.stringify(s.features),
        image: s.image,
        accent: s.accent,
        icon: s.icon,
        startPrice: s.startPrice,
        warranty: s.warranty,
        featured: true,
        order: parseInt(s.num, 10),
      },
      update: {},
    });
  }
  console.log(`✓ Seeded ${SERVICE_SEED.length} services`);

  for (const p of PROJECTS) {
    const existing = await db.project.findFirst({ where: { title: p.title } });
    if (!existing) {
      await db.project.create({
        data: {
          title: p.title,
          category: p.category,
          location: p.location,
          image: p.image,
          icon: "Building2",
          desc: p.desc,
          tags: JSON.stringify(p.tags),
          featured: true,
        },
      });
    }
  }
  console.log(`✓ Seeded ${PROJECTS.length} projects`);

  for (const b of BLOG_POSTS) {
    await db.blogPost.upsert({
      where: { slug: b.id },
      create: {
        slug: b.id,
        title: b.title,
        excerpt: b.excerpt,
        content:
          b.excerpt +
          "\n\nنقدم في هذا المقال دليلاً مفصلاً يساعدك على فهم الموضوع بعمق واتخاذ القرار الأمثل. يغطي المقال أهم النقاط العملية والنصائح من خبراء Secure Home Solutions المتميزين في مجال الأمان والطاقة.\n\nأولاً، من المهم فهم الأساسيات التقنية قبل اتخاذ أي قرار. نوصي دائماً بالاستشارة مع متخصص لتقييم احتياجاتك الفعلية.\n\nثانياً، الجودة والضمان من أهم العوامل في اختيار المنتج المناسب. جميع منتجاتنا أصلية ومعتمدة من الشركات المصنعة.\n\nثالثاً، التركيب الاحترافي يضمن أداءً مثالياً وعمراً أطول للنظام. فريقنا معتمد ومدرب على أحدث التقنيات.\n\nللاستفسار أو طلب استشارة مجانية، تواصل معنا على +967 734 066 962 أو عبر نموذج طلب عرض سعر في موقعنا.",
        category: b.category,
        date: b.date,
        readTime: b.readTime,
        image: b.image,
        published: true,
      },
      update: {},
    });
  }
  console.log(`✓ Seeded ${BLOG_POSTS.length} blog posts`);

  // Testimonials
  for (const t of TESTIMONIALS) {
    const existing = await db.testimonial.findFirst({ where: { name: t.name } });
    if (!existing) {
      await db.testimonial.create({
        data: {
          name: t.name,
          role: t.role,
          rating: t.rating,
          text: t.text,
          initials: t.initials,
          color: t.color,
          published: true,
          order: parseInt(t.id.slice(1), 10) || 0,
        },
      });
    }
  }
  console.log(`✓ Seeded ${TESTIMONIALS.length} testimonials`);

  // Team
  for (const m of TEAM) {
    const existing = await db.teamMember.findFirst({ where: { name: m.name } });
    if (!existing) {
      await db.teamMember.create({
        data: {
          name: m.name,
          role: m.role,
          desc: m.desc,
          initials: m.initials,
          color: m.color,
          order: parseInt(m.id.slice(1), 10) || 0,
        },
      });
    }
  }
  console.log(`✓ Seeded ${TEAM.length} team members`);

  // FAQs
  for (const f of FAQ_ITEMS) {
    const existing = await db.fAQ.findFirst({ where: { question: f.question } });
    if (!existing) {
      await db.fAQ.create({
        data: {
          question: f.question,
          answer: f.answer,
          category: f.category,
          published: true,
          order: parseInt(f.id.slice(1), 10) || 0,
        },
      });
    }
  }
  console.log(`✓ Seeded ${FAQ_ITEMS.length} FAQs`);

  console.log("Seed complete!");
}

main()
  .catch((e) => {
    console.error(e);
    process.exit(1);
  })
  .finally(async () => {
    await db.$disconnect();
  });
