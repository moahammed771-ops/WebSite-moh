#!/bin/bash
cd /home/z/my-project
while true; do
  if ! ss -tlnp 2>/dev/null | grep -q ":3000"; then
    echo "[watchdog] server down, starting... $(date)" >> /home/z/my-project/dev.log
    setsid bash -c 'exec /home/z/my-project/node_modules/.bin/next dev -p 3000' </dev/null >>/home/z/my-project/dev.log 2>&1 &
    disown
    sleep 8
  fi
  sleep 5
done
