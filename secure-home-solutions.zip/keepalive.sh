#!/bin/bash
cd /home/z/my-project
while true; do
  if ! pgrep -f "next dev -p 3000" > /dev/null 2>&1; then
    # Server died, restart it
    setsid bash -c 'exec /home/z/my-project/node_modules/.bin/next dev -p 3000' </dev/null >>/home/z/my-project/dev.log 2>&1 &
    disown
    echo "[keepalive] restarted server at $(date)" >> /home/z/my-project/dev.log
  fi
  sleep 3
done
