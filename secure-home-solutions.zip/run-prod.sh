#!/bin/bash
# Production server daemon — more stable than dev mode
cd /home/z/my-project
trap "" SIGTERM SIGHUP
export NODE_ENV=production
export PORT=3000
while true; do
  /home/z/my-project/node_modules/.bin/next start -p 3000 >> /home/z/my-project/dev.log 2>&1
  echo "[prod-daemon] server exited $(date), restarting in 3s" >> /home/z/my-project/dev.log
  sleep 3
done
